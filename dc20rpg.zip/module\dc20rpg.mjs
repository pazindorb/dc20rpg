/**
 * Evaluates given roll formula. 
 * If {@param ignoreDices} is set to true, all dice rolls will be 0.
 */
function evaulateDicelessFormula(formula, rollData) {
  if (formula === "") return 0;

  formula = _enchanceFormula(formula);
  const roll = new Roll(formula, rollData);
  
  // Remove dices
  roll.terms.forEach(term => {
    if (term.faces) term.faces = 0;
  });
  
  roll.evaluateSync({strict: false});
  return roll;
}

function _enchanceFormula(formula) {
  return formula.replace(/(^|\D)(d\d+)(?!\d|\w)/g, "$11$2");
}

function capitalize(str) {
  if (!str) return "";
  return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
}

/**
 * Checks if all elements in array are true;
 */
function arrayOfTruth(array) {
  return array.every(element => element === true);
}

/**
 * Returns label for given key found in object containing keys and label pairs. 
 */
function getLabelFromKey(key, labels) {
  let label = labels[key];
  if (label) return label;
  else return key;
}

/**
 * Returns value under given path for given object.
 * Example path: human.bodyParts.head.nose
 */
function getValueFromPath(object, pathToValue) {
  for (var i=0, pathToValue=pathToValue.split('.'), length=pathToValue.length; i<length; i++){
    object = object[pathToValue[i]];
  }  return object;
}

function setValueForPath(object, path, value) {
  const keys = path.split('.');
  let currentObject = object;

  for (let i = 0; i < keys.length - 1; i++) {
    const key = keys[i];

    // If the key doesn't exist in the current object, create an empty object
    currentObject[key] = currentObject[key] || {};
    currentObject = currentObject[key];
  }

  // Set the value at the final key
  currentObject[keys[keys.length - 1]] = value;
}

function toggleUpOrDown(pathToValue, which, object, upperLimit, lowerLimit) {
  let value = getValueFromPath(object, pathToValue);

  switch (which) {
    case 1: 
      value = Math.min(++value, upperLimit);
      break;
    case 3: 
      value = Math.max(--value, lowerLimit);
      break;
  }
  object.update({[pathToValue] : value});
}

/**
 * Changes boolean property to opposite value.
 */
function changeActivableProperty(pathToValue, object){
  let value = getValueFromPath(object, pathToValue);
  object.update({[pathToValue] : !value});
}

/**
 * Changes numeric value for given path.
 */
function changeNumericValue(value, pathToValue, object) {
  let changedValue = parseInt(value);
  if (isNaN(changedValue)) changedValue = 0;
  if (changedValue < 0) changedValue = 0;

  object.update({[pathToValue] : changedValue});
}

function kebabCaseToStandard(inputString) {
  return inputString
    .split('-') 
    .map(word => word.charAt(0).toUpperCase() + word.slice(1)) 
    .join(' '); 
}

function generateKey() {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
  const charactersLength = characters.length;

  let result = '';
  for (let i = 0; i < 16; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}

/**
 * Changes value of actor's skill skillMastery.
 */
function toggleSkillMastery(pathToValue, which, actor) {
  let currentValue = getValueFromPath(actor, pathToValue);

  // checks which mouse button were clicked 1(left), 2(middle), 3(right)
  let newValue = which === 3 
    ? _switchMastery(currentValue, true) 
    : _switchMastery(currentValue);

  actor.update({[pathToValue] : newValue});
}

/**
 * Changes value of actor's language mastery.
 */
function toggleLanguageMastery(key, which, actor) {
  let currentValue = actor.system.languages[key].languageMastery;
  let pathToValue = `system.languages.${key}.languageMastery`;
  
  // checks which mouse button were clicked 1(left), 2(middle), 3(right)
  let newValue = which === 3 
    ? _switchLanguageMastery(currentValue, true) 
    : _switchLanguageMastery(currentValue);

    actor.update({[pathToValue] : newValue});
}

/**
 * Changes value of actor's skill skillMastery.
 */
function toggleExpertise(pathToValue, which, actor) {
  let currentValue = getValueFromPath(actor, pathToValue);

  // checks which mouse button were clicked 1(left), 2(middle), 3(right)
  let newValue = which === 3 
    ? _switchExpertise(currentValue, true) 
    : _switchExpertise(currentValue);

  actor.update({[pathToValue] : newValue});
}

/**
 * Returns mastery value to be used in calculation formulas.
 * 
 * @param {string} skillMasteryKey	Key of skill mastery
 * @returns {number}	Mastery value for given key             
 */
function skillMasteryValue(skillMasteryKey) {
	switch (skillMasteryKey) {
		case "novice":
			return 2;
		case "trained":
			return 4;
		case "expert":
			return 6;
		case "master":
			return 8;
		case "grandmaster":
			return 10;
	}
	return 0;
}

function skillPointsSpendForMastery(skillMasteryKey) {
	switch (skillMasteryKey) {
		case "novice":
			return 1;
		case "trained":
			return 2;
		case "expert":
			return 3;
		case "master":
			return 4;
		case "grandmaster":
			return 5;
	}
	return 0;
}

function _switchMastery(skillMasteryKey, goDown) {
	switch (skillMasteryKey) {
		case "":
			return goDown ? "grandmaster" : "novice";
		case "novice":
			return goDown ? "" : "trained";
		case "trained":
			return goDown ? "novice" : "expert";
		case "expert":
			return goDown ? "trained" : "master";
		case "master":
			return goDown ? "expert" : "grandmaster";
		case "grandmaster":
			return goDown ? "master" : "";
	}
}

function _switchLanguageMastery(languageMasteryKey, goDown) {
	if (languageMasteryKey === 2) return goDown ? 1 : 0;
	if (languageMasteryKey === 0) return goDown ? 2 : 1;
	if (goDown) return languageMasteryKey - 1;
	return languageMasteryKey + 1;
}

function _switchExpertise(expertise, goDown) {
	if (expertise === 3) return goDown ? 2 : 0;
	if (expertise === 0) return goDown ? 3 : 1;
	if (goDown) return expertise - 1;
	return expertise + 1;
}

function addCustomSkill(actor) {
	const skillKey = generateKey();
	const skill = {
		label: "New Skill (Int)",
		modifier: 0,
		baseAttribute: "int",
		bonus: 0,
		skillMastery: "",
		knowledgeSkill: true,
		custom: true,
		expertise: 0
	};
	actor.update({[`system.skills.${skillKey}`] : skill});
}

function removeCustomSkill(skillKey, actor) {
	actor.update({[`system.skills.-=${skillKey}`]: null });
}

function addCustomLanguage(actor) {
	const languageKey = generateKey();
	const language = {
		label: "New Language",
		languageMastery: 0,
		custom: true
	};
	actor.update({[`system.languages.${languageKey}`] : language});
}

function removeCustomLanguage(languageKey, actor) {
	actor.update({[`system.languages.-=${languageKey}`]: null });
}

function convertSkillPoints(actor, from, to, opertaion, rate) {
	const skillFrom = actor.system.skillPoints[from];
	const skillTo = actor.system.skillPoints[to];
	
	if (opertaion === "convert") {
		const updateData = {
			[`system.skillPoints.${from}.converted`]: skillFrom.converted + 1,
			[`system.skillPoints.${to}.extra`]: skillTo.extra + parseInt(rate)
		};
		actor.update(updateData);
	}
	if (opertaion === "revert") {
		const newExtra = skillFrom.extra - parseInt(rate);
		if (newExtra < 0) {
			ui.notifications.error("Cannot revert more points!");
			return;
		}
		const updateData = {
			[`system.skillPoints.${from}.extra`]: newExtra,
			[`system.skillPoints.${to}.converted`]: skillTo.converted - 1 
		};
		actor.update(updateData);
	}
}

const DC20RPG = {};

/***********************/
/****  TRANSLATION  ****/
/***********************/

DC20RPG.trnAttributes  = {
  "mig": "DC20RPG.AttributeMig",
  "agi": "DC20RPG.AttributeAgi",
  "int": "DC20RPG.AttributeInt",
  "cha": "DC20RPG.AttributeCha"
};

DC20RPG.trnSkills = {
  "awa": "DC20RPG.SkillAwa",

  "ath": "DC20RPG.SkillAth",
  "inm": "DC20RPG.SkillInm",

  "acr": "DC20RPG.SkillAcr",
  "tri": "DC20RPG.SkillTri",
  "ste": "DC20RPG.SkillSte",

  "inv": "DC20RPG.SkillInv",
  "med": "DC20RPG.SkillMed",
  "sur": "DC20RPG.SkillSur",

  "ani": "DC20RPG.SkillAni",
  "ins": "DC20RPG.SkillIns",
  "inf": "DC20RPG.SkillInf",

  "nat": "DC20RPG.SkillNat",
  "his": "DC20RPG.SkillHis",
  "arc": "DC20RPG.SkillArc",
  "rel": "DC20RPG.SkillRel",
  "occ": "DC20RPG.SkillOcc",

  "alc": "DC20RPG.SkillAlc",
  "bla": "DC20RPG.SkillBla",
  "bre": "DC20RPG.SkillBre",
  "cap": "DC20RPG.SkillCap",
  "car": "DC20RPG.SkillCar",
  "coo": "DC20RPG.SkillCoo",
  "cry": "DC20RPG.SkillCry",
  "dis": "DC20RPG.SkillDis",
  "gam": "DC20RPG.SkillGam",
  "gla": "DC20RPG.SkillGla",
  "her": "DC20RPG.SkillHer",
  "ill": "DC20RPG.SkillIll",
  "jew": "DC20RPG.SkillJew",
  "loc": "DC20RPG.SkillLoc",
  "lea": "DC20RPG.SkillLea",
  "mas": "DC20RPG.SkillMas",
  "mus": "DC20RPG.SkillMus",
  "scu": "DC20RPG.SkillScu",
  "the": "DC20RPG.SkillThe",
  "tin": "DC20RPG.SkillTin",
  "wea": "DC20RPG.SkillWea",
  "veh": "DC20RPG.SkillVeh"
};

DC20RPG.trnLanguages = {
  "com": "DC20RPG.LangCom",
  "hum": "DC20RPG.LangHum",
  "dwa": "DC20RPG.LangDwa",
  "elv": "DC20RPG.LangElv",
  "gno": "DC20RPG.LangGno",
  "hal": "DC20RPG.LangHal",
  "gia": "DC20RPG.LangGia",
  "dra": "DC20RPG.LangDra",
  "orc": "DC20RPG.LangOrc",
  "fey": "DC20RPG.LangFey",
  "ele": "DC20RPG.LangEle",
  "cel": "DC20RPG.LangCel",
  "fie": "DC20RPG.LangFie",
  "dee": "DC20RPG.LangDee"
};

DC20RPG.trnReductions = {
    "acid": "DC20RPG.Acid",
    "cold": "DC20RPG.Cold",
    "fire": "DC20RPG.Fire",
    "force": "DC20RPG.Force",
    "holy": "DC20RPG.Holy",
    "lightning": "DC20RPG.Lightning",
    "poison": "DC20RPG.Poison",
    "psychic": "DC20RPG.Psychic",
    "sonic": "DC20RPG.Sonic",
    "unholy": "DC20RPG.Unholy",
    "piercing": "DC20RPG.Piercing",
    "slashing": "DC20RPG.Slashing",
    "bludgeoning": "DC20RPG.Bludgeoning"
};



/*************************/
/****  CONFIGURATION  ****/
/*************************/

DC20RPG.combatMastryLevels = {
  "novice": "Novice",
  "trained": "Trained",
  "expert": "Expert",
  "master": "Master",
  "grandmaster": "Grandmaster"
};

DC20RPG.attributes = {
  "mig": "Might",
  "agi": "Agility",
  "int": "Inteligence",
  "cha": "Charisma"
};

DC20RPG.attributesWithPrime = {
  "prime": "Prime",
  ...DC20RPG.attributes
};

DC20RPG.saveTypes = {
  "phy": "Physical",
  "men": "Mental",
  ...DC20RPG.attributes
};

DC20RPG.dcCalculationTypes = {
  "spell": "Spellcasting",
  "martial": "Martial",
  "flat": "Flat",
  ...DC20RPG.attributes
};

DC20RPG.skills = {
  "awa": "Awareness",

  "ath": "Athletics",
  "inm": "Intimidation",

  "acr": "Acrobatics",
  "tri": "Trickery",
  "ste": "Stealth",

  "inv": "Investigation",
  "med": "Medicine",
  "sur": "Survival",

  "ani": "Animal",
  "ins": "Insight",
  "inf": "Influence",

  "nat": "Nature",
  "his": "History",
  "arc": "Arcana",
  "rel": "Religion",
  "occ": "Occultism"
};

DC20RPG.tradeSkills = {
  "alc": "Alchemy",
  "bla": "Blacksmithing",
  "bre": "Brewing",
  "cap": "Carpentry",
  "car": "Carving",
  "coo": "Cooking",
  "dis": "Disguise",
  "dra": "Drawing/Painting",
  "enc": "Encription/Encoding",
  "for": "Forgery",
  "gam": "Gaming Kit",
  "gla": "Glassblower",
  "hea": "Healer Kit",
  "her": "Herbalism",
  "jew": "Jeweler",
  "lea": "Leatherworker/Tailor",
  "loc": "Lockpicking",
  "mas": "Masonry",
  "mus": "Musician",
  "nav": "Navigation/Cartography",
  "per": "Performance",
  "pil": "Piloting",
  "poi": "Poisons",
  "pot": "Pottery",
  "scu": "Sculpting",
  "tin": "Tinkering"
};

DC20RPG.checks = {
  "att": "Attack Check",
  "spe": "Spell Check",
  "mar": "Martial Check",

  "awa": "Awareness Check",

  "ath": "Athletics Check",
  "inm": "Intimidation Check",

  "acr": "Acrobatics Check",
  "tri": "Trickery Check",
  "ste": "Stealth Check",

  "inv": "Investigation Check",
  "med": "Medicine Check",
  "sur": "Survival Check",

  "ani": "Animal Check",
  "ins": "Insight Check",
  "inf": "Influence Check",

  "nat": "Nature Check",
  "his": "History Check",
  "arc": "Arcana Check",
  "rel": "Religion Check",
  "occ": "Occultism Check"
};

DC20RPG.contests = {
  "phy": "Physical Save",
  "men": "Mental Save",
  "mig": "Might Save",
  "agi": "Agility Save",
  "int": "Inteligence Save",
  "cha": "Charisma Save",
  ...DC20RPG.checks
};

DC20RPG.sizes = {
  "tiny": "Tiny",
  "small": "Small",
  "medium": "Medium",
  "large": "Large",
  "huge": "Huge",
  "gargantuan": "Gargantuan"
};

DC20RPG.weaponCategories = {
  "axe": "Axe",
  "bow": "Bow",
  "chained": "Chained",
  "crossbow": "Crossbow",
  "hammer": "Hammer",
  "pick": "Pick",
  "spear": "Spear",
  "special": "Special",
  "staff": "Staff",
  "sword": "Sword",
  "fist": "Fist",
  "whip": "Whip"
};

DC20RPG.rarities = {
  "common": "Common",
  "uncommon": "Uncommon",
  "rare": "Rare",
  "veryRare": "Very Rare",
  "legendary": "Legendary"
};

DC20RPG.weaponTypes = {
  "light": "Light Weapon",
  "heavy": "Heavy Weapon"
};

DC20RPG.equipmentTypes = {
  "light": "Light Armor",
  "heavy": "Heavy Armor",
  "lshield": "Light Shield",
  "hshield": "Heavy Shield",
  "clothing": "Clothing",
  "trinket": "Trinket"
};

DC20RPG.consumableTypes = {
  "ammunition": "Ammunition",
  "food": "Food",
  "poison": "Poison",
  "potion": "Potion",
  "ammunition": "Ammunition",
  "rod": "Rod",
  "scroll": "Scroll",
  "wand": "Wand",
  "trinket": "Trinket"
};

DC20RPG.featureSourceTypes = {
  "class": "Class",
  "subclass": "Subclass",
  "talent": "Talent",
  "ancestry": "Ancestry",
  "background": "Background",
  "monster": "Monster Feature",
  "other": "Other"
};

DC20RPG.techniqueTypes = {
  "maneuver": "Maneuver",
  "technique": "Technique"
};

DC20RPG.spellTypes = {
  "cantrip": "Cantrip",
  "spell": "Spell",
  "ritual": "Ritual"
};

DC20RPG.spellLists = {
  "arcane": "Arcane",
  "divine": "Divine",
  "primal": "Primal"
};

DC20RPG.magicSchools = {
  "astromancy": "Astromancy",
  "chronomancy": "Chronomancy",
  "conjuration": "Conjuration",
  "destruction": "Destruction",
  "divination": "Divination",
  "enchantment": "Enchantment",
  "illusion": "Illusion",
  "necromancy": "Necromancy",
  "protection": "Protection",
  "restoration": "Restoration",
  "transmutation": "Transmutation"
};

DC20RPG.components = {
  "verbal": "Verbal",
  "somatic": "Somatic",
  "material": "Material"
};

DC20RPG.spellTags = {
  "fire": "Fire",
  "water": "Water",
  "gravity": "Gravity"
};

DC20RPG.invidualTargets = {
  "self": "Self",
  "ally": "Ally",
  "enemy": "Enemy",
  "creature": "Creature",
  "object": "Object",
  "space": "Space"
};

DC20RPG.areaTypes = {
  "arc": "Arc",
  "aura": "Aura",
  "cone": "Cone",
  "cube": "Cube",
  "cylinder": "Cylinder",
  "line": "Line",
  "radius": "Radius",
  "sphere": "Sphere",
  "wall": "Wall",
};

DC20RPG.durations = {
  "instantaneous": "Instantaneous",
  "continuous": "Continuous",
  "concentration": "Concentration"
};

DC20RPG.attackTypes = {
  "attack": "Attack",
  "spell": "Spell"
};

DC20RPG.timeUnits = {
  "turns": "Turns",
  "rounds": "Rounds",
  "minutes": "Minutes",
  "hours": "Hours",
  "days": "Days",
  "months": "Months",
  "years": "Years",
  "permanent": "Permanent",
  "untilCanceled": "Until Canceled"
};

DC20RPG.restTypes = {
  "quick": "Quick Rest",
  "short": "Short Rest",
  "long": "Long Rest",
  "full": "Full Rest"
};

DC20RPG.resetTypes = {
  ...DC20RPG.restTypes,
  "round": "Round End",
  "combat": "Combat End",
};

DC20RPG.chargesResets = {
  ...DC20RPG.resetTypes,
  "day": "Daily",
  "charges": "Charges"
};

DC20RPG.actionTypes = {
  "dynamic": "Dynamic Attack Save",
  "attack": "Attack",
  "check": "Check",
  "save": "Save",
  "contest": "Contest",
  "other": "Other"
};

DC20RPG.damageTypes = {
  "acid": "Acid",
  "bludgeoning": "Bludgeoning",
  "cold": "Cold",
  "fire": "Fire",
  "force": "Force",
  "holy": "Holy",
  "lightning": "Lightning",
  "piercing": "Piercing",
  "poison": "Poison",
  "psychic": "Psychic",
  "slashing": "Slashing",
  "sonic": "Sonic",
  "unholy": "Unholy"
};

DC20RPG.healingTypes = {
  "heal": "Health",
  "temporary": "Temporary",
  "max": "Max Health"
};

DC20RPG.currencyTypes = {
  "pp": "PP",
  "gp": "GP",
  "sp": "SP",
  "cp": "CP"
};

DC20RPG.properties = {
  "agiDis": "Agi Check DisADV",
  "ammo": "Ammunition",
  "attunement": "Attunement",
  "concealable": "Concealable",
  "finesee": "Finesee",
  "focus": "Focus",
  "reach": "Reach",
  "requirement": "Requirement",
  "reload": "Reload",
  "special": "Special",
  "thrown": "Thrown",
  "twoHanded": "Two Handed",
  "versatile": "Versatile",
  "speedPenalty": "Speed Penalty",
  "sturdy": "Sturdy",
  "maxAgiLimit": "Max Agility Limit",
  "damageReduction": "Damage Reduction",
  "dense": "Dense",
  "mobile": "Mobile",
  "impact": "Impact",
  "threatening": "Threatening",
  "reinforced": "Reinforced",
  "mounted": "Mounted",
  "unwieldy": "Unwieldy"
};

DC20RPG.inventoryTypes = {
  "weapon": "Weapon",
  "equipment": "Equipment",
  "consumable": "Consumable",
  "tool": "Tool",
  "loot": "Loot"
};

DC20RPG.spellsTypes = {
  "spell": "Spell"
};

DC20RPG.techniquesTypes = {
  "technique": "Technique"
};

DC20RPG.featuresTypes = {
  "feature": "Feature"
};

DC20RPG.allItemTypes = {
  ...DC20RPG.inventoryTypes,
  ...DC20RPG.spellsTypes,
  ...DC20RPG.techniquesTypes,
  ...DC20RPG.featuresTypes,
  "class": "Class",
  "subclass": "Subclass",
  "ancestry": "Ancestry",
  "background": "Background"
};

DC20RPG.physicalDefenceFormulasLabels = {
  "standard": "Standard",
  "savage": "Savage Defense",
  "patient": "Patient Defense",
  "custom": "Custom Formula",
  "flat": "Flat",
  "standardMaxAgi": "Max Agility Limit"
};

DC20RPG.physicalDefenceFormulas = {
  "standard": "8 + @combatMastery + @agi + @defences.physical.armorBonus",
  "savage": "8 + @combatMastery + max(@mig, @agi) + @prime",
  "patient": "8 + @combatMastery + @agi + @prime",
  "standardMaxAgi": "8 + @combatMastery + min(@agi, (@prime - 2)) + @defences.physical.armorBonus",
};

DC20RPG.mentalDefenceFormulasLabels = {
  "standard": "Standard Formula",
  "custom": "Custom Formula",
  "patient": "Patient Defense",
  "flat": "Flat"
};

DC20RPG.mentalDefenceFormulas = {
  "standard": "8 + @combatMastery + @int + @cha",
  "patient": "8 + @combatMastery + @int + @cha + @prime"
};

DC20RPG.masteries = {
  "lightWeapon": "Light Weapon",
  "heavyWeapon": "Heavy Weapon",
  "lightShield": "Light Shield",
  "heavyShield": "Heavy Shield",
  "lightArmor": "Light Armor",
  "heavyArmor": "Heavy Armor",
  "spellcasting": "Spellcasting"
};

DC20RPG.defences = {
  "mental": "Mental",
  "physical": "Physical"
};

DC20RPG.conditions = {
  "charmed": "Charmed",
  "burning": "Burning",
  "bleeding": "Bleeding",
  "poisoned": "Poisoned",
  "taunted": "Taunted",
  "deafened": "Deafened",
  "blinded": "Blinded",
  "intimidated": "Intimidated",
  "rattled": "Rattled",
  "frightened": "Frightened",
  "slowed": "Slowed",
  "grapple": "Grapple",
  "exposed": "Exposed",
  "hindered": "Hindered",
  "restrained": "Restrained",
  "prone": "Prone",
  "incapacitated": "Incapacitated",
  "stunned": "Stunned",
  "paralyzed": "Paralyzed",
  "unconscious": "Unconscious",
  "petrified": "Petrified",
  "surprised": "Surprised",
  "doomed": "Doomed",
  "exhaustion": "Exhaustion",
  "impared": "Impared",
  "dazed": "Dazed"
};

function makeCalculations(actor) {
	_combatMatery(actor);
	_coreAttributes(actor);
	_skillModifiers(actor);
	_attackModAndSaveDC(actor);

	if (actor.type === "character") {
		_maxHp(actor);
		_maxMana(actor);
		_maxStamina(actor);
		_maxGrit(actor);

		_skillPoints(actor);
	}
	_currentHp(actor);

	_vision(actor);
	_movement(actor);
	_jump(actor);

	_physicalDefence(actor);
	_mentalDefence(actor);
	_damageReduction(actor);
	_deathsDoor(actor);
}

function _combatMatery(actor) {
  const level = actor.system.details.level;
  actor.system.details.combatMastery = Math.ceil(level/2);
}

function _coreAttributes(actor) {
	const exhaustion = actor.system.exhaustion;
	const attributes = actor.system.attributes;
	const details = actor.system.details;

	let primeAttrKey = "mig";
	for (let [key, attribute] of Object.entries(attributes)) {
		let save = attribute.saveMastery ? details.combatMastery : 0;
		save += attribute.value + attribute.bonuses.save - exhaustion;
		attribute.save = save;

		const check = attribute.value + attribute.bonuses.check - exhaustion;
		attribute.check = check;

		if (attribute.value >= attributes[primeAttrKey].value) primeAttrKey = key;
	}
	details.primeAttrKey = primeAttrKey;
	attributes.prime = foundry.utils.deepClone(attributes[primeAttrKey]);
}

function _skillModifiers(actor) {
	const exhaustion = actor.system.exhaustion;
	const attributes = actor.system.attributes;

	// Calculate skills modifiers
	for (let [key, skill] of Object.entries(actor.system.skills)) {
		skill.modifier = attributes[skill.baseAttribute].value + skillMasteryValue(skill.skillMastery) + skill.bonus + (2 * skill.expertise) - exhaustion;
	}

	// Calculate trade skill modifiers
	if (actor.type === "character") {
		for (let [key, skill] of Object.entries(actor.system.tradeSkills)) {
			skill.modifier = attributes[skill.baseAttribute].value + skillMasteryValue(skill.skillMastery) + skill.bonus + (2 * skill.expertise) - exhaustion;
		}
	}
}

function _attackModAndSaveDC(actor) {
	const exhaustion = actor.system.exhaustion;
	const prime = actor.system.attributes.prime.value;
	const CM = actor.system.details.combatMastery;
	const hasSpellcastingMastery = actor.system.masteries.spellcasting;
	const CmOrZero = hasSpellcastingMastery ? CM : 0;

	// Attack Modifier
	const attackMod = actor.system.attackMod;
	const mod = attackMod.value;
	if (!attackMod.flat) {
		mod.martial = prime + CM + attackMod.bonus.martial;
		mod.spell = prime + CmOrZero + attackMod.bonus.spell;
	}
	mod.martial -= exhaustion;
	mod.spell -= exhaustion;

	// Save DC
	const saveDC = actor.system.saveDC;
	const save = saveDC.value;
	if (!saveDC.flat) {
		save.martial = 8 + prime + CM + saveDC.bonus.martial;
		save.spell = 8 + prime + CmOrZero + saveDC.bonus.spell;
	}
	save.martial -= exhaustion;
	save.spell -= exhaustion;
}

function _maxHp(actor) {
	const details = actor.system.details;
	const health = actor.system.resources.health;
	const might = actor.system.attributes.mig.value;
	const hpFromClass = details.class.maxHpBonus || 0;
	
	health.max = 6 + details.level + might + hpFromClass + health.bonus;
}

function _maxMana(actor) {
	const details = actor.system.details;
	const mana = actor.system.resources.mana;
	const prime = actor.system.attributes.prime.value;
	const manaFromClass = details.class.bonusMana || 0;
	
	mana.max = (details.spellcaster ? prime : 0) + manaFromClass + mana.bonus;
}

function _maxStamina(actor) {
	const details = actor.system.details;
	const stamina = actor.system.resources.stamina;
	const staminaFromClass = details.class.bonusStamina || 0;

	stamina.max = staminaFromClass + stamina.bonus;
}

function _maxGrit(actor) {
	const grit = actor.system.resources.grit;
	const charisma = actor.system.attributes.cha.value;
	grit.max = 2 + charisma;
}

function _skillPoints(actor) {
	const int = actor.system.attributes.int.value;
	const spentPoints = _collectSpentPoints(actor);
	Object.entries(actor.system.skillPoints).forEach(([key, type]) => {
		if (key === "skill") type.max += int;
		type.max += type.extra;
		type.spent += spentPoints[key] + type.converted;
	});
}

function _collectSpentPoints(actor) {
	const actorSkills = actor.system.skills;
	const actorTrades = actor.system.tradeSkills;
	const actorLanguages = actor.system.languages;
	const collected = {
		skill: 0,
		trade: 0,
		knowledge: 0,
		language: 0,
		expertise: 0
	};

	Object.values(actorSkills)
		.filter(skill => skill.skillMastery !== "")
		.forEach(skill => {
			if (skill.expertise) collected.expertise++;
			if (skill.knowledgeSkill) collected.knowledge += skillPointsSpendForMastery(skill.skillMastery);
			else collected.skill += skillPointsSpendForMastery(skill.skillMastery);
		});

	Object.values(actorTrades)
		.filter(skill => skill.skillMastery !== "")
		.forEach(skill => {
			if (skill.expertise) collected.expertise++;
			collected.trade += skillPointsSpendForMastery(skill.skillMastery);
		});

	Object.entries(actorLanguages)
		.filter(([key, lang]) => key !== "com")
		.filter(([key, lang]) => lang.languageMastery !== 0)
		.forEach(([key, lang]) => {
			collected.language += lang.languageMastery;
		});

	return collected;
}

function _currentHp(actor) {
	const health = actor.system.resources.health;
	health.value = health.current + health.temp;
}

function _vision(actor) {
	const visionTypes = actor.system.vision;

	visionTypes.darkvision.value = visionTypes.darkvision.range + visionTypes.darkvision.bonus; 
	visionTypes.tremorsense.value = visionTypes.tremorsense.range + visionTypes.tremorsense.bonus; 
	visionTypes.blindsight.value = visionTypes.blindsight.range + visionTypes.blindsight.bonus; 
	visionTypes.truesight.value = visionTypes.truesight.range + visionTypes.truesight.bonus; 
}

function _movement(actor) {
	const exhaustion = actor.system.exhaustion;
	const movements = actor.system.movement;

	const groundSpeed = movements.speed.value + movements.speed.bonus - exhaustion;
	movements.speed.current = groundSpeed > 0 ? groundSpeed : 0;
	for (const [key, movement] of Object.entries(movements)) {
		if (key === "speed") continue;
		
		if (actor.type === "character") {
			if (movement.hasSpeed) {
				movement.current = groundSpeed + movement.bonus;
			}
			else {
				const speed = movement.bonus - exhaustion;
				movement.current = speed > 0 ? speed : 0;
			}
		}
		else {
			movement.current = movement.value + movement.bonus - exhaustion;
		}
	}
}

function _jump(actor) {
	const jump = actor.system.jump;
	const attribute = actor.system.attributes[jump.attribute].value;
	jump.value = (attribute >= 1 ? attribute : 1) + jump.bonus;
}

function _physicalDefence(actor) {
	const pd = actor.system.defences.physical;
	if (pd.formulaKey !== "flat") {
		const formula = pd.formulaKey === "custom" ? pd.customFormula : DC20RPG.physicalDefenceFormulas[pd.formulaKey];
		pd.normal = evaulateDicelessFormula(formula, actor.getRollData()).total;
	}
	
	// Calculate Hit Thresholds
	pd.value = pd.normal + pd.bonus;
	pd.heavy = pd.value + 5;
	pd.brutal = pd.value + 10;
}

function _mentalDefence(actor) {
	const md = actor.system.defences.mental;
	if (md.formulaKey !== "flat") {
		const formula = md.formulaKey === "custom" ? md.customFormula : DC20RPG.mentalDefenceFormulas[md.formulaKey];
		md.normal = evaulateDicelessFormula(formula, actor.getRollData()).total;
	}
	
	// Calculate Hit Thresholds
	md.value = md.normal + md.bonus;
	md.heavy = md.value + 5;
	md.brutal = md.value + 10;
}

function _damageReduction(actor) {
	const dmgReduction = actor.system.damageReduction;
	dmgReduction.pdr.value = dmgReduction.pdr.number + dmgReduction.pdr.bonus;
	dmgReduction.mdr.value = dmgReduction.mdr.number + dmgReduction.mdr.bonus;
}

function _deathsDoor(actor) {
	const death = actor.system.death;
	const currentHp = actor.system.resources.health.current;
	const prime = actor.system.attributes.prime.value;

	const treshold = -prime + death.doomed - death.bonus;
	death.treshold = treshold < 0 ? treshold : 0;
	if (currentHp <= 0) death.active = true;
	else death.active = false;
}

/**
 * Copies some data from actor's items to make it easier to access it later.
 */
function prepareDataFromItems(actor) {
	if (actor.type === "character") {
		_background(actor);
		_class(actor);
		_ancestry(actor);
		_subclass(actor);
	}
	_equipment(actor);
	_tools(actor);
	_activeEffects(actor);
}

function _background(actor) {
	const details = actor.system.details;
	const skillPoints = actor.system.skillPoints;

	const background = actor.items.get(details.background.id);
	if (!background) return;

	skillPoints.skill.max = background.system.skillPoints || 0;
	skillPoints.trade.max = background.system.tradePoints || 0;
	skillPoints.language.max = background.system.langPoints || 0;
}

function _class(actor) {
	const details = actor.system.details;
	const skillPoints = actor.system.skillPoints;
	const restPoints =  actor.system.rest.restPoints;
	const actorMasteries = actor.system.masteries;
  const scaling = actor.system.scaling;

	const clazz = actor.items.get(details.class.id);
	if (!clazz) return;

  // Level and Rest Points
  const level = clazz.system.level;
	details.level = level;
	restPoints.max = level;

  // Resources for Given Level
	details.class.maxHpBonus = clazz.system.scaling.maxHpBonus.values[level - 1];
  details.class.bonusMana = clazz.system.scaling.bonusMana.values[level - 1];
  details.class.bonusStamina = clazz.system.scaling.bonusStamina.values[level - 1];

  // Custom Resources for Given Level
  Object.entries(clazz.system.scaling)
    .filter(([key, sca]) => !sca.core)
    .forEach(([key, sca]) => scaling[key] = sca.values[level - 1]);

  // Class Category
  details.martial = clazz.system.martial;
	details.spellcaster = clazz.system.spellcaster;

	// Masteries
	Object.entries(clazz.system.masteries).forEach(([key, mastery]) => actorMasteries[key] = mastery);

	// Skill Points from class 
	skillPoints.skill.max += clazz.system.scaling.skillPoints.values[level - 1];
	skillPoints.trade.max += clazz.system.scaling.tradePoints.values[level - 1];
}

function _ancestry(actor) {
	const details = actor.system.details;
	const movement = actor.system.movement;

	const ancestry = actor.items.get(details.ancestry.id);
	if (!ancestry) return;

	details.size = ancestry.system.size;
	movement.speed.value = ancestry.system.movement.speed;
}

function _subclass(actor) {
	const details = actor.system.details;

	const subclass = actor.items.get(details.subclass.id);
	if (!subclass) return;
}

function _equipment(actor) {
	let equippedArmorBonus = 0;
	let damageReduction = 0;
	let maxAgiLimit = false;
	let speedPenalty = false;

	actor.items
		.filter(item => item.type === 'equipment')
		.forEach(item => {
			equippedArmorBonus += _getArmorBonus(item);
			damageReduction += _getDamageReduction(item);
			if (!maxAgiLimit) maxAgiLimit = _checkMaxAgiLimit(item);
			if (!speedPenalty) speedPenalty = _checkSpeedPenalty(item);
		});
	
	const defences = actor.system.defences;
	if (maxAgiLimit) defences.physical.formulaKey = "standardMaxAgi";
	if (speedPenalty)  actor.system.movement.speed.value -= 1;
	defences.physical.armorBonus = equippedArmorBonus;
	actor.system.damageReduction.pdr.number += damageReduction;
}

function _tools(actor) {
	actor.items
		.filter(item => item.type === 'tool')
		.forEach(item => {
			const tradeSkillKey = item.system.tradeSkillKey;
			const rollBonus = item.system.rollBonus;
			if (tradeSkillKey) {
				const bonus = rollBonus ? rollBonus : 0;
				actor.system.tradeSkills[tradeSkillKey].bonus += bonus;
			}
		});
}

function _activeEffects(actor) {
	const equippedEffects = [];
	const attunedEffects = [];
	const activableEffects = [];

	actor.items.forEach(item => {
		// Activable Effects
		const hasEffects = item.system.activableEffect?.hasEffects;
		if (hasEffects) activableEffects.push(item);

		// Equipped and Attuned Items Effects
		const hasStatuses = item.system.statuses;
		const hasAttunement = item.system.properties?.attunement.active;
		if (hasStatuses && hasAttunement) attunedEffects.push(item); 
		else if (hasStatuses) equippedEffects.push(item);
	});

	_activableEffects(activableEffects, actor);
	_equippedEffects(equippedEffects, actor);
	_attunedEffects(attunedEffects, actor);
}

function _activableEffects(items, actor) {
	items.forEach(item => {
		const activableEffect = item.system.activableEffect;
		const origin = `Actor.${actor._id}.Item.${item._id}`;
		actor.effects.forEach(effect => {
			if(effect.origin === origin) effect.update({["disabled"]: !activableEffect.active});
		});
	});
}

function _equippedEffects(items, actor) {
	items.forEach(item => {
		const statuses = item.system.statuses;
		const origin = `Actor.${actor._id}.Item.${item._id}`;
		actor.effects.forEach(effect => {
			if(effect.origin === origin) effect.update({["disabled"]: !statuses.equipped});
		});
	});
}

function _attunedEffects(items, actor) {
	items.forEach(item => {
		const statuses = item.system.statuses;
		const equippedAndAttuned = statuses.equipped && statuses.attuned;
		const origin = `Actor.${actor._id}.Item.${item._id}`;
		actor.effects.forEach(effect => {
			if(effect.origin === origin) effect.update({["disabled"]: !equippedAndAttuned});
		});
	});
}

function _getArmorBonus(item) {
  if (!item.system.statuses.equipped) return 0;
  return item.system.armorBonus ? item.system.armorBonus : 0;
}

function _checkMaxAgiLimit(item) {
	if (!item.system.statuses.equipped) return 0;
	return item.system.properties.maxAgiLimit.active;
}

function _checkSpeedPenalty(item) {
	if (!item.system.statuses.equipped) return 0;
	return item.system.properties.speedPenalty.active;
}

function _getDamageReduction(item) {
  if (!item.system.statuses.equipped) return 0;
  const hasReduction = item.system.properties.damageReduction.active;
  const reductionValue = item.system.properties.damageReduction.value ? item.system.properties.damageReduction.value : 0;
  return hasReduction ? reductionValue : 0;
}

function initFlags(actor) {
  if (!actor.flags.dc20rpg) actor.flags.dc20rpg = {};

	const flags = actor.flags.dc20rpg;
	if (flags.showUnknownSkills === undefined) flags.showUnknownSkills = true;
	if (flags.showUnknownTradeSkills === undefined) flags.showUnknownTradeSkills = false;
	if (flags.showUnknownLanguages === undefined) flags.showUnknownLanguages = false;
	if (flags.showEmptyReductions === undefined) flags.showEmptyReductions = false;
	if (flags.showEmptyConditions === undefined) flags.showEmptyConditions = false;

	// Header Ordering (to be repleaced with different implementation)
	if (actor.type === 'character') _initializeFlagsForCharacter(actor);
	else _initializeFlagsForNpc(actor);
}

function _initializeFlagsForCharacter(actor) {
	const coreFlags = actor.flags.dc20rpg;
	// Flags describing item table headers ordering
	if (coreFlags.headersOrdering === undefined) { 
		coreFlags.headersOrdering = {
			inventory: {
				Weapons: 0,
				Equipment: 1,
				Consumables: 2,
				Tools: 3,
				Loot: 4
			},
			features: {
				Features: 0
			},
			techniques: {
				Techniques: 0
			},
			spells: {
				Spells: 0
			}
		};
	}
}

function _initializeFlagsForNpc(actor) {
	const coreFlags = actor.flags.dc20rpg;
	// Flags describing item table headers ordering
	if (coreFlags.headersOrdering === undefined) { 
		coreFlags.headersOrdering = {
			items: {
				Actions: 0,
				Features: 1,
				Techniques: 2,
				Inventory: 3,
				Spells: 4,
			}
		};
	}
}

function prepareRollData(actor, data) {
  _attributes(data);
  _details(data);
  _mods(data, actor);
	return data;
}

function _attributes(data) {
	// Copy the attributes to the top level, so that rolls can use
	// formulas like `@mig + 4` or `@prime + 4`
	if (data.attributes) {
		for (let [key, attribute] of Object.entries(data.attributes)) {
			data[key] = foundry.utils.deepClone(attribute.value);
		}
	}
}

function _details(data) {
	// Add level for easier access, or fall back to 0.
	if (data.details.level) {
		data.lvl = data.details.level ?? 0;
	}
	if (data.details.combatMastery) {
		data.combatMastery = data.details.combatMastery ?? 0;
	}
}

function _mods(data, actor) {
	const attackMod = actor.system.attackMod.value;
	if (attackMod.martial) {
		data.attack = attackMod.martial;
		
		if (data.combatMastery) data.attackNoCM = data.attack - data.combatMastery; // Used for rolls when character has no mastery in given weapon
		else data.attackNoCM = data.attack;
	}
	if (attackMod.spell) {
		data.spell = attackMod.spell;
	}
}

/**
 * Extend the base Actor document by defining a custom roll data structure which is ideal for the Simple system.
 * @extends {Actor}
 */
class DC20RpgActor extends Actor {

  /** @override */
  prepareData() {
    // Prepare data for the actor. Calling the super version of this executes
    // the following, in order: 
    // 1) data reset (to clear active effects),
    // 2) prepareBaseData(),
    // 3) prepareEmbeddedDocuments() (including active effects),
    // 4) prepareDerivedData().
    super.prepareData();
  }

  prepareBaseData() {
    super.prepareBaseData();
    initFlags(this);
  }

  prepareEmbeddedDocuments() {
    prepareDataFromItems(this);
    super.prepareEmbeddedDocuments();
  }

  /**
   * @override
   * This method collects calculated data (non editable on charcter sheet) that isn't defined in template.json
   */
  prepareDerivedData() {
    makeCalculations(this);
    this._prepareCustomResources();
    this.prepared = true; // Mark actor as prepared
  }

  /** @override */
  getRollData() { 
    // We want to operate on copy of original data because we are making some changes to it
    const data = foundry.utils.deepClone(super.getRollData());   
    return prepareRollData(this, data);
  }

  /**
   * Returns object containing items owned by actor that have charges or are consumable.
   */
  getOwnedItemsIds(excludedId) {
    const excludedTypes = ["class", "subclass", "ancestry", "background", "loot", "tool"];

    const itemsWithCharges = {};
    const consumableItems = {};
    const weapons = {};
    const items = this.items;
    items.forEach(item => {
      if (item.id !== excludedId && !excludedTypes.includes(item.type)) {
        const maxChargesFormula = item.system.costs.charges.maxChargesFormula;
        if (maxChargesFormula) itemsWithCharges[item.id] = item.name; 
        if (item.type === "consumable") consumableItems[item.id] = item.name;
        if (item.type === "weapon") weapons[item.id] = item.name;
      }
    });
    return {
      withCharges: itemsWithCharges,
      consumable: consumableItems,
      weapons: weapons
    }
  }

  _prepareCustomResources() {
    const customResources = this.system.resources.custom;

    // remove empty custom resources and calculate its max charges
    for (const [key, resource] of Object.entries(customResources)) {
      if (!resource.name) delete customResources[key];
      resource.max = resource.maxFormula ? evaulateDicelessFormula(resource.maxFormula, this.getRollData()).total : 0;
    }
  }
}

/**
 * Extend the basic Item with some very simple modifications.
 * @extends {Item}
 */
class DC20RpgItem extends Item {

  /**
   * Augment the basic Item data model with additional dynamic data.
   */
  prepareData() {
    // As with the actor class, items are documents that can have their data
    // preparation methods overridden (such as prepareBaseData()).
    super.prepareData();
  }

  prepareDerivedData() {

    if (['weapon', 'equipment', 'consumable', 'feature', 'technique', 'spell'].includes(this.type)) {
      this._prepareCoreRoll();
      this._prepareMaxChargesAmount();
      this._prepareDC();
      this._prepareDCForEnhancements();
    }
    if (this.type === "weapon") this._prepareTableName("Weapons");
    if (this.type === "equipment") this._prepareTableName("Equipment");
    if (this.type === "consumable") this._prepareTableName("Consumables");
    if (this.type === "tool") this._prepareTableName("Tools");
    if (this.type === "loot") this._prepareTableName("Loot");
    if (this.type === "feature") this._prepareTableName("Features");
    if (this.type === "technique") this._prepareTableName("Techniques");
    if (this.type === "spell") this._prepareTableName("Spells");
  }

  /**
   * Prepare a data object which is passed to any Roll formulas which are created related to this Item
   * @private
   */
  async getRollData() {
    const systemData = foundry.utils.deepClone(this.system);
 
    // Grab the item's system data.
    let rollData = {
      ...systemData,
      rollBonus: systemData.attackFormula?.rollBonus
    };

    const actor = await this.actor;
    // If present, add the actor's roll data.
    if (actor) {
      rollData = {...rollData, ...actor.getRollData()};
    }

    return rollData;
  }

//=========================================
//=           Prepare Item Data           =
//=========================================
  async _prepareCoreRoll() {
    const system = this.system;
    const attackFormula = system.attackFormula;
    
    // Prepare formula
    if (attackFormula.overriden) {
      attackFormula.formula = attackFormula.overridenFormula;
    } else {
      let calculationFormula = "d20";

      // determine if it is a spell or attack check
      if (attackFormula.checkType === "attack") {
        if (system.attackFormula.combatMastery) calculationFormula += " + @attack";
        else calculationFormula += " + @attackNoCM";
      }
      else if (attackFormula.checkType === "spell") calculationFormula += " + @spell";

      if (system.attackFormula.rollBonus) calculationFormula +=  " + @rollBonus";
      attackFormula.formula = calculationFormula;
    }

    // Calculate roll modifier for formula
    const rollData = await this.getRollData();
    attackFormula.rollModifier = attackFormula.formula ? evaulateDicelessFormula(attackFormula.formula, rollData).total : 0;
  }

  async _prepareDCForEnhancements() {
    const enhancements = this.system.enhancements;
    if (!enhancements) return;

    const actor = await this.actor;
    for (const enh of Object.values(enhancements)) {
      if (enh.modifications.overrideSave) {
        const save = enh.modifications.save;
        if (save.calculationKey === "flat") continue;
        if (actor) save.dc = this._calculateSaveDC(save, actor);
        else save.dc = null;
      }
    }
  }

  async _prepareDC() {
    const save = this.system.save;
    if (save.calculationKey === "flat") return;

    const actor = await this.actor;
    if (!actor) {
      save.dc = null;
      return;
    }
    
    save.dc = this._calculateSaveDC(save, actor);
  }

  _calculateSaveDC(save, actor) {
    const saveDC = actor.system.saveDC;
    switch (save.calculationKey) {
      case "martial":
        return saveDC.value.martial;
      case "spell":
        return saveDC.value.spell; 
      default:
        let dc = 8;
        const key = save.calculationKey;
        dc += actor.system.attributes[key].value;
        if (save.addMastery) dc += actor.system.details.combatMastery;
        return dc;
    }
  }

  async _prepareMaxChargesAmount() {
    const charges = this.system.costs.charges;
    const rollData = await this.getRollData();
    charges.max = charges.maxChargesFormula ? evaulateDicelessFormula(charges.maxChargesFormula, rollData).total : null;    
  }

  _prepareTableName(fallbackName) {
    let tableName = this.system.tableName;
    if (!tableName || tableName.trim() === "") this.system.tableName = fallbackName;
  }
}

class DC20RpgCombatant extends Combatant {

  constructor(data, combat) {
    super(data, combat);
    this.canRollInitiative = this.actor.type === "character";
  }

  prepareData() {
    super.prepareData();
    if (!this.actor.prepared) this.actor.prepareData();
  }

  rememberDataset(dataset) {
    this.initiativeDataset = dataset;
  }

  getRemeberedDataset() {
    if (this.initiativeDataset) return this.initiativeDataset;
    else ui.notifications.error("Initative formula for that combatant was not yet chosen. Please roll initiative from character sheet!");    
  }
}

//============================================
//              Item Usage Costs             =
//============================================
/**
 * Return item costs data formatted to be used in html files.
 */
function getItemUsageCosts(item, actor) {
  if (!item.system.costs) return {};
  const usageCosts = {};
  usageCosts.resources = _getItemResources(item, actor);
  usageCosts.otherItem = _getOtherItem(item, actor);
  return usageCosts;
}

function _getItemResources(item, actor) {
  const resourcesCosts = item.system.costs.resources;

  let counter = 0;
  let costs = {
    actionPoint: {cost: resourcesCosts.actionPoint},
    stamina: {cost: resourcesCosts.stamina},
    mana: {cost: resourcesCosts.mana},
    health: {cost: resourcesCosts.health},
    custom: {}
  };
  counter += resourcesCosts.actionPoint ? resourcesCosts.actionPoint : 0;
  counter += resourcesCosts.stamina ? resourcesCosts.stamina : 0;
  counter += resourcesCosts.mana ? resourcesCosts.mana : 0;
  counter += resourcesCosts.health ? resourcesCosts.health : 0;

  if (actor) {
    const customResources = actor.system.resources.custom;

    Object.entries(resourcesCosts.custom).forEach(([key, customCost]) => {
      if (customResources[key]) {
        counter += customCost ? customCost : 0;
  
        const imgSrc = customResources[key].img;
        const name = customResources[key].name;
  
        costs.custom[key] = {
          imgSrc: imgSrc,
          name: name,
          cost: customCost
        };
      }
    });
  }

  return {
    counter: counter,
    costs: costs
  };
}

function _getOtherItem(item, actor) {
  const otherItem = item.system.costs.otherItem;
  if(!actor) return {};

  const usedItem = actor.items.get(otherItem.itemId);
  if (!usedItem) return {};

  return {
    amount: otherItem.amountConsumed,
    consumeCharge: otherItem.consumeCharge,
    name: usedItem.name,
    image: usedItem.img,
  }
}

//============================================
//          Resources Manipulations          =
//============================================
function subtractAP(actor, amount) {
  if (_canSubtractBasicResource("ap", actor, amount)) {
    subtractBasicResource("ap", actor, amount);
    return true;
  }
  return false;
}

function refreshAllActionPoints(actor) {
  let max = actor.system.resources.ap.max;
  actor.update({["system.resources.ap.value"] : max});
}

function subtractBasicResource(key, actor, amount) {
  amount = parseInt(amount);
  if (amount <= 0) return;

  const current = actor.system.resources[key].value;
  const newAmount = current - amount;

  actor.update({[`system.resources.${key}.value`] : newAmount});
}

function regainBasicResource(key, actor, amount) {
  amount = parseInt(amount);
  if (amount <= 0) return;

  const valueKey = key === "health" ? "current" : "value";
  const current = actor.system.resources[key][valueKey];
  const newAmount = current + amount;

  actor.update({[`system.resources.${key}.${valueKey}`] : newAmount});
}

//===========================================
//        Item Charges Manipulations        =
//===========================================
function changeCurrentCharges(value, item) {
  let changedValue = parseInt(value);
  let maxCharges = parseInt(item.system.costs.charges.max);
  if (isNaN(changedValue)) changedValue = 0;
  if (changedValue < 0) changedValue = 0;
  if (changedValue > maxCharges) changedValue = maxCharges;
  item.update({["system.costs.charges.current"] : changedValue});
}

//=============================================
//        Item Usage Costs Subtraction        =
//=============================================
/**
 * Checks if all resources used by item are available for actor. 
 * If so subtracts those from actor current resources.
 */
function respectUsageCost(actor, item, configured) {
  if (!item.system.costs) return true;
  let basicCosts = item.system.costs.resources;
  if (configured) basicCosts = _costsAndEnhancements(actor, item);

  if(_canSubtractAllResources(actor, item, basicCosts) && _canSubtractFromOtherItem(actor, item)) {
    _subtractAllResources(actor, item, basicCosts);
    _subtractFromOtherItem(actor, item);
    return true;
  }
  return false;
}

function _costsAndEnhancements(actor, item) {
  let enhancements = item.system.enhancements;
  const usesWeapon = item.system.usesWeapon;
  if (usesWeapon) {
    const weapon = actor.items.get(usesWeapon);
    if (weapon) {
      enhancements = {
        ...enhancements,
        ...weapon.system.enhancements
      };
    }
  }
  
  let costs = foundry.utils.deepClone(item.system.costs.resources);
  if (!enhancements) return costs;

  for (let [key, enhancement] of Object.entries(enhancements)) {
    if (enhancement.number) {
      for (let [key, resource] of Object.entries(enhancement.resources)) {
        costs[key] += enhancement.number * resource;
      }
    }
  }

  return costs;
}

function _canSubtractAllResources(actor, item, costs) {
  let canSubtractAllResources = [
    _canSubtractBasicResource("ap", actor, costs.actionPoint),
    _canSubtractBasicResource("stamina", actor, costs.stamina),
    _canSubtractBasicResource("mana", actor, costs.mana),
    _canSubtractBasicResource("health", actor, costs.health),
    _canSubtractCustomResources(actor, costs.custom),
    _canSubtractCharge(item, 1),
    _canSubtractQuantity(item, 1),
  ];
  return arrayOfTruth(canSubtractAllResources);
}

function _subtractAllResources(actor, item, costs) {
  const oldResources = actor.system.resources;

  let newResources = _copyResources(oldResources);
  newResources = _prepareBasicResourceToSubtraction("ap", costs.actionPoint, newResources);
  newResources = _prepareBasicResourceToSubtraction("stamina", costs.stamina, newResources);
  newResources = _prepareBasicResourceToSubtraction("mana", costs.mana, newResources);
  newResources = _prepareBasicResourceToSubtraction("health", costs.health, newResources);
  newResources = _prepareCustomResourcesToSubtraction(costs.custom, newResources);
  _subtractActorResources(actor, newResources);
  _subtractCharge(item, 1);
  _subtractQuantity(item, 1);
}

function _subtractActorResources(actor, newResources) {
  actor.update({['system.resources'] : newResources});
}

function _copyResources(old) {
  const nev = {
    ap: {},
    stamina: {},
    mana: {},
    health: {},
    grit: {},
    custom: {}
  };

  // Standard Resources
  for (const [key, resource] of Object.entries(old)) {
    if(key === "custom") continue;
    if(key === "health") nev[key].current = resource.current;
    nev[key].value = resource.value;
  }

  // Custom Resources
  for (const [key, resource] of Object.entries(old.custom)) {
    if (!nev.custom[key]) nev.custom[key] = {}; // If no object with key found create new object
    nev.custom[key].value = resource.value;
  }
  
  return nev;
}

//================================
//        Basic Resources        =
//================================
function _canSubtractBasicResource(key, actor, cost) {
  if (cost <= 0) return true;

  const resources = actor.system.resources;
  const current = key === "health" ? resources[key].current : resources[key].value;
  const newAmount = current - cost;

  if (newAmount < 0) {
    let errorMessage = `Cannot subract ${cost} ${key} from ${actor.name}. Not enough ${key} (Current amount: ${current}).`;
    ui.notifications.error(errorMessage);
    return false;
  }
  
  return true;
}

function _prepareBasicResourceToSubtraction(key, cost, newResources) {
  if (cost <= 0) return newResources;

  if(key === "health") newResources[key].current -= cost;
  newResources[key].value -= cost;

  return newResources;
}

//=================================
//        Custom Resources        =
//=================================
function _canSubtractCustomResources(actor, customCosts) {
  const customResources = actor.system.resources.custom;

  for (const [key, cost] of Object.entries(customCosts)) {
    if (!customResources[key]) continue;
    if (cost <= 0) continue;

    const current = customResources[key].value;
    const newAmount = current - cost;
  
    if (newAmount < 0) {
      let errorMessage = `Cannot subract ${cost} charges of custom resource with key '${key}' from ${actor.name}. Current amount: ${current}.`;
      ui.notifications.error(errorMessage);
      return false;
    }
  }

  return true;
}

function _prepareCustomResourcesToSubtraction(customCosts, newResources) {
  const customResources = newResources.custom;

  for (const [key, cost] of Object.entries(customCosts)) {
    if (!customResources[key]) continue;
    if (cost <= 0) continue;

    const current = customResources[key].value;
    const newAmount = current - cost;

    newResources.custom[key].value = newAmount;
  }

  return newResources;
}

//===============================
//        Item Resources        =
//===============================
function _canSubtractFromOtherItem(actor, item) {
  const otherItemUsage = item.system.costs.otherItem;
  if (!otherItemUsage.itemId) return true;

  const otherItem = actor.items.get(otherItemUsage.itemId);
  if (!otherItem) {
    let errorMessage = `Item used by ${item.name} doesn't exist.`;
    ui.notifications.error(errorMessage);
    return false;
  }

  return otherItemUsage.consumeCharge 
    ? _canSubtractCharge(otherItem, otherItemUsage.amountConsumed) 
    : _canSubtractQuantity(otherItem, otherItemUsage.amountConsumed);
}

function _subtractFromOtherItem(actor, item) {
  const otherItemUsage = item.system.costs.otherItem;
  if (otherItemUsage.itemId) {
    const otherItem = actor.items.get(otherItemUsage.itemId);
    otherItemUsage.consumeCharge 
     ? _subtractCharge(otherItem, otherItemUsage.amountConsumed) 
     : _subtractQuantity(otherItem, otherItemUsage.amountConsumed);
  }
}

function _canSubtractCharge(item, subtractedAmount) {
  let max = item.system.costs.charges.max;
  if (!max) return true;

  let current = item.system.costs.charges.current;
  let newAmount = current - subtractedAmount;

  if (newAmount < 0) {
    let errorMessage = `Cannot use ${item.name}. No more charges.`;
    ui.notifications.error(errorMessage);
    return false;
  }
  return true;
}

function _subtractCharge(item, subtractedAmount) {
  let max = item.system.costs.charges.max;
  if (!max) return;

  let current = item.system.costs.charges.current;
  let newAmount = current - subtractedAmount;

  item.update({["system.costs.charges.current"] : newAmount});
}

function _canSubtractQuantity(item, subtractedAmount) {
  if (item.type !== "consumable") return true; // It is not consumable
  if (!item.system.consume) return true; // It doesn't consume item on use

  let current = item.system.quantity;
  let newAmount = current - subtractedAmount;

  if (current <= 0) {
    let errorMessage = `Cannot use ${item.name}. No more items.`;
    ui.notifications.error(errorMessage);
    return false;
  }

  if (newAmount < 0) {
    let errorMessage = `Cannot use ${item.name}. No enough items.`;
    ui.notifications.error(errorMessage);
    return false;
  }

  return true;
}

function _subtractQuantity(item, subtractedAmount) {
  if (item.type !== "consumable") return;
  if (!item.system.consume) return;

  let deleteOnZero = item.system.deleteOnZero;
  let current = item.system.quantity;
  let newAmount = current - subtractedAmount;

  if (newAmount === 0 && deleteOnZero) {
    item.delete();
  } 
  else {
    item.update({["system.quantity"] : newAmount});
  }
}

function getStatusById(id) {
  return CONFIG.statusEffects.find(status => status.id === id);
}

async function addStatusWithIdToActor(actor, id) {
  const status = getStatusById(id);
  if (actor.isToken) {
    const tokens = actor.getActiveTokens();
    tokens.forEach(token => token.toggleEffect(status, { active: true }));
  }
  else {
    const tokenDoc = await actor.getTokenDocument();
    tokenDoc.toggleActiveEffect(status, { active: true });
  }
}

async function removeStatusWithIdFromActor(actor, id) {
  const status = getStatusById(id);
  if (actor.isToken) {
    const tokens = actor.getActiveTokens();
    tokens.forEach(token => token.toggleEffect(status, { active: false }));
  }
  else {
    const tokenDoc = await actor.getTokenDocument();
    tokenDoc.toggleActiveEffect(status, { active: false });
  }
}

//=============================================
//              CUSTOM RESOURCES              =
//=============================================
function createCustomResourceFromScalingValue(key, scalingValue, actor) {
  const maxFormula = `@scaling.${key}`;
  const newResource = {
    name: scalingValue.label,
    img: "icons/svg/item-bag.svg",
    value: 0,
    maxFormula: maxFormula,
    max: 0,
    reset: scalingValue.reset
  };
  actor.update({[`system.resources.custom.${key}`] : newResource});
}

function createNewCustomResource(name, actor) {
  const customResources = actor.system.resources.custom;
  const newResource = {
    name: name,
    img: "icons/svg/item-bag.svg",
    value: 0,
    maxFormula: null,
    max: 0,
    reset: ""
  };

  // Generate key (make sure that key does not exist already)
  let resourceKey = "";
  do {
    resourceKey = generateKey();
  } while (customResources[resourceKey]);

  actor.update({[`system.resources.custom.${resourceKey}`] : newResource});
}

function removeResource(resourceKey, actor) {
  actor.update({[`system.resources.custom.-=${resourceKey}`]: null });
}

function changeResourceIcon(event, actor) {
  const key = event.detail.key;
  const newSrc = event.detail.newSrc;
  actor.update({[`system.resources.custom.${key}.img`] : newSrc});
}

function addObserverToCustomResources(html) {
  const resourceIcons = html.find('.resource-icon').toArray();
  resourceIcons.forEach(icon => _applyObserver(icon));
}

function _applyObserver(icon) {
  // Create a new MutationObserver instance
  const observer = new MutationObserver((mutationsList) => {
    for (const mutation of mutationsList) {
      if (mutation.type === 'attributes' && mutation.attributeName === 'src') {
        const newSrcValue = icon.src;
        const key = $(icon).data('key');
        const srcWithoutOrigin = newSrcValue.replace(origin + "/",'');
        const eventData = {
          newSrc: srcWithoutOrigin, 
          key: key
        };

        const event = new CustomEvent('imageSrcChange', {detail: { ...eventData }});
        icon.dispatchEvent(event); // Emit the custom event
    }
  }});

  // Start observing the 'attributes' mutations on the target node
  observer.observe(icon, { attributes: true });
}

//=============================================
//             HP THRESHOLD CHECK              =
//=============================================
function runHealthThresholdsCheck(oldHp, newHp, maxHp, actor) {
  const bloodiedThreshold = Math.floor(maxHp/2);
  const wellBloodiedThreshold = Math.floor(maxHp/4);
  const deathThreshold = actor.type === "character" ? actor.system.death.treshold : 0;
  
  _checkStatus("bloodied1", oldHp, newHp, bloodiedThreshold, actor);
  _checkStatus("bloodied2", oldHp, newHp, wellBloodiedThreshold, actor);
  _checkStatus("dead", oldHp, newHp, deathThreshold, actor);
  return {
    system: _checkDeathsDoor(oldHp, newHp, actor)
  };
}

function _checkStatus(statusId, oldHp, newHp, treshold, actor) {
  // Add status
  if (oldHp > treshold && newHp <= treshold) addStatusWithIdToActor(actor, statusId);
  // Remove status
  if (oldHp <= treshold && newHp > treshold) removeStatusWithIdFromActor(actor, statusId);
}

function _checkDeathsDoor(oldHp, newHp, actor) {
  if (actor.type !== "character") return {}; // Only PC have death's door

  // Was on Death's Doors and it ended
  if (oldHp <= 0 && newHp > 0) {
    return {
      death: {
        stable: true,
        active: false,
      }
    }
  }

  // Wasn't on Death's Doors and got there
  if (oldHp > 0 && newHp <= 0) {
    const currentExhaustion = actor.system.exhaustion;
    const newExhaustion = currentExhaustion !== 6 ? currentExhaustion + 1 : 6;
    return {
      exhaustion: newExhaustion,
      death: {
        stable: false,
        active: true,
      }
    }
  }

  return {};
}

async function getSelectedTokens() {
  if (canvas.activeLayer === canvas.tokens) return canvas.activeLayer.placeables.filter(p => p.controlled === true);
}

function updateActorHp(actor, updateData) {
  if (updateData.system && updateData.system.resources && updateData.system.resources.health) {
    const newHealth = updateData.system.resources.health;
    const actorsHealth = actor.system.resources.health;
    const maxHp = actorsHealth.max;
    const currentHp = actorsHealth.current;
    const tempHp = actorsHealth.temp || 0;

    // When value (temporary + current hp) was changed
    if (newHealth.value !== undefined) {
      const newValue = newHealth.value;
      const oldValue = actorsHealth.value;
  
      if (newValue >= oldValue) {
        const newCurrentHp = Math.min(newValue - tempHp, maxHp);
        const newTempHp = newValue - newCurrentHp > 0 ? newValue - newCurrentHp : null;
        newHealth.current = newCurrentHp;
        newHealth.temp = newTempHp;
        newHealth.value = newCurrentHp + newTempHp;
      }
  
      else {
        const valueDif = oldValue - newValue;
        const remainingTempHp = tempHp - valueDif;
        if (remainingTempHp <= 0) { // It is a negative value we want to subtract from currentHp
          newHealth.temp = null;
          newHealth.current = currentHp + remainingTempHp; 
          newHealth.value = currentHp + remainingTempHp;
        }
        else {
          newHealth.temp = remainingTempHp;
          newHealth.value = currentHp + remainingTempHp;
        }
      }
    }

    // When only temporary HP was changed
    else if (newHealth.temp !== undefined) {
      newHealth.value = newHealth.temp + currentHp;
    }

    // When only current HP was changed
    else if (newHealth.current !== undefined) {
      newHealth.current = newHealth.current >= maxHp ? maxHp : newHealth.current;
      newHealth.value = newHealth.current + tempHp;
    }

    if (newHealth.current !== undefined) {
      const tresholdData = runHealthThresholdsCheck(currentHp, newHealth.current, maxHp, actor);
      foundry.utils.mergeObject(updateData, tresholdData);
    }
    updateData.system.resources.health = newHealth;
  }
  return updateData;
}

/**
 * Called when new actor is being created, makes simple pre-configuration on actor's prototype token depending on its type.
 */
function preConfigurePrototype(actor) {
  const prototypeToken = actor.prototypeToken;
  prototypeToken.displayBars = 20;
  prototypeToken.displayName = 20;
  if (actor.type === "character") {
    prototypeToken.actorLink = true;
    prototypeToken.disposition = 1;
  }
  actor.update({['prototypeToken'] : prototypeToken});
}

/**
 * Returns dataset extracted from event's currentTarget.
 * Also calls preventDefault method on event.
 */
function datasetOf(event) {
  event.preventDefault();
  return event.currentTarget.dataset;
}

/**
 * Returns value of event's currentTarget.
 * Also calls preventDefault method on event.
 */
function valueOf(event) {
  event.preventDefault();
  return event.currentTarget.value;
}

//===========================================
//         SENDING MESSAGES TO CHAT         =
//===========================================
/**
 * Creates chat message.
 * 
 * @param {DC20RpgActor} actor  - Speaker.
 * @param {Object} details      - Informations about labels, descriptions and other details.
 */
function descriptionMessage(actor, details) {
  const templateSource = "systems/dc20rpg/templates/chat/description-chat-message.hbs";
  _createChatMessage(actor, details, templateSource, {});
}

/**
 * Creates chat message for given rolls.
 * 
 * @param {Object} rolls        - Separated in 3 categories: coreRolls (Array of Rolls), formulaRolls (Array of Rolls), winningRoll (Roll).
 * @param {DC20RpgActor} actor  - Speaker.
 * @param {Object} details      - Informations about labels, descriptions and other details.
 */
function sendRollsToChat(rolls, actor, details) {
  const isCrit = rolls.winningRoll?.crit || false;
  const isCritFail = rolls.winningRoll?.fail || false;
  const targets = details.collectTargets ? _checkIfAttackHitsTargets(details.rollTotal, details.targetDefence, isCrit, isCritFail) : [];
  const templateData = {
    ...details,
    roll: rolls.winningRoll,
    rolls: rolls,
    winTotal: rolls.winningRoll?._total || 0,
    amountOfCoreRolls: rolls.core.length,
    targets: targets
  };
  const templateSource = "systems/dc20rpg/templates/chat/roll-chat-message.hbs";
  _createChatMessage(actor, templateData, templateSource, rolls);
}

async function _createChatMessage(actor, data, templateSource, rolls) {
  const templateData = {
    ...data
  };
  const template = await renderTemplate(templateSource, templateData);
  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: actor }),
    rollMode: game.settings.get('core', 'rollMode'),
    content: template,
    rolls: _rollsObjectToArray(rolls),
    sound: CONFIG.sounds.dice,
  });
}

function _rollsObjectToArray(rolls) {
  const array = [];
  if (rolls.core) rolls.core.forEach(roll => array.push(roll));
  if (rolls.formula) {
    rolls.formula.forEach(roll => {
      array.push(roll.clear);
      array.push(roll.modified);
    });
  }
  return array;
}

function _checkIfAttackHitsTargets(rollTotal, defenceKey, isCrit, isCritFail) {
  const targets = [];
  game.user.targets.forEach(token => targets.push(_tokenToTarget(token, rollTotal, defenceKey, isCrit, isCritFail)));
  return targets;
}

function _tokenToTarget(token, rollTotal, defenceKey, critHit, critMiss) {
  const actor = token.actor;
  const target = {
    name: actor.name,
    img: actor.img
  };
  
  const defence = actor.system.defences[defenceKey].value;
  const hit = rollTotal - defence;
  if (hit < 0)                target.outcome = "Miss";
  if (hit >= 0 && hit < 5)    target.outcome = "Hit";
  if (hit >= 5 && hit < 10)   target.outcome = "Heavy Hit";
  if (hit >= 10 && hit < 15)  target.outcome = "Brutal Hit";
  if (hit >= 15)              target.outcome = "Brutal Hit(+)";

  // Determine Crit Miss 
  if (critMiss)               target.outcome = "Critical Miss";

  // Determine Crit Hit 
  if (critHit && hit < 5)     target.outcome = "Critical Hit";
  if (critHit && hit >= 5)    target.outcome = "Critical " + target.outcome;

  // Mark as Miss
  if (hit < 0 || critMiss)    target.miss = true;

  return target;
}

//================================================
//         CUSTOM CHAT MESSAGE LISTENERS         =
//================================================
function initChatMessage(message, html, data) {
  // Registering listeners for chat log
  _addChatListeners(html);
  html.find('.formula-roll').first().before("<hr>");
}

function _addChatListeners(html) {
  // Show/Hide description
  html.find('.show-hide-description').click(event => {
    event.preventDefault();
    const description = event.target.closest(".chat-roll-card").querySelector(".chat-description");
    if(description) description.classList.toggle('hidden');
  });

  html.find('.toggle-formula-roll-type').click(event => {
    event.preventDefault();
    event.stopPropagation();
    const formulaId = event.currentTarget.dataset.formulaId;
    const wrapper = _parentWithClass(event.currentTarget, "same-formula-wrapper");
    wrapper.querySelectorAll(`[data-id="${formulaId}"]`).forEach(formula => formula.classList.toggle('hidden'));
  });
  html.find('.roll-save').click(event => _callOnTokens(event, "save"));
  html.find('.roll-check').click(event => _callOnTokens(event, "check"));
  html.find('.applicable').click(event => _callOnTokens(event, datasetOf(event).type));
}

function _parentWithClass(element, className) {
  let parent = element.parentNode;
  while (parent) {
    if (parent.classList.contains(className)) {
      return parent;
    }
    parent = parent.parentNode;
  }
  // If no parent with the specified class is found, return null
  return null;
}

//================================================
//              TOKEN MANIPULATIONS              =
//================================================
async function _callOnTokens(event, type) {
  event.preventDefault();
  event.stopPropagation();
  const dataset = event.currentTarget.dataset;
  const selectedTokens = await getSelectedTokens();
  if (selectedTokens.length === 0) return;

  selectedTokens.forEach(async (token) => {
    const actor = await token.actor;
    switch (type) {
      case "save": _rollSave(actor, dataset); break;
      case "check": _rollCheck(actor, dataset); break;
      case "dmg": _applyDamage(actor, dataset); break;
      case "heal": _applyHealing(actor, dataset); break;
    }
  });
}

function _rollSave(actor, dataset) {
  const key = dataset.key;
  let save = "";

  switch (key) {
    case "phy": 
      const migSave = actor.system.attributes.mig.save;
      const agiSave = actor.system.attributes.agi.save;
      save = migSave >= agiSave ? migSave : agiSave;
      break;
    
    case "men": 
      const intSave = actor.system.attributes.int.save;
      const chaSave = actor.system.attributes.cha.save;
      save = intSave >= chaSave ? intSave : chaSave;
      break;

    default:
      save = actor.system.attributes[key].save;
      break;
  }

  const details = {
    roll: `d20 + ${save}`,
    label: getLabelFromKey(key, DC20RPG.saveTypes) + " Save",
    type: "save",
    against: parseInt(dataset.dc)
  };
  rollFromSheet(actor, details);
}

function _rollCheck(actor, dataset) {
  const key = dataset.key;
  if (["phy", "men", "mig", "agi", "int", "cha"].includes(key)) {
    dataset.dc = dataset.against;      // For saves we want to roll against dynamic DC provided by contest 
    _rollSave(actor, dataset);
    return;
  }
  let modifier = "";
  let rollType = "";

  switch (key) {
    case "att":
      modifier = actor.system.attackMod.value.martial;
      rollType = "attackCheck";
      break;

    case "spe":
      modifier = actor.system.attackMod.value.spell;
      rollType = "spellCheck";
      break;

    case "mar": 
      const acrModifier = actor.system.skills.acr.modifier;
      const athModifier = actor.system.skills.ath.modifier;
      modifier = acrModifier >= athModifier ? acrModifier : athModifier;
      rollType = "skillCheck";
      break;

    default:
      modifier = actor.system.skills[key].modifier;
      rollType = "skillCheck";
      break;
  } 

  const details = {
    roll: `d20 + ${modifier}`,
    label: getLabelFromKey(key, DC20RPG.checks),
    type: rollType,
    against: parseInt(dataset.against)
  };
  rollFromSheet(actor, details);
}

function _applyHealing(actor, dataset) {
  const healAmount = parseInt(dataset.heal);
  const healType = dataset.healType;
  const health = actor.system.resources.health;
  let source = dataset.source;

  switch (healType) {
    case "heal": 
      const oldCurrent = health.current;
      let newCurrent = health.current + healAmount;

      if (health.max <= newCurrent) {
        source += ` -> (Overheal <b>${newCurrent - health.max}</b>)`;
        newCurrent = health.max;
      }
      actor.update({["system.resources.health.current"]: newCurrent});
      _createHealChatMessage(actor, newCurrent - oldCurrent, source);
      break;
    case "temporary":
      const oldTemp = health.temp || 0;
      const newTemp = oldTemp + healAmount;
      actor.update({["system.resources.health.temp"]: newTemp});
      _createTempHPChatMessage(actor, newTemp - oldTemp, source);
      break;
    case "max":
      const newMax = (health.tempMax ? health.tempMax : 0) + healAmount;
      actor.update({["system.resources.health.tempMax"]: newMax});
      break;
  }
}

function _applyDamage(actor, dataset) {
  const dmgType = dataset.dmgType;
  const defenceKey = dataset.defence;
  const isCritHit = dataset.crit === "true";
  const isCritMiss = dataset.miss === "true";
  const halfDmgOnMiss = dataset.halfOnMiss === "true";
  const health = actor.system.resources.health;
  const damageReduction = actor.system.damageReduction;

  let dmg = {
    value: parseInt(dataset.dmg),
    source: dataset.source
  };
  let halfDmg = false;

  // True Damage is always applied as flat value
  if (dmgType === "true" || dmgType === "") {
    const newValue = health.value - dmg.value;
    actor.update({["system.resources.health.value"]: newValue});
    _createDamageChatMessage(actor, dmg.value, "True Damage");
    return;
  }

  
  // Attack Check specific calculations
  if (defenceKey) {
    const rollTotal = dataset.total ? parseInt(dataset.total) : null;
    const modified = dataset.modified === "true";
    const defence = actor.system.defences[defenceKey].value;
    const drKey = ["holy", "unholy", "sonic", "psychic"].includes(dmgType) ? "mdr" : "pdr";
    const dr = damageReduction[drKey].value;
    
    // Check if Attack Missed and if it should be zero or only halved
    const hit = rollTotal - defence;
    if (!isCritHit && (hit < 0 || isCritMiss)) {
      if (halfDmgOnMiss) {
        halfDmg = true;
      } 
      else {
        const message = isCritMiss ? "Critical Miss" : "Miss";
        _createDamageChatMessage(actor, 0, message);
        return;
      }
    }

    // Damage Reduction and Heavy/Brutal Hits
    dmg = _applyAttackCheckDamageModifications(dmg, modified, defence, rollTotal, dr);
  }

  // Vulnerability, Resistance and other
  const damageType = damageReduction.damageTypes[dmgType];
  dmg = _applyOtherDamageModifications(dmg, damageType);

  // Half the final dmg taken on miss 
  if (halfDmg) {
    dmg.source += ` - Miss(Half Damage)`;
    dmg.value = Math.ceil(dmg.value/2);  
  }

  const newValue = health.value - dmg.value;
  actor.update({["system.resources.health.value"]: newValue});
  _createDamageChatMessage(actor, dmg.value, dmg.source);
}

function _applyAttackCheckDamageModifications(dmg, modified, defence, rollTotal, dr) {
  if (rollTotal === null) return dmg;     // We want to check armor class only for attacks

  const hit = rollTotal - defence;
  const extraDmg = Math.max(Math.floor(hit/5), 0);
  // Apply damage reduction
  if (extraDmg === 0 && dr > 0) {
    dmg.source += " - Damage Reduction";
    dmg.value -= dr;
    return dmg; 
  }

  // Only modified rolls can apply Heavy Hit, Brutal Hit dmg
  if (!modified) return dmg;

  // Add dmg from Heavy Hit, Brutal Hit etc.
  if (extraDmg === 1) dmg.source += " + Heavy Hit";
  if (extraDmg === 2) dmg.source += " + Brutal Hit";
  if (extraDmg >= 3) dmg.source += ` + Brutal Hit(over ${extraDmg * 5})`;
  dmg.value += extraDmg;
  return dmg;  
}

function _applyOtherDamageModifications(dmg, damageType) {
  // STEP 1 - Adding & Subtracting
  // Resist X
  if (damageType.resist > 0) {
    dmg.source += ` - Resistance(${damageType.resist})`;
    dmg.value -= damageType.resist;
  }
  // Vulnerable X
  if (damageType.vulnerable > 0) {
    dmg.source += ` + Vulnerability(${damageType.vulnerable})`;
    dmg.value += damageType.vulnerable; 
  }
  dmg.value = dmg.value > 0 ? dmg.value : 0;

  // STEP 2 - Doubling & Halving
  // Immunity
  if (damageType.immune) {
    dmg.source = "Resistance(Immune)";
    dmg.value = 0;
    return dmg;
  }
  // Resistance and Vulnerability - cancel each other
  if (damageType.resistance && damageType.vulnerability) return dmg;
  // Resistance
  if (damageType.resistance) {
    dmg.source += ` - Resistance(Half)`;
    dmg.value = Math.ceil(dmg.value/2);  
  }
  // Vulnerability
  if (damageType.vulnerability) {
    dmg.source += ` + Vulnerability(Half)`;
    dmg.value = dmg.value * 2; 
  }

  return dmg;
}

//================================================
//           HP CHANGE CHAT MESSAGES             =
//================================================
function _createDamageChatMessage(actor, amount, source) {
  const color = "#780000";
  const icon = "fa-droplet";
  const text = `<i>${actor.name}</i> took <b>${amount}</b> damage.`;
  _createHpChangeMessage(color, icon, text, source);
}

function _createHealChatMessage(actor, amount, source) {
  const color = "#007802";
  const icon = "fa-heart";
  const text = `<i>${actor.name}</i> was healed by <b>${amount}</b> HP.`;
  _createHpChangeMessage(color, icon, text, source);
}

function _createTempHPChatMessage(actor, amount, source) {
  const color = "#707070";
  const icon = "fa-shield-halved";
  const text = `<i>${actor.name}</i> received <b>${amount}</b> temporary HP.`;
  _createHpChangeMessage(color, icon, text, source);
}

function _createHpChangeMessage(color, icon, text, source) {
  let sources = "";
  const shouldAddSources = game.settings.get("dc20rpg", "showSourceOfDamageOnChatMessage");
  if (shouldAddSources) sources = `<br><br><i class="fa-solid fa-calculator"></i> = ${source}.`;
  const content = `<div style="font-size: 16px; color: ${color};">
                    <i class="fa fa-solid ${icon}"></i> ${text} ${sources}
                  </div>`;

  const message = {
    content: content
  };
  const gmOnly = !game.settings.get("dc20rpg", "showDamageChatMessage");
  if (gmOnly) message.whisper = ChatMessage.getWhisperRecipients("GM");
  ChatMessage.create(message);
}

class DC20RpgRoll extends Roll {
  async evaluate({minimize=false, maximize=false, allowStrings=false, allowInteractive=true, ...options}={}) {
    if ( this._evaluated ) {
      throw new Error(`The ${this.constructor.name} has already been evaluated and is now immutable`);
    }
    this._evaluated = true;
    if ( CONFIG.debug.dice ) console.debug(`Evaluating roll with formula "${this.formula}"`);

    // Migration path for async rolls
    if ( "async" in options ) {
      foundry.utils.logCompatibilityWarning("The async option for Roll#evaluate has been removed. "
        + "Use Roll#evaluateSync for synchronous roll evaluation.");
    }
    return await this._evaluate({minimize, maximize, allowStrings, allowInteractive});
  }
}

//==========================================
//             Roll From Sheet             =
//==========================================
async function rollFromSheet(actor, details) {
  return await _rollFromFormula(details.roll, details, actor, true);
}

//==========================================
//            Roll From Actions            =
//==========================================
function rollFromAction(actor, action) {
  if (!subtractAP(actor, action.apCost)) return;

  const details = {
    label: action.name,
    image: actor.img,
    formulaLabel: action.label,
    sublabel: action.label,
    description: action.description,
    type: action.type
  };
  if (action.formula) return _rollFromFormula(action.formula, details, actor, true);
  else descriptionMessage(actor, details);
}

//==========================================
//           Roll For Initiative           =
//==========================================
function rollForInitiative(actor, details) {
  actor.rollInitiative({
    createCombatants: true,
    rerollInitiative: true,
    initiativeOptions: {
      formula: details.roll,
      label: details.label,
      type: details.type
    },
  });
}

/**
 * Creates new Roll instance from given formula. Returns result of that roll.
 * If roll was done with advantage or disadvantage only winning roll will be returned.
 * 
 * @param {String} formula      - Formula used to create roll.
 * @param {Object} details      - Object containing extra informations about that roll. Ex. type, description, label.
 * @param {DC20RpgActor} actor  - Actor which roll data will be used for creating that roll.
 * @param {Boolean} sendToChat  - If true, creates chat message showing rolls results.
 * @returns {Roll} Winning roll.
 */
async function _rollFromFormula(formula, details, actor, sendToChat) {
  const rollMenu = actor.system.rollMenu;
  const rollLevel = _determineRollLevel(rollMenu);
  const rollData = actor.getRollData();

  const globalMod = actor.system.globalFormulaModifiers[details.type] || "";
  const helpDices = _collectHelpDices(rollMenu);
  formula += " " + globalMod + helpDices;

  const rolls = {
    core: _prepareCoreRolls(formula, rollData, rollLevel, details.label)
  };
  await _evaluateRollsAndMarkCrits(rolls.core);
  rolls.winningRoll = _extractAndMarkWinningCoreRoll(rolls.core, rollLevel);

  // Prepare and send chat message
  if (sendToChat) {
    const label = details.label || `${actor.name} : Roll Result`;
    const rollTitle = details.formulaLabel || label;
    const messageDetails = {
      label: label,
      image: actor.img,
      description: details.description,
      against: details.against,
      rollTitle: rollTitle,
      actionType: "attack"
    };
    sendRollsToChat(rolls, actor, messageDetails);
  }
  return rolls.winningRoll;
}

//===================================
//          Roll From Item          =
//===================================
/**
 * Creates new Roll instances from given item formulas. Returns result of core formula.
 * If roll was done with advantage or disadvantage only winning roll will be returned.
 * 
 * @param {String} itemId       - The ID of the item from which the rolls will be created.
 * @param {DC20RpgActor} actor  - Actor which roll data will be used for creating those rolls.
 * @param {Boolean} sendToChat  - If true, creates chat message showing rolls results.
 * @returns {Roll} Winning roll.
 */
async function rollFromItem(itemId, actor, sendToChat) {
  const item = actor.items.get(itemId);
  if (!item) return;
  
  const rollMenu = item.system.rollMenu;
  const costsSubracted = rollMenu.free ? true : respectUsageCost(actor, item, true);
  if (!costsSubracted) return;

  const rollLevel = _determineRollLevel(rollMenu);
  const rollData = await item.getRollData();
  const actionType = item.system.actionType;
  const rolls = await _evaluateItemRolls(actionType, actor, item, rollData, rollLevel, rollMenu.versatile);
  rolls.winningRoll = _hasAnyRolls(rolls) ? _extractAndMarkWinningCoreRoll(rolls.core, rollLevel) : null;

  // Prepare and send chat message
  if (sendToChat) {
    const description = !item.system.statuses || item.system.statuses.identified
        ? item.system.description
        : "<b>Unidentified</b>";

    const messageDetails = {
      image: item.img,
      description: description,
      rollTitle: item.name,
      actionType: actionType,
    };
    
    // Details depending on action type
    if (["dynamic", "attack"].includes(actionType)) {
      const winningRoll = rolls.winningRoll;
      if (winningRoll.crit) _markCritFormulas(rolls.formula);

      const attackKey = item.system.attackFormula.checkType;
      messageDetails.label = getLabelFromKey(attackKey, DC20RPG.attackTypes) + " Check"; 
      messageDetails.rollTotal = winningRoll.total;
      messageDetails.targetDefence = item.system.attackFormula.targetDefence;
      messageDetails.halfDmgOnMiss = item.system.attackFormula.halfDmgOnMiss;
      // Flag indicating that when sending a chat message we should run check againts targets selected by this user
      messageDetails.collectTargets = game.settings.get("dc20rpg", "showTargetsOnChatMessage");
      messageDetails.saveDetails = _prepareDynamicSaveDetails(item, rolls.winningRoll);
    }
    if (["save"].includes(actionType)) {
      messageDetails.saveDetails = _prepareSaveDetails(item);
    }
    if (["check", "contest"].includes(actionType)) {
      const checkDetails = _prepareCheckDetails(item, rolls.winningRoll, rolls.formula);
      messageDetails.checkDetails = checkDetails;
      messageDetails.label = checkDetails.rollLabel;
    }
    sendRollsToChat(rolls, actor, messageDetails);
  }
  return rolls.winningRoll;
}

//=======================================
//           evaluate ROLLS             =
//=======================================
async function _evaluateItemRolls(actionType, actor, item, rollData, rollLevel, versatileRoll) {
  const attackRolls = await _evaluateAttackRolls(actionType, actor, item, rollData, rollLevel);
  const checkRolls = await _evaluateCheckRolls(actionType, actor, item, rollData, rollLevel);
  const coreRolls = [...attackRolls, ...checkRolls];

  const checkOutcome = actionType === "check" ? item.system.check.outcome : undefined;
  const formulaRolls = await _evaluateFormulaRolls(item, actor, rollData, versatileRoll, checkOutcome);
  return {
    core: coreRolls,
    formula: formulaRolls
  }
}

async function _evaluateAttackRolls(actionType, actor, item, rollData, rollLevel) {
  if (!["attack", "dynamic"].includes(actionType)) return []; // We want to create attack rolls only for few types of roll
  const helpDices = _collectHelpDices(item.system.rollMenu);
  const coreFormula = _prepareAttackFromula(actor, item.system.attackFormula, helpDices);
  const label = getLabelFromKey(actionType, DC20RPG.actionTypes);
  const coreRolls = _prepareCoreRolls(coreFormula, rollData, rollLevel, label);
  await _evaluateRollsAndMarkCrits(coreRolls, item.system.attackFormula.critThreshold);
  return coreRolls;
}

async function _evaluateFormulaRolls(item, actor, rollData, versatileRoll, checkOutcome) {
  const formulaRolls = _prepareFormulaRolls(item, actor, rollData, versatileRoll, checkOutcome);
  for (let i = 0; i < formulaRolls.length; i++) {
    const roll = formulaRolls[i];
    await roll.clear.evaluate();
    await roll.modified.evaluate();
  }
  return formulaRolls;
}

async function _evaluateCheckRolls(actionType, actor, item, rollData, rollLevel) {
  if (!["check", "contest"].includes(actionType)) return []; // We want to create check rolls only for few types of roll
  const checkKey = item.system.check.checkKey;
  const helpDices = _collectHelpDices(item.system.rollMenu);
  const checkFormula = _prepareCheckFormula(actor, checkKey, helpDices);
  const label = getLabelFromKey(checkKey, DC20RPG.checks) + " Check";
  const checkRolls = _prepareCoreRolls(checkFormula, rollData, rollLevel, label);
  await _evaluateRollsAndMarkCrits(checkRolls);
  if (actionType === "check") _determineCheckOutcome(checkRolls, item, rollLevel);
  return checkRolls;
}

function _determineCheckOutcome(rolls, item, rollLevel) {
  const check = item.system.check;
  const checkValue = _extractAndMarkWinningCoreRoll(rolls, rollLevel).total;
  if (checkValue < check.checkDC) check.outcome = -1;               // Check Failed
  else check.outcome = Math.floor((checkValue - check.checkDC)/5);  // Check succeed by 5 or more
}

async function _evaluateRollsAndMarkCrits(rolls, critThreshold) {
  if (!rolls) return;

  for (let i = 0; i < rolls.length; i++) {
    const roll = rolls[i];
    await roll.evaluate();
    roll.crit = false;
    roll.fail = false;

    // Only d20 can crit
    roll.terms.forEach(term => {
      if (term.faces === 20) {
        const fail = 1;
        const crit = critThreshold ? critThreshold : 20;

        term.results.forEach(result => {
          if (result.result >= crit) roll.crit = true;
          if (result.result === fail) roll.fail = true;
        });
      }
    });
  }
}

function _extractAndMarkWinningCoreRoll(coreRolls, rollLevel) {
  if (coreRolls.length === 0) return 0;
  let bestRoll;
  let bestTotal;

  if (coreRolls.length === 1) bestRoll = coreRolls[0];
  
  if (rollLevel < 0) {
    bestTotal = 999;
    coreRolls.forEach(coreRoll => {
      if (coreRoll._total < bestTotal) {
        bestRoll = coreRoll;
        bestTotal = coreRoll._total;
      }
    });
  }
  if (rollLevel > 0) {
    bestTotal = -999;
    coreRolls.forEach(coreRoll => {
      if (coreRoll._total > bestTotal) {
        bestRoll = coreRoll;
        bestTotal = coreRoll._total;
      }
    });
  }

  bestRoll.winner = true;
  return bestRoll;
}

//=======================================
//            PREPARE ROLLS             =
//=======================================
function _prepareCoreRolls(coreFormula, rollData, rollLevel, label) {
  let coreRolls = [];
  if (coreFormula) {
    // We want to create core rolls for every level of advanage/disadvantage
    for (let i = 0; i < Math.abs(rollLevel) + 1; i++) {
      const coreRoll = new DC20RpgRoll(coreFormula, rollData);
      coreRoll.coreFormula = true;
      coreRoll.label = label;
      coreRolls.push(coreRoll);
    }
  }
  return coreRolls;
}

function _prepareFormulaRolls(item, actor, rollData, versatileRoll, checkOutcome) { // TODO: Refactor this
  let formulas = item.system.formulas;
  let enhancements = item.system.enhancements;
  if (item.system.usesWeapon) {
    const wrapper = _getWeaponFormulasAndEnhacements(actor, item.system.usesWeapon);
    formulas = {...formulas, ...wrapper.formulas};
    enhancements = {...enhancements, ...wrapper.enhancements};
  }

  if (formulas) {
    const damageRolls = [];
    const healingRolls = [];
    const otherRolls = [];

    for (const [key, formula] of Object.entries(formulas)) {
      const isVerstaile = versatileRoll ? formula.versatile : false;
      const clearRollFromula = isVerstaile ? formula.versatileFormula : formula.formula; // formula without any modifications
      const modified = _modifiedRollFormula(formula, isVerstaile, checkOutcome, enhancements); // formula with all enhancements and each five applied
      const roll = {
        clear: new DC20RpgRoll(clearRollFromula, rollData),
        modified: new DC20RpgRoll(modified.rollFormula, rollData)
      };
      const commonData = {
        id: key,
        coreFormula: false,
        label: isVerstaile ? "(Versatile) " : "",
        category: formula.category
      };
      roll.clear.clear = true;
      roll.modified.clear = false;
      roll.clear.modifierSources = isVerstaile ? "Versatile Value" : "Standard Value";
      roll.modified.modifierSources = modified.modifierSources;

      switch (formula.category) {
        case "damage":
          let damageTypeLabel = getLabelFromKey(formula.type, DC20RPG.damageTypes);
          commonData.label += "Damage - " + damageTypeLabel;
          commonData.type = formula.type;
          commonData.typeLabel = damageTypeLabel;
          _fillCommonRollProperties(roll, commonData);
          damageRolls.push(roll);
          break;
        case "healing":
          let healingTypeLabel = getLabelFromKey(formula.type, DC20RPG.healingTypes);
          commonData.label += "Healing - " + healingTypeLabel;
          commonData.type = formula.type;
          commonData.typeLabel = healingTypeLabel;
          _fillCommonRollProperties(roll, commonData);
          healingRolls.push(roll);
          break;
        case "other":
          commonData.label += "Other";
          _fillCommonRollProperties(roll, commonData);
          otherRolls.push(roll);
          break;
      }
    }
    return [...damageRolls, ...healingRolls, ...otherRolls];
  }
  return [];
}

function _fillCommonRollProperties(roll, commonData) {
  return {
    clear: foundry.utils.mergeObject(roll.clear, commonData),
    modified: foundry.utils.mergeObject(roll.modified, commonData)
  };
}

function _getWeaponFormulasAndEnhacements(actor, itemId) {
  const item = actor.items.get(itemId);
  if (!item) return {formulas: {}, enhancements: {}};
  return {
    formulas: item.system.formulas, 
    enhancements: item.system.enhancements
  };
}

function _modifiedRollFormula(formula, isVerstaile, checkOutcome, enhancements) {
  // Choose formula depending on versatile option
  let rollFormula = isVerstaile ? formula.versatileFormula : formula.formula;
  let modifierSources = isVerstaile ? "Versatile Value" : "Standard Value";

  // If check faild use fail formula
  if (checkOutcome === -1 && formula.fail) {
    rollFormula = formula.failFormula;
    modifierSources += " (Check Failed)";
  }

  // If check successed over 5 add bonus formula
  if (checkOutcome > 0 && formula.each5) {
    for(let i = 0; i < checkOutcome; i++) {
      rollFormula += ` + ${formula.each5Formula}`;
    }
    modifierSources += ` (Check Success over ${5 * checkOutcome})`;
  }
  // Apply active enhancements
  if (enhancements) {
    Object.values(enhancements).forEach(enh => {
      if (enh.modifications.hasAdditionalFormula) {
        for (let i = 0; i < enh.number; i++) {
          rollFormula += ` + ${enh.modifications.additionalFormula}`;
          modifierSources += ` + ${enh.name}`;
        }
      }
    });
  }
  return {
    rollFormula: rollFormula,
    modifierSources: modifierSources
  };
}

function _prepareCheckFormula(actor, checkKey, helpDices) {
  let modifier;
  let rollType;
  switch (checkKey) {
    case "att":
      modifier = actor.system.attackMod.value.martial;
      rollType = "attackCheck";
      break;

    case "spe":
      modifier = actor.system.attackMod.value.spell;
      rollType = "spellCheck";
      break;

    case "mar": 
      const acrModifier = actor.system.skills.acr.modifier;
      const athModifier = actor.system.skills.ath.modifier;
      modifier = acrModifier >= athModifier ? acrModifier : athModifier;
      rollType = "skillCheck";
      break;

    default:
      modifier = actor.system.skills[checkKey].modifier;
      rollType = "skillCheck";
      break;
  }
  const globalMod = actor.system.globalFormulaModifiers[rollType] || "";
  return `d20 + ${modifier} ${globalMod} ${helpDices}`;
}

function _prepareAttackFromula(actor, attackFormula, helpDices) {
  const formula = attackFormula.formula;
  const rollType = attackFormula.checkType === "attack" ? "attackCheck" : "spellCheck";
  const globalMod = actor.system.globalFormulaModifiers[rollType] || "";
  return `${formula} ${globalMod} ${helpDices}`;
}

//=======================================
//           PREPARE DETAILS            =
//=======================================
function _prepareDynamicSaveDetails(item, winningRoll) {
  const type = item.system.actionType === "dynamic" ? item.system.save.type : null;
  const saveDetails = {
    dc: winningRoll._total,
    type: type
  };
  const enhancements = item.system.enhancements;
  _overrideWithEnhancement(saveDetails, enhancements, false);

  saveDetails.label = getLabelFromKey(saveDetails.type, DC20RPG.saveTypes) + " Save";
  return saveDetails;
}

function _prepareSaveDetails(item) {
  const type = item.system.save.type;
  const saveDetails = {
    dc: item.system.save.dc,
    type: type,
  };
  const enhancements = item.system.enhancements;
  _overrideWithEnhancement(saveDetails, enhancements, true);
  
  saveDetails.label = getLabelFromKey(saveDetails.type, DC20RPG.saveTypes) + " Save";
  return saveDetails;
}

function _overrideWithEnhancement(saveDetails, enhancements, overrideDC) {
  if (enhancements) {
    Object.values(enhancements).forEach(enh => {
      if (enh.number && enh.modifications.overrideSave) {
        saveDetails.type = enh.modifications.save.type;
        if (overrideDC) saveDetails.dc = enh.modifications.save.dc;
      }
    });
  }
}

function _prepareCheckDetails(item, winningRoll, formulaRolls) {
  const canCrit = item.system.check.canCrit;
  if (canCrit && winningRoll.crit) _markCritFormulas(formulaRolls);

  const checkKey = item.system.check.checkKey;
  const contestedKey = item.system.check.contestedKey;
  return {
    rollLabel: getLabelFromKey(checkKey, DC20RPG.checks),
    checkDC: item.system.check.checkDC,
    actionType: item.system.actionType,
    contestedAgainst: winningRoll._total,
    contestedKey: contestedKey,
    contestedLabel: getLabelFromKey(contestedKey, DC20RPG.contests)
  }
}

function _markCritFormulas(formulaRolls) {
  formulaRolls.forEach(roll => {
    roll.modified._total += 2;
    roll.modified.crit = true;
    roll.modified.modifierSources += ` + Critical`;
  });
}

//=======================================
//            OTHER FUNCTIONS           =
//=======================================
function _collectHelpDices(rollMenu) {
  let hitDicesFormula = "";
  if (rollMenu.d8 > 0) hitDicesFormula += `+ ${rollMenu.d8}d8`;
  if (rollMenu.d6 > 0) hitDicesFormula += `+ ${rollMenu.d6}d6`;
  if (rollMenu.d4 > 0) hitDicesFormula += `+ ${rollMenu.d4}d4`;
  return hitDicesFormula;
}

function _determineRollLevel(rollMenu) {
  const disLevel = rollMenu.dis;
  const advLevel = rollMenu.adv;
  return advLevel - disLevel;
}

function _hasAnyRolls(rolls) {
  if (rolls.core.length !== 0) return true;
  if (rolls.formula.length !== 0) return true;
  return false;
}

async function spendRestPoint(actor) {
  const rpCurrent = actor.system.rest.restPoints.current;
  const newRpAmount = rpCurrent - 1;

  if (newRpAmount < 0) {
    let errorMessage = `No more Rest Points to spend.`;
    ui.notifications.error(errorMessage);
    return;
  }

  const health = actor.system.resources.health;
  const hpCurrent = health.current;
  const hpMax = health.max;
  const mig = actor.system.attributes.mig.value;

  let newHP = hpCurrent + Math.max(mig, 0) + 2;
  newHP = newHP > hpMax ? hpMax : newHP;

  const updateData = {
    ["system.rest.restPoints.current"]: newRpAmount,
    ["system.resources.health.current"]: newHP
  };
  await actor.update(updateData);
}

async function regainRestPoint(actor) {
  const rpCurrent = actor.system.rest.restPoints.current;
  const rpMax = actor.system.rest.restPoints.max;
  const newRpAmount = Math.min(rpMax, rpCurrent + 1);
  await actor.update({["system.rest.restPoints.current"]: newRpAmount});
}

async function resetLongRest(actor) {
  const updateData = {
    ["system.rest.longRest.half"]: false,
    ["system.rest.longRest.noActivity"]: false
  };
  await actor.update(updateData);
}

async function finishRest(actor, restType, noActivity) { 
  switch (restType) {
    case "quick":
      return await _finishQuickRest(actor);
    case "short":
      return await _finishShortRest(actor);
    case "long":
      return await _finishLongRest(actor, noActivity);
    case "full": 
      return await _finishFullRest(actor);
    default:
      ui.notifications.error("Choose correct rest type first.");
  }
}

async function refreshOnRoundEnd(actor) {
  refreshAllActionPoints(actor);
  await _refreshItemsOn(actor, ["round"]);
  await _refreshCustomResourcesOn(actor, ["round"]);
}

async function refreshOnCombatEnd(actor) {
  refreshAllActionPoints(actor);
  await _refreshItemsOn(actor, ["round", "combat"]);
  await _refreshCustomResourcesOn(actor, ["round", "combat"]);
}

async function _finishQuickRest(actor) {
  await _refreshItemsOn(actor, ["round", "combat", "quick"]);
  await _refreshCustomResourcesOn(actor, ["round", "combat", "quick"]);
  return true;
}

async function _finishShortRest(actor) {
  await _refreshItemsOn(actor, ["round", "combat", "quick", "short"]);
  await _refreshCustomResourcesOn(actor, ["round", "combat", "quick", "short"]);
  return true;
}

async function _finishLongRest(actor, noActivity) {
  await _respectActivity(actor, noActivity);

  const halfFinished = actor.system.rest.longRest.half;
  if (halfFinished) {
    await _refreshMana(actor);
    await _refreshGrit(actor);
    await _refreshItemsOn(actor, ["round", "combat", "quick", "short", "long"]);
    await _refreshCustomResourcesOn(actor, ["round", "combat", "quick", "short", "long"]);
    await _checkIfNoActivityPeriodAppeared(actor);
    await _clearDoomed(actor);
    await resetLongRest(actor);
    return true;
  } 
  else {
    await _refreshRestPoints(actor);
    await _refreshItemsOn(actor, ["round", "combat", "quick", "short"]);
    await _refreshCustomResourcesOn(actor, ["round", "combat", "quick", "short"]);
    await actor.update({["system.rest.longRest.half"]: true});
    return false;
  }
}

async function _finishFullRest(actor) {
  await _refreshMana(actor);
  await _refreshGrit(actor);
  await _refreshRestPoints(actor);
  await _refreshHealth(actor);
  await _clearExhaustion(actor);
  await _clearDoomed(actor);
  await _refreshItemsOn(actor, ["round", "combat", "quick", "short", "long", "full", "day"]);
  await _refreshCustomResourcesOn(actor, ["round", "combat", "quick", "short", "long", "full"]);
  return true;
}

async function _refreshItemsOn(actor, resetTypes) {
  const items = actor.items;

  for (let item of items) {
    if (item.system.costs) {
      const charges = item.system.costs.charges;
      if (resetTypes.includes(charges.reset)) {
        if (charges.overriden) {
          const rollData = await item.getRollData();
          const result = evaulateDicelessFormula(charges.rechargeFormula, rollData).total;

          let newCharges = charges.current + result;
          newCharges = newCharges <= charges.max ? newCharges : charges.max;
          item.update({[`system.costs.charges.current`]: newCharges});
        } 
        else {
          item.update({[`system.costs.charges.current`]: charges.max});
        }
      }
    }
  } 
}

async function _refreshCustomResourcesOn(actor, resetTypes) {
  const customResources = actor.system.resources.custom;
  const updateData = {};
  Object.entries(customResources).forEach(([key, resource]) => {
    if (resetTypes.includes(resource.reset)) {
      resource.value = resource.max;
      updateData[`system.resources.custom.${key}`] = resource;
    }
  });
  actor.update(updateData);
}

async function _clearExhaustion(actor) {
  const updateData = {
    ["system.exhaustion"]: 0,
    ["system.rest.longRest.exhSaveDC"]: 10
  };
  await actor.update(updateData);
}

async function _clearDoomed(actor) {
  const updateData = {
    ["system.death.doomed"]: 0
  };
  await actor.update(updateData);
}

async function _respectActivity(actor, noActivity) {
  if (noActivity) {
    const currentExhaustion = actor.system.exhaustion;
    let newExhaustion = currentExhaustion - 1;
    newExhaustion = newExhaustion >= 0 ? newExhaustion : 0;
    const updateData = {
      ["system.exhaustion"]: newExhaustion,
      ["system.rest.longRest.noActivity"]: true
    };
    await actor.update(updateData);
  }
}

async function _checkIfNoActivityPeriodAppeared(actor) {
  const noActivity = actor.system.rest.longRest.noActivity;
  if (!noActivity) {
    const rollDC = actor.system.rest.longRest.exhSaveDC;
    const details = {
      roll: "1d20 + @attributes.mig.save",
      label: `Exhaustion Save [Might] (DC ${rollDC})`,
      type: "save",
    };
    const roll = await rollFromSheet(actor, details);
    if (roll.total < rollDC) {
      const currentExhaustion = actor.system.exhaustion;
      let newExhaustion = currentExhaustion + 1;
      newExhaustion = newExhaustion <= 6 ? newExhaustion : 6;

      const updateData = {
        ["system.exhaustion"]: newExhaustion,
        ["system.rest.longRest.exhSaveDC"]: rollDC + 5
      };
      await actor.update(updateData);
    }
  }
}

async function _refreshMana(actor) {
  const manaMax = actor.system.resources.mana.max;
  await actor.update({["system.resources.mana.value"]: manaMax});
}

async function _refreshHealth(actor) {
  const hpMax = actor.system.resources.health.max;
  await actor.update({["system.resources.health.current"]: hpMax});
}

async function _refreshGrit(actor) {
  const gritMax = actor.system.resources.grit.max;
  await actor.update({["system.resources.grit.value"]: gritMax});
}

async function _refreshRestPoints(actor) {
  const rpMax = actor.system.rest.restPoints.max;
  await actor.update({["system.rest.restPoints.current"]: rpMax});
}

class DC20RpgCombat extends Combat {

  /** @override **/
  async rollInitiative(ids, {formula=null, updateTurn=true, messageOptions={}, label="Initiative", type=null}={}) {
    // Structure input data
    ids = typeof ids === "string" ? [ids] : ids;
    const currentId = this.combatant?.id;

    // Iterate over Combatants, performing an initiative roll for each
    const updates = [];
    const messages = [];
    for ( let [i, id] of ids.entries() ) {

      // Get Combatant data (non-strictly)
      const combatant = this.combatants.get(id);
      if ( !combatant?.isOwner ) continue;

      // Produce an initiative roll for the PC/NPC Combatant
      const initiative = combatant.actor.type === "character" 
            ? await this._initiativeRollForPC(combatant, formula, label, type, messageOptions, i, messages) 
            : this._initiativeForNPC();
      if (initiative == null) return;
      updates.push({_id: id, initiative: initiative});
    }
    if ( !updates.length ) return this;

    // Update multiple combatants
    await this.updateEmbeddedDocuments("Combatant", updates);

    // Ensure the turn order remains with the same combatant
    if ( updateTurn && currentId ) {
      await this.update({turn: this.turns.findIndex(t => t.id === currentId)});
    }

    // Create multiple chat messages
    await ChatMessage.implementation.create(messages);
    return this;
  }

  /** @override **/
  async nextTurn() {
    let turn = this.turn ?? -1;
    let skip = this.settings.skipDefeated;
    
    // Refresh resources on turn end
    const combatant = this.combatants.get(this.current.combatantId);
    const actor =  await combatant.actor;
    refreshOnRoundEnd(actor);

    // Determine the next turn number
    let next = null;
    if ( skip ) {
      for ( let [i, t] of this.turns.entries() ) {
        if ( i <= turn ) continue;
        if ( t.isDefeated ) continue;
        next = i;
        break;
      }
    }
    else next = turn + 1;

    // Maybe advance to the next round
    let round = this.round;
    if ( (this.round === 0) || (next === null) || (next >= this.turns.length) ) {
      return this.nextRound();
    }

    // Update the document, passing data through a hook first
    const updateData = {round, turn: next};
    const updateOptions = {advanceTime: CONFIG.time.turnTime, direction: 1};
    Hooks.callAll("combatTurn", this, updateData, updateOptions);
    return this.update(updateData, updateOptions);
  }

  /** @override **/
  async endCombat() {
    return Dialog.confirm({
      title: game.i18n.localize("COMBAT.EndTitle"),
      content: `<p>${game.i18n.localize("COMBAT.EndConfirmation")}</p>`,
      yes: () => {
        this.combatants.forEach(async combatant => {
          const actor =  await combatant.actor;
          refreshOnCombatEnd(actor);
        });
        this.delete();
      }
    });
  }

  /** @override **/
  async _manageTurnEvents(adjustedTurn) {
    if ( !game.users.activeGM?.isSelf ) return;
    const prior = this.previous && this.combatants.get(this.previous.combatantId);

    // Adjust the turn order before proceeding. Used for embedded document workflows
    if ( Number.isNumeric(adjustedTurn) ) await this.update({turn: adjustedTurn}, {turnEvents: false});
    if ( !this.started ) return;

    // Identify what progressed
    const advanceRound = this.current.round > (this.previous.round ?? -1);
    const advanceTurn = this.current.turn > (this.previous.turn ?? -1);
    if ( !(advanceTurn || advanceRound) ) return;

    // Conclude prior turn
    if ( prior ) await this._onEndTurn(prior);

    // Conclude prior round
    if ( advanceRound && (this.previous.round !== null) ) await this._onEndRound();

    // Begin new round
    if ( advanceRound ) await this._onStartRound();

    // Begin a new turn
    await this._onStartTurn(this.combatant);
  }

  async _initiativeRollForPC(combatant, formula, label, type) {
    const dataset = !formula ? combatant.getRemeberedDataset() : {
      roll: formula,
      label: label,
      formulaLabel: "Initative Roll",
      type: type
    };
    const roll = await rollFromSheet(combatant.actor, dataset);
    if (!roll) return;
    combatant.rememberDataset(dataset);
    if (roll.fail) return 0; // For nat 1 we want player to always start last.
    else return roll.total;
  }

  _initiativeForNPC() {
    const pcTurns = [];
    const npcTurns = [];
    this.turns.forEach((turn) => {
      if (turn.initiative != null) {
        if (turn.actor.type === "character") pcTurns.push(turn);
        else npcTurns.push(turn);
      }
    });
    
    if (pcTurns.length === 0) {
      ui.notifications.error("At least one PC should be in initative order at this point!"); 
      return;
    }

    // For nat 1 we want player to always start last.We give them initative equal to 0 so 0.5 is a minimum value that enemy can get
    const checkOutcome = this._checkWhoGoesFirst();
    // Special case when 2 PC start in initative order
    if (checkOutcome === "2PC") {
      // Only one PC
      if (pcTurns.length === 1 && !npcTurns[0]) return Math.max(pcTurns[0].initiative - 0.5, 0.5);
      // More than one PC
      for (let i = 1; i < pcTurns.length; i ++) {
        if (!npcTurns[i-1]) return Math.max(pcTurns[i].initiative - 0.5, 0.5);
      }
      // More NPCs than PCs - add those at the end
      if (npcTurns.length >= pcTurns.length - 1) return Math.max(npcTurns[npcTurns.length - 1].initiative - 0.55, 0.5);
    }
    else {
      for (let i = 0; i < pcTurns.length; i ++) {
        if (!npcTurns[i]) {
          // Depending on outcome of encounter check we want enemy to be before or after pcs
          const changeValue = checkOutcome === "PC" ? - 0.5 : 0.5; 
          return Math.max(pcTurns[i].initiative + changeValue, 0.5);
        }
      }
      // More NPCs than PCs - add those at the end
      if (npcTurns.length >= pcTurns.length) return Math.max(npcTurns[npcTurns.length - 1].initiative - 0.55, 0.5); 
    }
  }

  _checkWhoGoesFirst() {
    // Determine who goes first. Players or NPCs
    const turns = this.turns;
    if (turns) {
      let highestPCInitiative;
      for (let i = 0; i < turns.length; i++) {
        if (turns[i].actor.type === "character") {
          highestPCInitiative = turns[i].initiative;
          break;
        }
      }
      if (highestPCInitiative >= this.flags.dc20rpg.encounterDC + 5) return "2PC";
      else if (highestPCInitiative >= this.flags.dc20rpg.encounterDC) return "PC";
      else return "ENEMY";
    }
  }
}

/**
 * Dialog window for picking custom attribute for skill roll.
 */
class VariableAttributePickerDialog extends Dialog {

  constructor(actor , parentDataset, dialogData = {}, options = {}) {
    super(dialogData, options);
    this.actor = actor;
    this.parentDataset = parentDataset;
  }

  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      template: "systems/dc20rpg/templates/dialogs/variable-attribute-picker.hbs",
      classes: ["dc20rpg", "dialog"]
    });
  }

  getData() {
    return DC20RPG.attributes;
  }

   /** @override */
  activateListeners(html) {
    super.activateListeners(html);
    html.find('.rollable').click(ev => this._onRoll(ev));
  }

  _onRoll(event) {
    event.preventDefault();
    const selectedAttributeKey = $(".selectable option:selected").val();
    const selectedAttributeLabel = $(".selectable option:selected").text();
    const parentDataset = this.parentDataset;

    const value = skillMasteryValue(parentDataset.mastery);
    const modifier = value + (2 * parentDataset.expertise) + parseInt(parentDataset.bonus);
    parentDataset.roll = `d20+ @attributes.${selectedAttributeKey}.check + ${modifier}`;
    parentDataset.label = parentDataset.label ? `${parentDataset.label} (${selectedAttributeLabel})` : '';
    
    this.close();
    rollFromSheet(this.actor, parentDataset);
  }
}

/**
 * Creates VariableAttributePickerDialog for given actor and with dataset extracted from event. 
 */
function createVariableRollDialog(dataset, actor) {
  let dialog = new VariableAttributePickerDialog(actor, dataset, {title: "Variable Attribute Roll"});
  dialog.render(true);
}

function prepareActiveEffectCategories(effects) {
    // Define effect header categories
    const categories = {
      temporary: {
        type: "temporary",
        label: "Temporary Effects",
        effects: []
      },
      passive: {
        type: "passive",
        label: "Passive Effects",
        effects: []
      },
      inactive: {
        type: "inactive",
        label: "Inactive Passive Effects",
        effects: []
      },
      disabled: {
        type: "disabled",
        label: "Disabled Temporary Effects",
        effects: []
      }
    };

    // Iterate over active effects, classifying them into categories
    for ( let effect of effects ) {
      effect.orignName = effect.sourceName;
      if (effect.isTemporary && effect.disabled) categories.disabled.effects.push(effect);
      else if (effect.disabled) categories.inactive.effects.push(effect);
      else if (effect.isTemporary) categories.temporary.effects.push(effect);
      else categories.passive.effects.push(effect);
    }
    return categories;
}

//==================================================
//    Manipulating Effects On Other Objects        =  
//==================================================
async function createEffectOn(type, owner) {
  const duration = type === "temporary" ? 1 : undefined;
  const inactive = type === "inactive";
  owner.createEmbeddedDocuments("ActiveEffect", [{
    label: "New Effect",
    icon: "icons/svg/aura.svg",
    origin: owner.uuid,
    "duration.rounds": duration,
    disabled: inactive
  }]);
}

function editEffectOn(effectId, owner) {
  const effect = _getEffectFrom(effectId, owner);
  effect.sheet.render(true);
}

function deleteEffectOn(effectId, owner) {
  const effect = _getEffectFrom(effectId, owner);
  effect.delete();
}

function toggleEffectOn(effectId, owner) {
  const effect = _getEffectFrom(effectId, owner);
  effect.update({disabled: !effect.disabled});
}

function _getEffectFrom(effectId, owner) {
  return owner.effects.get(effectId);
}

//===========================================================
//     Method exposed for efect management with macros      =  
//===========================================================
const effectMacroHelper = {
  toggleEffectOnSelectedTokens: async function (effect) {
    const tokens = await getSelectedTokens();
    if (tokens) tokens.forEach(token => this.toggleEffectOnActor(effect, token.actor));
  },

  toggleEffectOnActor: function(effect, owner) {
    if (this.effectWithNameExists(effect.label, owner)) this.deleteEffectWithName(effect.label, owner);
    else this.addEffectToActor(effect, owner); 
  },

  addEffectToActor: function(effect, owner) {
    effect.owner = owner.uuid;
    owner.createEmbeddedDocuments("ActiveEffect", [effect]);
  },

  effectWithNameExists: function(effectName, owner) {
    return owner.effects.getName(effectName) !== undefined;
  },

  deleteEffectWithName: function(effectName, owner) {
    const effect = owner.effects.getName(effectName);
    effect.delete();
  },
};

/**
 * Configuration of advancements on item
 */
class ActorAdvancement extends Dialog {

  constructor(actor, advForItems, scalingValues, dialogData = {}, options = {}) {
    super(dialogData, options);
    this.actor = actor;
    this.advForItems = advForItems;
    this.scalingValues = scalingValues;
    this.showScaling = true;
  }

  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      template: "systems/dc20rpg/templates/dialogs/actor-advancement.hbs",
      classes: ["dc20rpg", "dialog"],
      width: 550,
      height: 550
    });
  }

  prepareData() {
    const current = Object.values(this.advForItems)[0];
    if (!current) {this.close(); return;}
    
    const currentItem = current.item;
    if (!currentItem) {this.close(); return;}

    const advancementsForCurrentItem =  Object.entries(current.advancements);
    const currentAdvancement = advancementsForCurrentItem[0];
    if (!currentAdvancement) {this.close(); return;}

    // Set first item
    this.currentItem = currentItem;
    this.itemIndex = 0;
    
    // Set first advancement
    this.advancementsForCurrentItem = advancementsForCurrentItem;
    this.currentAdvancement = currentAdvancement[1];
    this.currentAdvancementKey = currentAdvancement[0];
    this.advIntex = 0;

  }

  hasNext() {
    const nextAdvancement = this.advancementsForCurrentItem[this.advIntex + 1];
    if (nextAdvancement) return true;
    
    const nextItem =  Object.values(this.advForItems)[this.itemIndex + 1];
    if (nextItem) return true;
    else return false;
  }

  next() {
    const nextAdvancement = this.advancementsForCurrentItem[this.advIntex + 1];
    if (nextAdvancement) {
      this.currentAdvancement = nextAdvancement[1];
      this.currentAdvancementKey = nextAdvancement[0];
      this.advIntex++;
      return;
    }
    
    const next = Object.values(this.advForItems)[this.itemIndex + 1];
    if (!next) {
      ui.notifications.error("Advancement cannot be progressed any further");
      this.close();
      return;
    }

    const nextItem = next.item;
    if (!nextItem) {
      ui.notifications.error("Advancement cannot be progressed any further");
      this.close();
      return;
    }

    const advancementsForItem = Object.entries(next.advancements);
    const currentAdvancement = advancementsForItem[0];

    if (!currentAdvancement) {
      ui.notifications.error("Advancement cannot be progressed any further");
      this.close();
      return;
    }

    // Go to next item
    this.currentItem = nextItem;
    this.itemIndex++;

    // Reset advancements
    this.advancementsForCurrentItem = advancementsForItem;
    this.currentAdvancement = currentAdvancement[1];
    this.currentAdvancementKey = currentAdvancement[0];
    this.advIntex = 0;
    
  }

  //=====================================
  //              Get Data              =  
  //=====================================
  async getData() {
    if (this.showScaling) return await this._getDataForScalingValues();
    else return await this._getDataForAdvancements();

  }

  async _getDataForScalingValues() {
    return {
      showScaling: true,
      scaling: this.scalingValues,
      title: {
        text: `You gain next level!`,
        img: "icons/svg/upgrade.svg"
      }
    }
  }

  async _getDataForAdvancements() {
    const advancement = this.currentAdvancement;

    // Collect items that are part of advancement
    Object.values(advancement.items).forEach(async record => {
      const item = await fromUuid(record.uuid);
      if (!item) {
        ui.notifications.error(`Advancement corrupted, cannot find saved items.`);
        return advancement;
      } 
      record.img = item.img;
      record.name = item.name;
      record.description = await TextEditor.enrichHTML(item.system.description, {async: true});
    });

    // Determine how many points left to spend
    if (advancement.mustChoose) {
      const choosen = Object.fromEntries(Object.entries(advancement.items).filter(([key, item]) => item.selected));
      
      let pointsSpend = 0; 
      Object.values(choosen).forEach(item => pointsSpend += item.pointValue);
      advancement.pointsLeft = advancement.pointAmount - pointsSpend;
    }

    return {
      ...advancement,
      title: {
        text: `You gain next level in ${this.currentItem.name}!`,
        img: this.currentItem.img
      }
    }
  }

  //===========================================
  //           Activate Listerners            =  
  //===========================================
   /** @override */
  activateListeners(html) {
    super.activateListeners(html);
    html.find(".apply").click(async (ev) => await this._onApply(ev));
    html.find('.activable').click(ev => this._onActivable(datasetOf(ev).path));
    html.find('.next').click(ev => this._onNext(ev));
  }

  _onNext(event) {
    event.preventDefault();
    this.showScaling = false;
    if (Object.keys(this.advForItems).length === 0) {
      this.close();
      return;
    }
    this.prepareData();
    this.render(true);
  }

  _onActivable(pathToValue) {
    let value = getValueFromPath(this.currentAdvancement, pathToValue);
    setValueForPath(this.currentAdvancement, pathToValue, !value);
    this.render(true);
  }

  async _onApply(event) {
    event.preventDefault();
    const advancement = this.currentAdvancement;

    if (advancement.mustChoose) {
      if (advancement.pointsLeft < 0) {
        ui.notifications.error(`You spent too many Choice Points!`);
        return;
      } 
      else if (advancement.pointsLeft > 0) {
        ui.notifications.error(`You spent not enough Choice Points!`);
        return;
      }
      else {
        const selectedItems = Object.fromEntries(Object.entries(advancement.items).filter(([key, item]) => item.selected));
        await this._addItemsToActor(selectedItems, advancement);
        this._markAdvancementAsApplied(advancement);
      }
    }
    else {
      await this._addItemsToActor(advancement.items, advancement);
      this._markAdvancementAsApplied(advancement);
    }

    if (this.hasNext()) {
      this.next();
      this.render(true);
    }
    else this.close();
  }

  async _addItemsToActor(items, advancement) {
    let createdItems = {};
    for (const [key, record] of Object.entries(items)) {
      const item = await fromUuid(record.uuid);
      const created = await createItemOnActor(this.actor, item);
      record.createdItemId = created._id;
      createdItems[key] = record;
    }
    advancement.items = createdItems;
  }

  _markAdvancementAsApplied(advancement) {
    advancement.applied = true;
    this.currentItem.update({[`system.advancements.${this.currentAdvancementKey}`]: advancement});
  }
}

/**
 * Creates and returns ActorAdvancement dialog. 
 */
function actorAdvancementDialog(actor, advForItems, scalingValues) {
  const dialog = new ActorAdvancement(actor, advForItems, scalingValues, {title: `Character Advancements`});
  dialog.render(true);
}

function deleteAdvancement(item, key) {
	item.update({[`system.advancements.-=${key}`]: null});
}

function applyAdvancements(actor, level, clazz, subclass, ancestry, background) {
	let advForItems = {};
	let scalingValues = {};

	if (clazz) {
		const advancements = _collectAdvancementsFromItem(level, clazz);
		if (Object.keys(advancements).length !== 0) advForItems = {...advForItems, clazz: {item: clazz, advancements: advancements}};
		scalingValues = {...scalingValues, ..._collectScalingValuesForItem(level, clazz)};
	}
	if (subclass) {
		const advancements = _collectAdvancementsFromItem(level, subclass);
		if (Object.keys(advancements).length !== 0) advForItems = {...advForItems, subclass: {item: subclass, advancements: advancements}};
		scalingValues = {...scalingValues, ..._collectScalingValuesForItem(level, subclass)};
	}
	if (ancestry) {
		const advancements = _collectAdvancementsFromItem(level, ancestry);
		if (Object.keys(advancements).length !== 0) advForItems = {...advForItems, ancestry: {item: ancestry, advancements: advancements}};
		scalingValues = {...scalingValues, ..._collectScalingValuesForItem(level, ancestry)};
	}
	if (background) {
		const advancements = _collectAdvancementsFromItem(level, background);
		if (Object.keys(advancements).length !== 0) advForItems = {...advForItems, background: {item: background, advancements: advancements}};
		scalingValues = {...scalingValues, ..._collectScalingValuesForItem(level, background)};
	}

	actorAdvancementDialog(actor, advForItems, scalingValues);
}

function _collectAdvancementsFromItem(level, item) {
	const advancements = item.system.advancements;
	return Object.fromEntries(Object.entries(advancements)
		.filter(([key, advancement]) => advancement.level <= level)
		.filter(([key, advancement]) => !advancement.applied));
}

function _collectScalingValuesForItem(level, item) {
	const scaling = item.system.scaling;
	return Object.fromEntries(Object.entries(scaling).map(([key, value]) => {
		const label = value.label;
		const current = value.values[level-1]; // Tables start from 0!
		const previous = value.values[level-2] || 0;

		return [key, {
			label: label,
			current: current,
			previous: previous,
		}];
	}));
}

function removeAdvancements(actor, level, clazz, subclass, ancestry, background) {
	if (clazz) _removeAdvancementsFrom(actor, level, clazz);
	if (subclass) _removeAdvancementsFrom(actor, level, subclass);
	if (ancestry) _removeAdvancementsFrom(actor, level, ancestry);
	if (background) _removeAdvancementsFrom(actor, level, background);
}

async function _removeAdvancementsFrom(actor, level, item) {
	const advancements = item.system.advancements;
	Object.entries(advancements)
		.filter(([key, advancement]) => advancement.level >= level)
		.filter(([key, advancement]) => advancement.applied)
		.forEach(async ([key, advancement]) => {
			await _removeItemsFromActor(actor, advancement.items);
			await _markAdvancementAsNotApplied(advancement, key, actor, item._id);
		});
}

async function _removeItemsFromActor(actor, items) {
	for (const [key, record] of Object.entries(items)) {
		const itemExist = await actor.items.has(record.createdItemId);
		if (itemExist) {
			const item = await actor.items.get(record.createdItemId);
			record.createdItemId = "";
			await item.delete();
		}	
	}
}

async function _markAdvancementAsNotApplied(advancement, key, actor, id) {
	const itemStillExist = await actor.items.has(id);
	if (itemStillExist) {
		const item = await actor.items.get(id);
		advancement.applied = false;
		await item.update({[`system.advancements.${key}`]: advancement})
			.then((updatedItem) => updatedItem)
			.catch((error) => {/*Sometimes we are to fast with deleting item and update finds nothing. This error should be ignored.*/});
	}
}

//================================================
//           Item Manipulaton on Actor           =
//================================================
function getItemFromActor(itemId, actor) {
  return actor.items.get(itemId);
}

async function createItemOnActor(actor, itemData) {
  return await Item.create(itemData, { parent: actor });
}

function deleteItemFromActor(itemId, actor) {
  const item = getItemFromActor(itemId, actor);
  item.delete();
}

function editItemOnActor(itemId, actor) {
  const item = getItemFromActor(itemId, actor);
  item.sheet.render(true);
}

//======================================
//            Proficiencies            =
//======================================
/**
 * Checks if owner of given item is proficient with it. Method will change item's value
 * of ``system.attackFormula.combatMastery`` accordingly. Works only for weapons and equipment.
 * 
 * If actor is not sent it will be extracted from item.
 */
async function checkProficiencies(item, actor) {
  const owner = actor ? actor : await item.actor; 
  if (owner) {
    const profs = owner.system.masteries;
    if (!profs) return; // Actor does not have proficiencies (probably npc)

    if (item.type === "weapon") {
      const weaponType = item.system.weaponType;

      let isProficient = true;
      if (weaponType === "light") isProficient = profs.lightWeapon;
      else if (weaponType === "heavy") isProficient = profs.heavyWeapon;

      item.update({["system.attackFormula.combatMastery"]: isProficient});
    }
    else if (item.type === "equipment") {
      const equipmentType = item.system.equipmentType;

      let isProficient = true; // we want combat mastery for non-proficiency equipments (clothing, trinkets)
      switch (equipmentType) {
        case "light":
          isProficient = profs.lightArmor;
          break;

        case "heavy":
          isProficient = profs.heavyArmor;
          break;

        case "lshield": 
          isProficient = profs.lightShield;
          break;

        case "hshield": 
          isProficient = profs.heavyShield;
          break;
      }

      item.update({["system.attackFormula.combatMastery"]: isProficient});
    }
  }
}

async function changeProficiencyAndRefreshItems(key, actor) {
  const path = `system.masteries.${key}`;
  // Send call to update actor on server
  changeActivableProperty(path, actor);

  // We need to create actor dummy with correct proficency because 
  // we want to update item before changes on original actor were made
  let clonedProfs = foundry.utils.deepClone(actor.system.masteries);
  let dummyActor = {
    system: {
      masteries : clonedProfs
    }
  };
  dummyActor.system.masteries[key] = !actor.system.masteries[key];
  
  // Change items attackFormula
  const items = await actor.items;
  items.forEach(item => checkProficiencies(item, dummyActor));
}

//======================================
//            Actor's Class            =
//======================================
async function addUniqueItemToActor(item) {
  const itemType = item.type;
  if (!["class", "subclass", "ancestry", "background"].includes(itemType)) return;

  const actor = await item.actor;
  if (!actor) return;
  
  const uniqueItemId = actor.system.details[itemType].id;
  if (uniqueItemId) {
    let errorMessage = `Cannot add another ${itemType} to ${actor.name}.`;
    ui.notifications.error(errorMessage);
    item.delete();
  } 
  else {
    const actorLevel = actor.system.details.level;

    // Create custom resources from item on actor
    Object.entries(item.system.scaling)
      .filter(([key, scalingValue]) => scalingValue.isResource)
      .forEach(([key, scalingValue]) => createCustomResourceFromScalingValue(key, scalingValue, actor));

    // Apply Item Advancements
    switch (itemType) {
      case "class":
        // When adding class we also need to add subclass and ancestry advancements
        const subclass = actor.items.get(actor.system.details.subclass.id);
        const ancestry = actor.items.get(actor.system.details.ancestry.id);
        const background = actor.items.get(actor.system.details.background.id);
        applyAdvancements(actor, 1, item, subclass, ancestry, background); // When we are putting class it will always be at 1st level
        break;
      case "subclass":
        applyAdvancements(actor, actorLevel, null, item);
        break;
      case "ancestry":
        applyAdvancements(actor, actorLevel, null, null, item);
        break;
      case "background":
        applyAdvancements(actor, actorLevel, null, null, null, item);
    }
    
    actor.update({[`system.details.${itemType}.id`]: item._id});
  }
}

async function removeUniqueItemFromActor(item) {
  const itemType = item.type;
  if (!["class", "subclass", "ancestry", "background"].includes(itemType)) return;

  const actor = await item.actor;
  if (!actor) return;

  const uniqueItemId = actor.system.details[itemType].id;
  if (uniqueItemId === item._id) {
    
    // Remove item's custom resources from actor
    Object.entries(item.system.scaling)
      .filter(([key, scalingValue]) => scalingValue.isResource)
      .forEach(([key, scalingValue]) => removeResource(key, actor));

    switch (itemType) {
      case "class":
        // When removing class we also need to remove subclass and ancestry advancements
        const subclass = actor.items.get(actor.system.details.subclass.id);
        const ancestry = actor.items.get(actor.system.details.ancestry.id);
        const background = actor.items.get(actor.system.details.background.id);
        removeAdvancements(actor, 1, item, subclass, ancestry, background);
        break;
      case "subclass":
        removeAdvancements(actor, 1, null, item);
        break;
      case "ancestry":
        removeAdvancements(actor, 0, null, null, item); // Ancestries have level 0 traits
        break;
      case "background":
        removeAdvancements(actor, 0, null, null, null, item); // Background have level 0 traits
        break;
    }

    actor.update({[`system.details.${itemType}`]: {id: ""}});
  }
}

//======================================
//          Other Item Methods         =
//======================================
function changeLevel(up, itemId, actor) {
  const item = getItemFromActor(itemId, actor);
  let currentLevel = item.system.level;

  const clazz = actor.items.get(actor.system.details.class.id);
  const subclass = actor.items.get(actor.system.details.subclass.id);
  const ancestry = actor.items.get(actor.system.details.ancestry.id);
  if (up === "true") {
    currentLevel++;
    applyAdvancements(actor, currentLevel, clazz, subclass, ancestry);
  }
  else {
    removeAdvancements(actor, currentLevel, clazz, subclass, ancestry);
    currentLevel--;
  }

  item.update({[`system.level`]: currentLevel});
}

function sortMapOfItems(mapOfItems) {  
  const sortedEntries = [...mapOfItems.entries()].sort(([, a], [, b]) => a.sort - b.sort);

  if (!sortedEntries) return mapOfItems; // No entries, map is empty

  sortedEntries.forEach(entry => mapOfItems.delete(entry[0])); // we want to remove all original entries because those are not sorted
  sortedEntries.forEach(entry => mapOfItems.set(entry[0], entry[1])); // we put sorted entries to map
  return mapOfItems;
}

/**
 * Dialog window for creating new items on actor.
 */
class CreateItemDialog extends Dialog {

  constructor(actor, tab, dialogData = {}, options = {}) {
    super(dialogData, options);
    this.actor = actor;
    this.tab = tab;
  }

  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      template: "systems/dc20rpg/templates/dialogs/create-item-dialog.hbs",
      classes: ["dc20rpg", "dialog"]
    });
  }

  getData() {
    switch(this.tab) {
      case "inventory":   return DC20RPG.inventoryTypes;
      case "features":    return DC20RPG.featuresTypes;
      case "techniques":  return DC20RPG.techniquesTypes;
      case "spells":      return DC20RPG.spellsTypes;
      default:            return DC20RPG.allItemTypes;
    }
  }

   /** @override */
  activateListeners(html) {
    super.activateListeners(html);
    html.find('.create-item').click(ev => this._onCreateItem(ev));
  }

  _onCreateItem(event) {
    event.preventDefault();
    const selectedTypeKey = $(".selectable option:selected").val();
    const selectedTypeLabel = $(".selectable option:selected").text();
    const itemName = `New ${selectedTypeLabel}`;

    this.close();
    const itemData = {
      name: itemName,
      type: selectedTypeKey
    };
    createItemOnActor(this.actor, itemData);
  }
}

/**
 * Creates VariableAttributePickerDialog for given actor and with dataset extracted from event. 
 */
function createItemDialog(tab, actor) {
  let dialog = new CreateItemDialog(actor, tab, {title: "Create new Item"});
  dialog.render(true);
}

/**
 * Adds new header name to actor's headersOrdering flag.
 */
function addNewTableHeader(actor, headerName, tab) {
  const headersOrdering = actor.flags.dc20rpg.headersOrdering;
  const currentTabOrdering = headersOrdering[tab];

  const sortedHeaders = Object.entries(currentTabOrdering).sort((a, b) => a[1] - b[1]);
  const lastNumberInOrder = sortedHeaders[sortedHeaders.length - 1][1];

  headersOrdering[tab] = {
    ...currentTabOrdering, 
    [headerName]: lastNumberInOrder + 1
  };

  actor.update({[`flags.dc20rpg.headersOrdering`]: headersOrdering });
}

/**
 * Changes order of headers.
 */
function reorderTableHeader(event, actor) {
  event.preventDefault();
  const dataset = event.currentTarget.dataset;
  const headersOrdering = actor.flags.dc20rpg.headersOrdering;

  const tab = dataset.tab;
  const current = dataset.current;
  const swapped = dataset.swapped;

  let currentSortValue = headersOrdering[tab][current];
  let swappedSortValue = headersOrdering[tab][swapped];

  headersOrdering[tab][current] = swappedSortValue;
  headersOrdering[tab][swapped] = currentSortValue;

  actor.update({[`flags.dc20rpg.headersOrdering`]: headersOrdering });
}

/**
 * Removes headers when it has no items stored, as long as those are not send as core ones, those will stay.
 */
function enhanceItemTab(tab, coreHeaders) {
  let headersAsEntries = _hideEmptyTableHeaders(tab, coreHeaders);
  _addSiblings(headersAsEntries);
  return Object.fromEntries(headersAsEntries);
}

function _hideEmptyTableHeaders(tab, coreHeaders) {
  let filteredEntries = Object.entries(tab).filter(
                header => Object.keys(header[1].items).length !== 0 
                      ? true : 
                      coreHeaders.includes(header[0])
                );
  return filteredEntries;
}

function _addSiblings(headersAsEntries) {
  for(let i = 0; i < headersAsEntries.length; i++) {
    let siblingBefore = headersAsEntries[i-1] ? headersAsEntries[i-1][0] : undefined;
    let siblingAfter = headersAsEntries[i+1] ? headersAsEntries[i+1][0] : undefined;

    headersAsEntries[i][1].siblings = {
      before: siblingBefore,
      after: siblingAfter
    };
  }
  return headersAsEntries;
}

function generateItemName(item) {
  let itemName = item.name ? item.name : "Item Details";
  if (item.type === "spell") {
    const spellType = item.system.spellType;
    itemName += ` (${getLabelFromKey(spellType, DC20RPG.spellTypes)})`;
  } 
  return itemName;
}

function generateDescriptionForItem(item) {
  if (!item) return "Item not found";

  let content = "";
  // content += _rollResults(item);
  content += _description(item);
  return content;
}

function generateDetailsForItem(item) {
  if (!item) return "Item not found";

  let content = "";
  content += _range(item);
  content += _target(item);
  content += _duration(item);
  content += _armorBonus(item);
  content += _props(item);
  content += _components(item);
  return content;
}

function _range(item) {
  const range = item.system.range;
  let content = "";

  if (range) {
    const normal = range.normal;
    const max = range.max;
    const unit = range.unit ? range.unit : "Spaces";

    if (normal) {
      content += `<div class='detail'> ${normal}`;
      if (max) content += `/${max}`;
      content += ` ${unit} </div>`;
    }
  }
  return content;
}

function _target(item) {
  const target =  item.system.target;
  let content = "";

  if (target) {
    if (target.invidual) content += _invidual(target);
    else content += _area(target);
  }
  return content;
}
  
function _invidual(target) {
  let content = "";
  const type = target.type;
  const count = target.count;

  if (type) {
    content += "<div class='detail'>";
    if (count) content += ` ${count}`;
    content += ` ${getLabelFromKey(type, DC20RPG.invidualTargets)}`;
    content += "</div>";
  }
  return content;
}
  
function _area(target) {
  let content = "";
  const area = target.area;
  const unit = target.unit;
  const distance = target.distance;
  const width = target.width;

  if (area) {
    content += "<div class='detail'>";
    if (distance) {
      content += area === "line" ? ` ${distance}/${width}` : ` ${distance}`;
      content += unit ? ` ${unit}` : " Spaces";
    }
    content += ` ${getLabelFromKey(area, DC20RPG.areaTypes)}`;
    content += "</div>";
  }
  return content;
}

function _duration(item) {
  const duration =  item.system.duration;
  let content = "";

  if (duration) {
    const type = duration.type;
    const value = duration.value;
    const timeUnit = duration.timeUnit;

    if (type && timeUnit) {
      content += "<div class='detail'>";
      content += `${getLabelFromKey(type, DC20RPG.durations)} (`;
      if (value) content += `${value}`;
      content += ` ${getLabelFromKey(timeUnit, DC20RPG.timeUnits)}`;
      content += ")</div>";
    }
    else if (type) {
      content += "<div class='detail'>";
      content += `${getLabelFromKey(type, DC20RPG.durations)}`;
      content += "</div>";
    }
  }
  return content;
}

function _armorBonus(item) {
  const armorBonus = item.system.armorBonus;
  let content = "";
  if (armorBonus) {
    content += "<div class='detail'>";
    content += `+ ${armorBonus} PD`;
    content += "</div>";
  }
  return content;
}

function _props(item) {
  const properties =  item.system.properties;
  let content = "";
  if (properties) {
    Object.entries(properties).forEach(([key, prop]) => {
      if (prop.active) {
        content += `<div class='detail box'> ${getLabelFromKey(key, DC20RPG.properties)}`;
        if (prop.value) content += ` (${prop.value})`;
        content += "</div>";
      }
    });
  }
  return content;
}

function _components(item) {
  const components = item.system.components;
  let content = "";
  if (components) {
    Object.entries(components).forEach(([key, comp]) => {
      if (comp.active) {
        content += `<div class='detail box'> ${getLabelFromKey(key, DC20RPG.components)}`;
        if (key === "material") {
          if (comp.description) {
            const cost = comp.cost ? ` ${comp.cost}` : "";
            const consumed = comp.consumed ? "[Consumed On Use]" : "";
            content += `: ${comp.description}${cost}${consumed}`;
          } 
        }
        content += "</div>";
      }
    });
  }
  return content;
}

// function _rollResults(item) {
//   const identified = item.system.statuses ? item.system.statuses.identified : true;
//   if (!identified) return "";

//   const outcomes = item.system.outcome;
//   if (!outcomes) return "";

//   let content = "";
//   Object.values(outcomes).forEach(outcome => {
//     if (outcome.description) content += `<div class='outcome'> <b>${outcome.label}</b> ${outcome.description} </div>`;
//   })
//   return content;
// }

function _description(item) {
  const identified = item.system.statuses ? item.system.statuses.identified : true;
  const description = item.system.description;
  if (identified) return `<div class='description'> ${_simplyfyDescription(description)} </div>`;
  else return `<div class='description'> <b>UNIDENTIFIED</b> </div>`;
}

function _simplyfyDescription(description) {
  let dsc = description;
  const regex = /@UUID\[[^\]]*]\{[^}]*}/g;
  const front = /@UUID\[[^\]]*]\{/;
  
  const parts = [...dsc.matchAll(regex)];
  parts.forEach(part => {
    let match = part[0];
    match = match.split(front); // extract item name
    match = match[1].slice(0, match[1].length -1); // remove closing '}'
    match = `<b>${match}</b>`; // make it bold

    dsc = dsc.replace(part[0], match);
  });
  return dsc;

}

/**
 * Dialog window for resting.
 */
class RestDialog extends Dialog {

  constructor(actor, dialogData = {}, options = {}) {
    super(dialogData, options);
    this.actor = actor;
    this.data = {
      selectedRestType: "long",
      noActivity: true
    };
  }

  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      template: "systems/dc20rpg/templates/dialogs/rest-dialog.hbs",
      classes: ["dc20rpg", "dialog"]
    });
  }

  getData() {
    const restTypes = DC20RPG.restTypes;
    this.data.rest = this.actor.system.rest;

    return {
      restTypes: restTypes,
      ...this.data
    }
  }

   /** @override */
  activateListeners(html) {
    super.activateListeners(html);
    html.find(".selectable").change(ev => this._onSelection(ev));
    html.find(".regain-rp").click(ev => this._onRpRegained(ev));
    html.find(".spend-rp").click(ev => this._onRpSpend(ev));
    html.find(".finish-rest").click(ev => this._onFinishRest(ev));
    html.find(".reset-rest").click(ev => this._onResetRest(ev));
    html.find(".activity-switch").click(ev => this._onSwitch(ev));
  }

  async _onSelection(event) {
    event.preventDefault();
    this.data.selectedRestType = event.currentTarget.value;
    this.render(true);
  }

  async _onSwitch(event) {
    event.preventDefault();
    this.data.noActivity = !this.data.noActivity;
    this.render(true);
  }

  async _onRpSpend(event) {
    event.preventDefault();
    await spendRestPoint(this.actor);
    this.render(true);
  }

  async _onRpRegained(event) {
    event.preventDefault();
    await regainRestPoint(this.actor);
    this.render(true);
  }

  async _onFinishRest(event) {
    event.preventDefault();
    const closeWindow = await finishRest(this.actor, this.data.selectedRestType, this.data.noActivity);
    if (closeWindow) this.close();
    else this.render(true);
  }

  async _onResetRest(event) {
    event.preventDefault();
    await resetLongRest(this.actor);
    this.render(true);
  }
}

/**
 * Creates RestDialog for given actor. 
 */
function createRestDialog(actor) {
  let dialog = new RestDialog(actor, {title: "Begin Resting"});
  dialog.render(true);
}

/**
 * Dialog window for using standard actions.
 */
class ActionsDialog extends Dialog {

  constructor(actor, dialogData = {}, options = {}) {
    super(dialogData, options);
    this.actor = actor;
    this.actions = {
      ...this._getOffensiveActions(),
      ...this._getDefensiveActions(),
      ...this._getUtilityActions(),
      ...this._getSkillBasedActions()
    };
  }

  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      template: "systems/dc20rpg/templates/dialogs/actions-dialog.hbs",
      classes: ["dc20rpg", "dialog"],
      width: 650,
      height: 550,
      tabs: [{ navSelector: ".dialog-tabs", contentSelector: ".dialog-body", initial: "offensive" }]
    });
  }

  getData() {
    return {
      offensive: this._getOffensiveActions(),
      defensive: this._getDefensiveActions(),
      utility: this._getUtilityActions(),
      skill: this._getSkillBasedActions(),
      reaction: this._getReactions()
    };
  }

   /** @override */
  activateListeners(html) {
    super.activateListeners(html);
    html.find(".roll-action").click(ev => this._rollActionForKey(datasetOf(ev)));
  }

  _rollActionForKey(dataset) {
    const key = dataset.key;
    const formulaKey = dataset.formulaKey;
    const action = this.actions[key];
    const selectedFormula = action.formulas[formulaKey];
    const flatAction = {
      description: action.description,
      name: action.name,
      formula: selectedFormula.formula,
      label: selectedFormula.label,
      apCost: selectedFormula.apCost,
      type: selectedFormula.type
    };
    rollFromAction(this.actor, flatAction);
  }

  _getOffensiveActions() {
    return {
      attack: this._attack(),
      disarm: this._disarm(),
      grapple: this._grapple(),
      shove: this._shove(),
      tackle: this._tackle()
    }
  }

  _getDefensiveActions() {
    return {
      disengage: this._disengage(),
      dodge: this._dodge(),
      hide: this._hide()
    }
  }

  _getUtilityActions() {
    return {
      move: this._move(),
      help: this._help(),
      object: this._object(),
      spell: this._spell()
    }
  }

  _getSkillBasedActions(){
    return {
      passThrough: this._passThrough(),
      analyzeCreature: this._analyzeCreature(),
      calmAnimal: this._calmAnimal(),
      combatInsight: this._combatInsight(),
      conceal: this._conceal(),
      feint: this._feint(),
      intimidate: this._intimidate(),
      investigate: this._investigate(),
      jump: this._jump(),
      mountedDefence: this._mountedDefence(),
      medicine: this._medicine(),
      search: this._search()
    }
  }

  _getReactions() {
    return {
      attackOfOpportunity: this._attackOfOpportunity(),
      spellDuel: this.spellDuel()
    }
  }

  //==================================
  //            OFFENSIVE            =
  //==================================
  _attack() {
    const description = "You can spend <b>1 AP</b> to make 1 <b>Attack Check</b>.";
    return {
      description: description,
      formulas: {
        attack: {
          label: "Attack Check",
          formula: "d20+@attackMod.value.martial",
          apCost: 1,
          type: "attackCheck"
        }
      },
      name: "Attack Action"
    }
  }
  _disarm() {
    const description = "You can spend <b>1 AP</b> to make an <b>Attack Check</b> Contested by " + 
    "the target's <b>Athletics</b>, <b>Acrobatics</b>, or <b>Trickery Check</b> (targets choice), " +
    "the target has ADV if they are holding the object with 2 hands. You have DisADV if the target " + 
    "is larger than you. You cannot Disarm a creature that is 2 Sizes larger than you." +
    "<br><br><b>Success:</b> The targeted object falls into an unoccupied space of your" + 
    "choice within 1 Spaces of the creature.";
    return {
      description: description,
      formulas: {
        disarm: {
          label: "Disarm (Attack Check)",
          formula: "d20+@attackMod.value.martial",
          apCost: 1,
          type: "attackCheck"
        }
      },
      name: "Disarm Action"
    }
  }
  _grapple() {
    const description = "Using a free hand, you can spend <b>1 AP</b> to attempt to <b>Grapple</b> " + 
    "another creature. Make an <b>Athletics Check</b> contested by the opposing creature's " + 
    "<b>Martial Check</b>. You or the target may have ADV or DisADV on your Check based on each other's size" +
    "(see Moving & Grappling Creatures). <br><b>Success:</b> The creature is <b>Grappled</b> by you." +
    "<br><br><b>Dragging:</b> You can move a creature that you have grappled to any Space " + 
    "adjacent to your own by spending your <b>Movement</b>. Alternatively, you can move the creature " + 
    "with you, but you are considered to be Slowed (Every 1 Space you move costs an extra 1 Space of movement)." + 
    "<br><br><b><u>Ending a Grapple</u></b> " + 
    "<ul><li><b>Escape Grapple:</b> You can spend <b>1 AP</b> to attempt to free yourself from a <b>Grapple</b>. " + 
    "Make a <b>Martial Check</b> contested by the opposing creatures <b>Athletics Check</b>. " + 
    "<br><b>Success:</b> You end the <b>Grappled</b> Condition on yourself. </li>" +
    "<li><b>Incapacitated Grappler:</b> If you become <b>Incapacitated</b>d, the Grapple immediately ends. </li>" +
    "<li><b>Forced Movement:</b> : If an effect attempts to forcibly move the target beyond your reach, you make " + 
    "the Check or Save instead of the target. If the effect targets both you and the target, you make 1 Check or Save for both of you." +
    "<br><b>Success:</b> The targets of the effect aren't moved." +
    "<br><b>Fail:</b> The Grapple immediately ends, and the targets of the effect are moved. </li>" +
    "<li><b>Falling:</b> If the target begins falling (and you don't), the Grapple ends if you can't carry the target's weight. " + 
    "If you can carry its weight, you hold it suspended in the air.</li></ul>";
    return {
      description: description,
      formulas: {
        grapple: {
          label: "Grapple (Athletics Check)",
          formula: "d20+@skills.ath.modifier",
          apCost: 1,
          type: "skillCheck"
        }
      },
      name: "Grapple Action"
    }
  }
  _shove() {
    const description = "You can spend <b>1 AP</b> to attempt to push a creature within 1 Space of you. " + 
    "Make an <b>Athletics Check</b> contested by the target's <b>Martial Check.</b> " + 
    "<br><b>Success:</b> You push the creature 1 Space away from you or to its left or right. " + 
    "<br><b>Success (each 5):</b> Push up to 1 additional Space." +
    "<br><br><b>Knock Prone:</b> After the result, you can choose to reduce the total distance " + 
    "the target is pushed by 1 Space to knock them <b>Prone</b> instead.";
    return {
      description: description,
      formulas: {
        shove: {
          label: "Shove (Athletics Check)",
          formula: "d20+@skills.ath.modifier",
          apCost: 1,
          type: "skillCheck"
        }
      },
      name: "Shove Action"
    }
  }
  _tackle() {
    const description = "If you move at least 2 Spaces in a straight line, you can spend <b>1 AP</b> " + 
    "to attempt to Tackle a creature that is your same size or smaller. " + 
    "Make an <b>Athletics Check</b> contested by the target's <b>Martial Check.</b> " + 
    "<br><br><b>Success:</b> You <b>Grapple</b> the target, you both move 1 Space in the same direction " + 
    "you're moving, and immediately fall <b>Prone</b>." + 
    "<br><b>Success (each 5):</b> +1 Space moved.";
    return {
      description: description,
      formulas: {
        tackle: {
          label: "Tackle (Athletics Check)",
          formula: "d20+@skills.ath.modifier",
          apCost: 1,
          type: "skillCheck"
        }
      },
      name: "Tackle Action"
    }
  }

  //==================================
  //            DEFENSIVE            =
  //==================================
  _disengage() {
    const description = "You can spend <b>1 AP</b> to impose DisADV on <b>Opportunity Attacks</b> made " + 
    "against you until the start of your next turn." + 
    "<br><br><b>Full Disengage:</b> When you take the <b>Disengage Action</b>, you can spend an additional " + 
    "<b>1 AP</b> to become immune to <b>Opportunity Attacks</b> until the start of your next turn.";
    return {
      description: description,
      formulas: {
        disengage: {
          label: "Disengage",
          apCost: 1
        },
        full: {
          label: "Full Disengage",
          apCost: 2
        }
      },
      name: "Disengage Action"
    }
  }
  _dodge() {
    const description = "You can spend <b>1 AP</b> to impose DisADV on on the next <b>Attack Check</b> " + 
    "or <b>Spell Check</b> made against you until the start of your next turn." + 
    "<br><br><b>Full Dodge:</b> When you take the <b>Dodge Action</b>, you can spend an additional " + 
    "<b>1 AP</b> to impose DisADV on all <b>Attacks</b> made against you until the start of your next turn.";
    return {
      description: description,
      formulas: {
        disengage: {
          label: "Dodge",
          apCost: 1
        },
        full: {
          label: "Full Dodge",
          apCost: 2
        }
      },
      name: "Dodge Action"
    }
  }
  _hide() {
    const description = "You can spend <b>1 AP</b> to attempt to <b>Hide</b> from 1 or more creatures that can't see " +
    "you (<b>Unseen</b>). Make a <b>Stealth Check</b> against the opposing creatures <b>Passive Awareness</b>. " + 
    "<br><b>Success:</b> You become <b>Hidden</b> from creatures whose <b>Passive Awareness</b> you beat, (making you <b>Unseen</b> and <b>Unheard</b> by them). " +
    "You remain <b>Hidden</b> until you make a noise louder than a whisper, make an <b>Attack</b>, " +
    "cast a <b>Spell</b> with a <b>Verbal Component</b>, or a creature takes the <b>Search Action</b> and successfully " +
    "locates you. <ul>" + 
    "<li><b>Unheard:</b> You are Unheard while you remain silent, talk no louder than a whisper, or are within an area affected by the Silence Spell." +
    "<li><b>Unseen:</b> You are Unseen by a creature while you are imperceivable to its visual senses, such as when you are outside its <b>Line of Sight</b> " + 
    "(behind <b>Full Cover</b>), it's <b>Blinded</b>, or you are obscured from it such as by being <b>Invisible</b>. " +
    "Creatures that can't see you are <b>Exposed</b> (your Attacks against them have ADV) and <b>Hindered</b> against you (they have DisADV on Attacks against you)." +
    "<li><b>Hidden:</b> While you are both <b>Unheard</b> and <b>Unseen</b>, you are considered <b>Hidden</b>, and your location or presence unknown to other creatures." +
    "</ul><br>(see “Hidden Creatures” for more info).";
    return {
      description: description,
      formulas: {
        hide: {
          label: "Hide (Stealth Check)",
          formula: "d20+@skills.ste.modifier",
          apCost: 1,
          type: "skillCheck"
        }
      },
      name: "Hide Action"
    }
  }

  //==================================
  //             UTILITY             =
  //==================================
  _move() {
    const description = "You can spend <b>1 AP</b> to move up to your Speed in Spaces (default of 4). " +
    "It chooses where to move, and can break up its movement by moving before and after taking " +
    "a different <b>Action</b>. You can't end your turn in a Space occupied by another creature.";
    return {
      description: description,
      formulas: {
        move: {
          label: "Move",
          apCost: 1
        },
      },
      name: "Move Action"
    }
  }
  _help() {
    const description = "You can spend <b>1 AP</b> to grant a creature a <b>d8</b> <b>Help Die</b> " +
    "that lasts until the start of your next turn. Upon granting the <b>Help Die</b>, you must declare which Creature you are " + 
    "Helping and the type of Check you will be aiding them with, while meeting the following conditions: <ul>" +
    "<li> <b>Attack:</b> You declare 1 target for the Check. You must be within 1 Space of " + 
    "the Attacker or the target of the Attack. While the <b>Help Die</b> lasts, it can be added to the <b>Attack</b> made against the target." +
    "<li> <b>Skill or Trade Check:</b> You declare a type of Skill or Trade Check. You describe how you are Helping them " +
    "and must do so using a Skill or Trade that you have at least 1 Mastery Level in. You can use the same " +
    "Skill or Trade or a different one. </ul>" + 
    "<br>The <b>Help Die</b> can only be used to aid the type of Check declared." +
    "<br><br><b>Multiple Help Penalty:</b> Once you take the Help Action, each time you take the " + 
    "Help Action again before the end of your turn, your <b>Help Die</b> decay by 1 step, to a minimum of a d4 " +
    "(d8 | d6 | d4). These Help Dice only decay when using the Help Action. Help Die granted by other sources (such as the Sword Maneuver) " +
    "decay independently of any Help Dice grant through the Help Action.";
    return {
      description: description,
      formulas: {
        help: {
          label: "Help",
          apCost: 1
        },
      },
      name: "Help Action"
    }
  }
  _object() {
    const description = "You can spend <b>1 AP</b> to perform 1 of the following object interactions: <br><ul>" +
    "<li> Drink a Potion or Administer a Potion to another Creature." +
    "<li> Attempt to Lock or Unlock a Lock." +
    "<li> Make a <b>Trickery Check</b> to activate or disable a trap or other mechanism." +
    "<li> Transfer and Item to or from another Creature (only 1 of the two creatures spends <b>1 AP</b>)." +
    "<li> Throw an Item to location you can see up to 5 Spaces away." +
    "</ul>";
    return {
      description: description,
      formulas: {
        object: {
          label: "Object",
          apCost: 1
        },
      },
      name: "Object Action"
    }
  }
  _spell() {
    const description = "You can spend 1 or more <b>AP</b> to cast a <b>Spell</b> that you know. If the <b>Spell</b> has a <b>Mana Point</b> requirement, you must spend that much <b>MP</b> to cast the <b>Spell</b>.";
    return {
      description: description,
      formulas: {
        spell: {
          label: "Spell",
          apCost: 1
        },
      },
      name: "Spell Action"
    }
  }

  //==================================
  //           SKILL BASED           =
  //==================================
  _passThrough() {
    const description = "You can spend <b>1 AP</b> to attempt to move through a Space occupied by a hostile " +
    "creature that's within 1 size of you. Make a contested <b>Martial Check</b> against the target." +
    "<br><br><b>Success:</b> You can move through the creature's Space as if it were <b>Difficult Terrain</b>" + 
    "(<b>Slowed 1</b> while moving through the area).";
    return {
      description: description,
      formulas: {
        passThrough: {
          label: "Pass Through (Martial Check)",
          formula: "d20+max(@skills.acr.modifier, @skills.ath.modifier)",
          apCost: 1,
          type: "skillCheck"
        }
      },
      name: "Pass Through"
    }
  }
  _analyzeCreature() {
    const description = "You can spend <b>1 AP</b> to attempt to recall or discern some information " +
    "about a creature that you can see or hear. Make a <b>DC 10 Knowledge Check</b> determined by the GM." +
    "<br><br><b>Success:</b> You learn a piece of lore about the creature." + 
    "<br><b>Success(5):</b> You learn 1 creature statistic (PD, MD, Attacks, Abilities, Resistances, Vulnerabilities, Immunities, etc.)." +
    "<br><b>Success(10):</b> +1 creature statistic.";
    return {
      description: description,
      formulas: {
        arcana: {
          label: "Arcana",
          formula: "d20+@skills.arc.modifier",
          apCost: 1,
          type: "skillCheck"
        },
        history: {
          label: "History",
          formula: "d20+@skills.his.modifier",
          apCost: 1,
          type: "skillCheck"
        },
        nature: {
          label: "Nature",
          formula: "d20+@skills.nat.modifier",
          apCost: 1,
          type: "skillCheck"
        },
        occultism: {
          label: "Occultism",
          formula: "d20+@skills.occ.modifier",
          apCost: 1,
          type: "skillCheck"
        },
        religion: {
          label: "Religion",
          formula: "d20+@skills.rel.modifier",
          apCost: 1,
          type: "skillCheck"
        },
      },
      name: "Analyze Creature"
    }
  }
  _calmAnimal() {
    const description = "You can spend <b>1 AP</b> to attempt to beguile a Beast that can see or hear you. " +
    + "Make an <b>Animal Check</b> contested by the target's <b>Charisma Save</b>." +
    "<br><br><b>Success:</b> The animal is <b>Taunted</b> by you for 1 minute (Repeated Save) or until you target it with a harmful <b>Attack</b>, <b>Spell</b>, or other effect." + 
    "<br><b>Success(5):</b> It's also <b>Impaired</b>." +
    "<br><b>Success(10):</b> It's also <b>Charmed</b>.";
    return {
      description: description,
      formulas: {
        calmAnimal: {
          label: "Calm Animal (Animal Check)",
          formula: "d20+@skills.ani.modifier",
          apCost: 1,
          type: "skillCheck"
        }
      },
      name: "Calm Animal"
    }
  }
  _combatInsight() {
    const description = "You can spend <b>1 AP</b> to attempt to discern the course of actions a creature might " + 
    "take on its next turn. Make an <b>Insight Check</b> contested by the target's <b>Trickery</b> or <b>Influence Check</b> (its choice)." +
    "<br><br><b>Success:</b> You learn the target's emotional state and whether it plans to make an <b>Attack</b>, cast a <b>Spell</b>, or flee combat during its next turn." + 
    "<br><b>Success(5):</b> You know who the creature is likely to target with a harmful ability." +
    "<br><b>Success(10):</b> You know which ability the creature plans to use.";
    return {
      description: description,
      formulas: {
        combatInsight: {
          label: "Combat Insight (Insight Check)",
          formula: "d20+@skills.ins.modifier",
          apCost: 1,
          type: "skillCheck"
        }
      },
      name: "Combat Insight"
    }
  }
  _conceal() {
    const description = "You can spend <b>1 AP</b> to hide an object on yourself or in nearby foliage, debris, or decor to render it <b>Hidden</b>. " + 
    "Make a contested <b>Trickery Check</b> against the <b>Passive Awareness</b> of creatures that can see you." +
    "<br><br><b>Success:</b> The object is <b>Hidden</b> from any creature whose <b>Passive Awareness</b> you beat.";
    return {
      description: description,
      formulas: {
        conceal: {
          label: "Conceal (Trickery Check)",
          formula: "d20+@skills.tri.modifier",
          apCost: 1,
          type: "skillCheck"
        }
      },
      name: "Conceal"
    }
  }
  _feint() {
    const description = "You can spend <b>1 AP</b> to make <b>Trickery Check</b> contested by the target's <b>Insight Check</b>." +
    "<br><br><b>Success:</b> The next <b>Attack</b> against the target before the start of your next turn has ADV and deals +1 damage.";
    return {
      description: description,
      formulas: {
        feint: {
          label: "Feint (Trickery Check)",
          formula: "d20+@skills.tri.modifier",
          apCost: 1,
          type: "skillCheck"
        }
      },
      name: "Feint"
    }
  }
  _intimidate() {
    const description = "You can spend <b>1 AP</b> to attempt to intimidate a creature that can see or hear you." + 
    "Make a contested <b>Intimidation Check</b> contested by the target's <b>Charisma Save</b>." +
    "<br><br><b>Success:</b> The target is <b>Intimidated</b> by you until the end of your next turn.";
    return {
      description: description,
      formulas: {
        intimidate: {
          label: "Intimidate (Intimidation Check)",
          formula: "d20+@skills.inm.modifier",
          apCost: 1,
          type: "skillCheck"
        }
      },
      name: "Intimidate"
    }
  }
  _investigate() {
    const description = "You can spend <b>1 AP</b> to attempt to uncover a concealed object on a creature, a " +
    "secret compartment, or the intended function of a mechanism within 1 Space of you. <ul>" + 
    "<li><b>Concealed Objects:</b> You can attempt to uncover any objects concealed on a creature. Make an <b>Investigation Check</b> contested by the target's <b>Trickery Check</b>. " +
    "<br><b>Success:</b> You know the location of any concealed object on the creature." +
    "<li><b>Secret Compartments:</b> You can attempt to uncover any secret compartments. Make an <b>Investigation Check</b> against the <b>discovery DC</b> of any secret compartments. " +
    "<br><b>Success:</b> You discover the location of any secret compartments whose <b>discovery DC</b> you beat." +
    "<li><b>Discern Mechanism:</b> You can attempt to discern the functionality of a mechanism (the effect of a trap, how to open a secret door, or activate a device). " +
    "Make an <b>Investigation Check</b>. " +
    "<br><b>Success:</b> You learn how the mechanism works and the methods to activate and disable it (if any)." +
    "</ul>";
    return {
      description: description,
      formulas: {
        investigate: {
          label: "Investigate (Investigation Check)",
          formula: "d20+@skills.inv.modifier",
          apCost: 1,
          type: "skillCheck"
        }
      },
      name: "Investigate"
    }
  }
  _jump() {
    const description = "You can spend <b>1 AP</b> to attempt to increase the distance you can cover when Jumping. Make a <b>DC 10 Martial Check</b>. <ul>" + 
    "<li><b>Long Jump Success:</b> You can move 1 additional Space as part of your Long Jump. <br><b>Success(each 5):</b> +1 additional Space." +
    "<li><b>High Jump Success:</b> : You can move an additional 1ft (30cm) as part of your High Jump. <br><b>Success(each 5):</b> +1ft (30cm)." +
    "</ul>";
    return {
      description: description,
      formulas: {
        jump: {
          label: "Jump (Martial Check)",
          formula: "d20+max(@skills.acr.modifier, @skills.ath.modifier)",
          apCost: 1,
          type: "skillCheck"
        }
      },
      name: "Jump"
    }
  }
  _mountedDefence() {
    const description = "You can spend <b>1 AP</b> to maneuver a mount you are riding to avoid danger. Make a <b>DC 10 Animal Check</b>." +
    "<br><br><b>Success:</b> The mount's PD increases by 2 until the start of your next turn." + 
    "<br><b>Success(5):</b> +2 PD." +
    "<br><b>Success(10):</b> +4 PD.";
    return {
      description: description,
      formulas: {
        mountedDefence: {
          label: "Mounted Defence (Animal Check)",
          formula: "d20+@skills.ani.modifier",
          apCost: 1,
          type: "skillCheck"
        }
      },
      name: "Mounted Defence"
    }
  }
  _medicine() {
    const description = "You can spend <b>1 AP</b> to touch a creature and tend to its wounds. Make a <b>DC 10 Medicine Check</b>." + 
    "<br><br><b>Success:</b> You stop its Bleeding or Stabilize it (your choice)." + 
    "<br><b>Success(5):</b> The creature gains +1 Temp HP.";
    return {
      description: description,
      formulas: {
        medicine: {
          label: "Medicine (Medicine Check)",
          formula: "d20+@skills.med.modifier",
          apCost: 1,
          type: "skillCheck"
        }
      },
      name: "Medicine"
    }
  }
  _search() {
    const description = "You can spend <b>1 AP</b> to attempt to locate 1 or more <b>Hidden</b> creatures and concealed objects within your Line of Sight. <ul>" +
    "<li><b>Hidden Creatures:</b> You attempt to locate any <b>Hidden</b> creatures in the area. Make an <b>Awareness Check</b> against the <b>Stealth Check</b> of any Hidden creatures." +
    "<br><b>Success:</b> You know the location of any <b>Hidden</b> creature whose <b>Stealth Check</b> you beat until the end of your turn. " + 
    "<li><b>Hidden Objects:</b> You attempt to locate any <b>Hidden</b> objects in the area. Make an <b>Awareness Check</b> against the DC to discover any concealed objects (such as traps, secret doors, or hidden items)." +
    "<br><b>Success:</b> You discover the location of any <b>Hidden</b> object whose discovery DC you beat. " + 
    "</ul>";
    return {
      description: description,
      formulas: {
        search: {
          label: "Search (Awareness Check)",
          formula: "d20+@skills.awa.modifier",
          apCost: 1,
          type: "skillCheck"
        }
      },
      name: "Search"
    }
  }

  //==================================
  //            REACTION             =
  //==================================
  _attackOfOpportunity() {
    const description = "<i><b><u>Prerequisite:</u></b> any Martial Class Feature</i>" + 
    "<br><br><b>Trigger:</b> A creature you can see within your Melee Range, uses its movement to leave your Melee Range, stands up " +
    "from Prone, picks up an item off the ground, or takes the <b>Object Action</b>." + 
    "<br><br><b>Reaction:</b> You can spend <b>1 AP</b> to make an Attack Check with an Unarmed Strike or a Melee Weapon that you are wielding " +
    "against the provoking creature. You can spend additional <b>AP</b> to gain <b>ADV</b> or to perform Maneuvers with the Attack.";
    return {
      description: description,
      formulas: {
      },
      name: "Attack Of Opportunity"
    }
  }

  spellDuel() {
    const description = "<i><b><u>Prerequisite:</u></b> any Spellcasting Class Feature</i>" + 
    "<br><br><b>Trigger:</b> When another creature that you can see casts a Spell. " +
    "<br><br><b>Reaction:</b> You declare a Spell Duel and spend <b>2 AP</b> and 1 or more <b>MP</b> to challenge the creature with a Spell of your own. " + 
    "You can declare a Spell Duel after the creature makes its Spell Check but before you know the result of its Check. " + 
    "<br><br><b>Multiple Participants:</b> Additional creatures can choose to participate in helping the Spell take effect or participate in " + 
    "stopping the Spell from taking effect. If multiple creatures choose to participate in the Spell Duel, the participants are " +
    "sorted into <b>Initiators</b> (those trying to help the Spell take effect) and <b>Challengers</b> (those trying to prevent the Spell " +
    "from taking effect). " + 
    "<br>During the Contest (see further below) every participant makes their Spell Check, and the highest Initiator result is compared " + 
    "against the highest Challenger result to determine the outcome." +
    "<br><br><b>Choosing a Spell:</b> You declare which Spell you are using to challenge the opposing Spell and then describe how " + 
    "you do so using your Spell. The GM decides if that makes sense." +
    "<br><b>Targeted:</b> If your chosen Spell targets 1 or more creatures or objects, you must be able to target the opposing creature " + 
    "or any of its targets with your Spell." +
    "<br><b>Area of Effect:</b> If your chosen Spell covers an area (such as an Arc, Cone, Cube, Cylinder, Line, or Sphere), then your Spell's " +
    "Area of Effect must include the opposing creature, any of its targets, or cover an area between the opposing creature and any of its targets." +
    "<br><b>Success & Failure:</b> The success and failure statements of your Spell are replaced by the success and failure statements in the Contest section below." +
    "<br><br><b><u>Contest</b></u><br>" +
    "The Spell Check the opposing creature makes to cast its Spell is Contested by the Spell Check you make to cast your Spell. When comparing the Spell Checks for the " + 
    "purpose of determining the winner of the Contest, each creature gains a bonus to its Check equal to the MP it spent on its Spell." +
    "<br><b>• Success:</b> The target creature's Spell fails and has no effect." + 
    "<br><b>• Failure:</b> The target creature's Spell succeeds and takes effect." + 
    "<br><b>• Tie:</b> The target creature's Spell fails, has no effect, and you each roll on the Wild Magic Surge Table.The effect from the table lasts until the end of your next turn." + 
    "Whatever the result, each creature still spends all AP, MP, or other resources they spent to cast their Spell.";
    return {
      description: description,
      formulas: {
      },
      name: "Spell Duel"
    }
  }
}

/**
 * Creates ActionsDialog for given actor. 
 */
function createActionsDialog(actor) {
  let dialog = new ActionsDialog(actor, {title: "Actions"});
  dialog.render(true);
}

/**
 * Dialog window for different actor configurations.
 */
class ActorConfigurationDialog extends Dialog {

  constructor(actor, type, data, dialogData = {}, options = {}) {
    super(dialogData, options);
    this.actor = actor;
    this.type = type;
    this.data = data;
  }

  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      classes: ["dc20rpg", "dialog"]
    });
  }

  /** @override */
  get template() {
    return `systems/dc20rpg/templates/dialogs/configuration/${this.type}.hbs`;
  }

  getData() {
    switch (this.type) {
      case "defence":
        return this._getDataForDefence();
      
      case "customResource": 
        return this._getDataForCustomResource();

      case "jump": 
        return this._getDataForJump();
    }
    return {};
  }
  _getDataForDefence() {
    const defenceKey = this.data.defenceKey;
    const defence = this.actor.system.defences[defenceKey];
    let defenceLabels;
    let selectedFormula;

    switch (defenceKey) {
      case "physical": 
        selectedFormula = DC20RPG.physicalDefenceFormulas[defence.formulaKey];
        defenceLabels = DC20RPG.physicalDefenceFormulasLabels; 
        break;
      
      case "mental": 
        selectedFormula = DC20RPG.mentalDefenceFormulas[defence.formulaKey];
        defenceLabels = DC20RPG.mentalDefenceFormulasLabels; 
        break;
    }
    if (defence.formulaKey === 'custom') selectedFormula = defence.customFormula;
    if (defence.formulaKey !== 'flat') defence.normal = evaulateDicelessFormula(selectedFormula, this.actor.getRollData()).total;
    
    return {
      selectedFormulaKey: defence.formulaKey,
      customFormula: defence.customFormula,
      defenceValue: defence.normal,
      selectedFormula: selectedFormula,
      defenceLabels: defenceLabels,
      defenceKey: defenceKey
    }
  }
  _getDataForCustomResource() {
    const resourceKey = this.data.resourceKey;
    const resource = this.actor.system.resources.custom[resourceKey];
    const resetTypes = DC20RPG.resetTypes;

    return {
      ...resource,
      resetTypes,
      resourceKey
    }
  }
  _getDataForJump() {
    const selectedAttribute = this.actor.system.jump.attribute;
    const jumpAttributes = DC20RPG.attributesWithPrime;
    return {
      selectedAttribute: selectedAttribute,
      jumpAttributes
    }
  }

   /** @override */
  activateListeners(html) {
    super.activateListeners(html);
    html.find(".save").click((ev) => this._onSave(ev));
    html.find(".selectable").change(ev => this._onValueChange(datasetOf(ev).path, valueOf(ev)));
    html.find(".input").change(ev => this._onValueChange(datasetOf(ev).path, valueOf(ev)));
    html.find(".numeric-input").change(ev => this._onNumericValueChange(datasetOf(ev).path, valueOf(ev)));
  }
  _onSave(event) {
    event.preventDefault();
    const updatePath = this.data.updatePath;
    const updateData = getValueFromPath(this.actor, this.data.updatePath);
    if (updateData.bonus) delete updateData.bonus; // We do not want to commit any bonuses
    this.actor.update({ [updatePath] : updateData });
    this.close();
  }
  _onValueChange(path, value) {
    setValueForPath(this.actor, path, value);
    this.render(true);
  }
  _onNumericValueChange(path, value) {
    const numericValue = parseInt(value);
    setValueForPath(this.actor, path, numericValue);
    this.render(true);
  }
}

function _createActorConfigurationDialog(actor, type, data = {}, dialogData = {}) {
  const dialog = new ActorConfigurationDialog(actor, type, data, dialogData);
  dialog.render(true);
}

function configureDefence(actor, defenceKey) {
  const data = {
    defenceKey: defenceKey, 
    updatePath: `system.defences.${defenceKey}`
  };
  const defenceLabel = getLabelFromKey(defenceKey, DC20RPG.defences);
  const dialogData = {title: `Configure ${defenceLabel} Defence`};
  _createActorConfigurationDialog(actor, "defence", data, dialogData);
}

function configureJump(actor) {
  const data = {
    updatePath: "system.jump.attribute"
  };
  const dialogData = {title: `Configure Jump Distance`};
  _createActorConfigurationDialog(actor, "jump", data, dialogData);
}

function configureCustomResource(actor, resourceKey) {
  const data = {
    resourceKey: resourceKey,
    updatePath: `system.resources.custom.${resourceKey}`
  };
  const resourceName = actor.system.resources.custom[resourceKey].name;
  _createActorConfigurationDialog(actor, "customResource", data, {title: `Configure ${resourceName}`});
}

/**
 * Extend the basic ActorSheet with some very simple modifications
 * @extends {ActorSheet}
 */
class DC20RpgActorSheet extends ActorSheet {

  /** @override */
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      classes: ["dc20rpg", "sheet", "actor"], //css classes
      width: 755,
      height: 850,
      tabs: [{ navSelector: ".sheet-tabs", contentSelector: ".sheet-body", initial: "skills" }]
    });
  }

  /** @override */
  get template() {
    return `systems/dc20rpg/templates/actor/actor-${this.actor.type}-sheet.hbs`;
  }

  /** @override */
  async getData() {
    const context = super.getData();

    context.config = DC20RPG;
    context.type = this.actor.type;
    context.system = this.actor.system;
    context.flags = this.actor.flags;
    // Sorting items
    context.items = sortMapOfItems(this.actor.items);
    context.itemChargesAsResources = {};
    context.itemQuantityAsResources = {};

    // Getting data to simpler objects to use it easier on sheet
    context.display = {};

    if (this.actor.type == 'character') {
      await this._prepareItemsForCharacter(context);
    }
    if (this.actor.type == 'npc') {
      await this._prepareItemsForNpc(context);
      context.isNPC = true;
    }
    this._prepareTranslatedLabels(context);
    this._prepareResourceBarsPercentages(context);
    this._determineIfDmgReductionIsEmpty(context);

    // Prepare active effects
    context.effects = prepareActiveEffectCategories(this.actor.effects);

    // Enrich text editors
    context.enriched = {};
    context.enriched.journal = await TextEditor.enrichHTML(context.system.journal, {async: true});

    return context;
  }

  /** @override */
  activateListeners(html) {
    super.activateListeners(html);
    this._alwaysActiveListeners(html);
    this._editActiveListeners(html);
  }

  /** @override */
  _onSortItem(event, itemData) {
    // Get the drag source and drop target
    const items = this.actor.items;
    const source = items.get(itemData._id);
  
    let dropTarget = event.target.closest("[data-item-id]");

    // We dont want to change tableName if item is sorted on Attacks table
    const itemRow = event.target.closest("[data-item-attack]");
    const isAttack = itemRow ? true : false;
  
    // if itemId not found we want to check if user doesn't dropped item on table header
    if (!dropTarget) {
      dropTarget = event.target.closest("[data-table-name]"); 
      if (!dropTarget || isAttack) return;
      source.update({["system.tableName"]: dropTarget.dataset.tableName});
      return;
    }
  
    const target = items.get(dropTarget.dataset.itemId);
  
    // Don't sort on yourself
    if ( source.id === target.id ) return;
  
    // Identify sibling items based on adjacent HTML elements
    const siblings = [];
    for ( let el of dropTarget.parentElement.children ) {
      const siblingId = el.dataset.itemId;
      if ( siblingId && (siblingId !== source.id) ) {
        siblings.push(items.get(el.dataset.itemId));
      } 
    }
  
    // Perform the sort
    const sortUpdates = SortingHelpers.performIntegerSort(source, {target, siblings});
    const updateData = sortUpdates.map(u => {
      const update = u.update;
      update._id = u.target._id;
      return update;
    });
  
    // Change items tableName to targets one, skip this if item was sorted on attack row
    if (!isAttack) {
      source.update({["system.tableName"]: target.system.tableName});
    }
  
    // Perform the update
    return this.actor.updateEmbeddedDocuments("Item", updateData);
  }

  //================================
  //           Get Data            =  
  //================================
  async _prepareItemsForCharacter(context) {
    const headersOrdering = context.flags.dc20rpg.headersOrdering;

    // Initialize containers with ordered table names.
    const inventory = this._prepareTableHeadersInOrder(headersOrdering.inventory);
    const features = this._prepareTableHeadersInOrder(headersOrdering.features);
    const techniques = this._prepareTableHeadersInOrder(headersOrdering.techniques);
    const spells = this._prepareTableHeadersInOrder(headersOrdering.spells);

    const attacks = {}; // Special container for items recognized as attacks, for easy access in 'techniques' tab

    // Iterate through items, allocating to containers  
    for (let item of context.items) {
      item.img = item.img || DEFAULT_TOKEN;
      let tableName = capitalize(item.system.tableName);

      // Append to inventory
      if (['weapon', 'equipment', 'consumable', 'loot', 'tool'].includes(item.type)) {
        if (!inventory[tableName]) addNewTableHeader(this.actor, tableName, "inventory");
        else inventory[tableName].items[item.id] = item;
      }
      // Append to features
      else if (item.type === 'feature') {
        if (!features[tableName]) addNewTableHeader(this.actor, tableName, "features");
        else features[tableName].items[item.id] = item;
      }
      // Append to techniques
      else if (item.type === 'technique') {
        if (!techniques[tableName]) addNewTableHeader(this.actor, tableName, "techniques");
        else  techniques[tableName].items[item.id] = item;
      }
      // Append to spells
      else if (item.type === 'spell') {
        if (!spells[tableName]) addNewTableHeader(this.actor, tableName, "spells");
        else spells[tableName].items[item.id] = item;
      }
      // Append to class
      else if (item.type === 'class') context.class = item;
      // Append to subclass
      else if (item.type === 'subclass') context.subclass = item;
      // Append to ancestry
      else if (item.type === 'ancestry') context.ancestry = item;
      // Append to background
      else if (item.type === 'background') context.background = item;

      await this._prepareItemAsResource(item, context);
      this._prepareItemUsageCosts(item);
      this._prepareItemEnhancements(item);
    }

    // Remove empty tableNames (except for core that should stay) and assign
    context.inventory = enhanceItemTab(inventory, ["Weapons", "Equipment", "Consumables", "Tools", "Loot"]);
    context.features = enhanceItemTab(features, ["Features"]);
    context.techniques = enhanceItemTab(techniques, ["Techniques"]);
    context.spells = enhanceItemTab(spells, ["Spells"]);
    context.attacks = attacks;
  }

  async _prepareItemsForNpc(context) {
    const headersOrdering = context.flags.dc20rpg.headersOrdering;

    // Initialize containers with ordered table names.
    const items = this._prepareTableHeadersInOrder(headersOrdering.items);

    // Iterate through items, allocating to containers  
    for (let item of context.items) {
      item.img = item.img || DEFAULT_TOKEN;
      let tableName = capitalize(item.system.tableName);

      // Append to items
      if (["Weapons", "Equipment", "Consumables", "Tools", "Loot"].includes(tableName)) {
        const itemCosts = item.system.costs;
        if (itemCosts && itemCosts.resources.actionPoint !== null) items["Actions"].items[item.id] = item;
        else items["Inventory"].items[item.id] = item;
      }
      else {
        if (!items[tableName]) addNewTableHeader(this.actor, tableName, "items");
        else items[tableName].items[item.id] = item;
      }

      await this._prepareItemAsResource(item, context);
      this._prepareItemUsageCosts(item);
      this._prepareItemEnhancements(item);
    }
    // Remove empty tableNames (except for core that should stay) and assign
    context.items = enhanceItemTab(items, ["Actions", "Features", "Techniques", "Inventory", "Spells"]);
  }

  _prepareTableHeadersInOrder(order) {
    // Sort
    let sortedTableHeaders = Object.entries(order).sort((a, b) => a[1] - b[1]);

    let tableHeadersInOrder = {};
    sortedTableHeaders.forEach(tableName => {
      tableHeadersInOrder[tableName[0]] = {
        items: {},
        siblings: {}
      };
    });

    return tableHeadersInOrder;
  }

  _prepareResourceBarsPercentages(context) {
    const hpCurrent = context.system.resources.health.current;
    const hpMax = context.system.resources.health.max;
    const hpPercent = Math.ceil(100 * hpCurrent/hpMax);
    if (isNaN(hpPercent)) context.system.resources.health.percent = 0;
    else context.system.resources.health.percent = hpPercent <= 100 ? hpPercent : 100;

    const hpValue = context.system.resources.health.value;
    const hpPercentTemp = Math.ceil(100 * hpValue/hpMax);
    if (isNaN(hpPercent)) context.system.resources.health.percentTemp = 0;
    else context.system.resources.health.percentTemp = hpPercentTemp <= 100 ? hpPercentTemp : 100;

    const manaCurrent = context.system.resources.mana.value;
    const manaMax = context.system.resources.mana.max;
    const manaPercent = Math.ceil(100 * manaCurrent/manaMax);
    if (isNaN(manaPercent)) context.system.resources.mana.percent = 0;
    else context.system.resources.mana.percent = manaPercent <= 100 ? manaPercent : 100;

    const staminaCurrent = context.system.resources.stamina.value;
    const staminaMax = context.system.resources.stamina.max;
    const staminaPercent = Math.ceil(100 * staminaCurrent/staminaMax);
    if (isNaN(staminaPercent)) context.system.resources.stamina.percent = 0;
    else context.system.resources.stamina.percent = staminaPercent <= 100 ? staminaPercent : 100;
  }

  _determineIfDmgReductionIsEmpty(context) {
    const dmgTypes = context.system.damageReduction.damageTypes;
    for (const [key, dmgType] of Object.entries(dmgTypes)) {
      dmgType.notEmpty = false;
      if (dmgType.immune) dmgType.notEmpty = true;
      if (dmgType.resistance) dmgType.notEmpty = true;
      if (dmgType.vulnerability) dmgType.notEmpty = true;
      if (dmgType.vulnerable) dmgType.notEmpty = true;
      if (dmgType.resist) dmgType.notEmpty = true;
    }
  }

  _prepareTranslatedLabels(context) {
    // Prepare attributes labels.
    for (let [key, attribute] of Object.entries(context.system.attributes)) {
      attribute.label = game.i18n.localize(CONFIG.DC20RPG.trnAttributes[key]) ?? key;
    }

    // Prepare skills labels.
    for (let [key, skill] of Object.entries(context.system.skills)) {
      if (!skill.custom) skill.label = game.i18n.localize(CONFIG.DC20RPG.trnSkills[key]) ?? key;
    }

    if (this.actor.type == 'character') {
      // Prepare trade skills labels.
      for (let [key, skill] of Object.entries(context.system.tradeSkills)) {
        skill.label = game.i18n.localize(CONFIG.DC20RPG.trnSkills[key]) ?? key;
      }
    }

    // Prepare languages labels.
    for (let [key, language] of Object.entries(context.system.languages)) {
      if (!language.custom) language.label = game.i18n.localize(CONFIG.DC20RPG.trnLanguages[key]) ?? key;
    }

    // Prepare damage reduction labels.
    for (let [key, resistance] of Object.entries(context.system.damageReduction.damageTypes)) {
      resistance.label = game.i18n.localize(CONFIG.DC20RPG.trnReductions[key]) ?? key;
    }

    // Prepare condition immunities
    for (let [key, condition] of Object.entries(context.system.immunities.conditions)) {
      // condition.label = game.i18n.localize(CONFIG.DC20RPG.conditions[key]) ?? key;
      condition.label = getLabelFromKey(key, CONFIG.DC20RPG.conditions);
    }
  }

  async _prepareItemAsResource(item, context) {
    await this._prepareItemChargesAsResource(item, context);
    await this._prepareItemQuantityAsResource(item, context);
  }

  async _prepareItemChargesAsResource(item, context) {
    if (!item.system.costs) return;
    if (!item.system.costs.charges.showAsResource) return;

    const collectedItem = await item;
    const itemCharges = collectedItem.system.costs.charges;
    context.itemChargesAsResources[collectedItem.id] = {
      img: collectedItem.img,
      name: collectedItem.name,
      value: itemCharges.current,
      max: itemCharges.max
    };
  }

  async _prepareItemQuantityAsResource(item, context) {
    if (item.type !== "consumable") return;
    if (item.system.quantity === undefined) return;
    if (!item.system.showAsResource) return;

    const collectedItem = await item;
    context.itemQuantityAsResources[collectedItem.id] = {
      img: collectedItem.img,
      name: collectedItem.name,
      quantity: item.system.quantity
    };
  }

  _prepareItemUsageCosts(item) {
    item.usageCosts = getItemUsageCosts(item, this.actor);
  }

  _prepareItemEnhancements(item) {
    // Collect item Enhancements
    let enhancements = item.system.enhancements;
    if (enhancements) Object.values(enhancements).forEach(enh => enh.itemId = item._id);

    // If selected collect Used Weapon Enhancements 
    const usesWeapon = item.system.usesWeapon;
    if (usesWeapon) {
      const weapon = this.actor.items.get(usesWeapon);
      if (weapon) {
        let weaponEnh = weapon.system.enhancements;
        if (weaponEnh) Object.values(weaponEnh).forEach(enh => {
          enh.itemId = usesWeapon;
          enh.fromWeapon = true;
        });
        enhancements = {
          ...enhancements,
          ...weaponEnh
        };
      }
    }

    if (!enhancements) item.enhancements = {};
    else item.enhancements = enhancements;
  }

  //===========================================
  //           Activate Listerners            =  
  //===========================================
  _alwaysActiveListeners(html) {
    // Rolls
    html.find('.rollable').click(ev => {
      if (this.actor.system.rollMenu.initiative) {
        rollForInitiative(this.actor, datasetOf(ev));
        this.actor.update({["system.rollMenu.initiative"]: false});
      }
      else rollFromSheet(this.actor, datasetOf(ev));
    });
    html.find('.roll-item').click(ev => rollFromItem(datasetOf(ev).itemId, this.actor, true, ev.altKey));
    html.find('.variable-roll').click(ev => createVariableRollDialog(datasetOf(ev), this.actor));

    // Togglers
    html.find(".skill-mastery-toggle").mousedown(ev => toggleSkillMastery(datasetOf(ev).path, ev.which, this.actor));
    html.find(".language-mastery-toggle").mousedown(ev => toggleLanguageMastery(datasetOf(ev).key, ev.which, this.actor));
    html.find(".skill-expertise-toggle").mousedown(ev => toggleExpertise(datasetOf(ev).path, ev.which, this.actor));
    html.find(".activable").click(ev => changeActivableProperty(datasetOf(ev).path, this.actor));
    html.find(".item-activable").click(ev => changeActivableProperty(datasetOf(ev).path, getItemFromActor(datasetOf(ev).itemId, this.actor)));
    html.find(".exhaustion-toggle").mousedown(ev => toggleUpOrDown(datasetOf(ev).path, ev.which, this.actor, 6, 0));
    html.find('.toggle-item-numeric').mousedown(ev => toggleUpOrDown(datasetOf(ev).path, ev.which, getItemFromActor(datasetOf(ev).itemId, this.actor), 9, 0));
    html.find('.toggle-actor-numeric').mousedown(ev => {
      const max = datasetOf(ev).max || 9;
      toggleUpOrDown(datasetOf(ev).path, ev.which, this.actor, max, 0);
    });

    html.find(".skill-point-converter").click(ev => convertSkillPoints(this.actor, datasetOf(ev).from, datasetOf(ev).to, datasetOf(ev).operation, datasetOf(ev).rate));

    // Rest Button
    html.find(".rest").click(() => createRestDialog(this.actor));

    // Configuration Dialogs
    html.find(".config-md").click(() => configureDefence(this.actor, "mental"));
    html.find(".config-pd").click(() => configureDefence(this.actor, "physical"));
    html.find(".config-jump").click(() => configureJump(this.actor));
    html.find(".activable-proficiency").click(ev => changeProficiencyAndRefreshItems(datasetOf(ev).key, this.actor));

    html.find(".show-actions").click(() => createActionsDialog(this.actor));
    // Manipulating resources
    html.find(".use-ap").click(() => subtractAP(this.actor, 1));
    html.find(".regain-ap").click(() => refreshAllActionPoints(this.actor));
    html.find(".regain-resource").click(ev => regainBasicResource(datasetOf(ev).key, this.actor, datasetOf(ev).amount));
    html.find(".spend-resource").click(ev => subtractBasicResource(datasetOf(ev).key, this.actor, datasetOf(ev).amount));

    // Item manipulation
    html.find('.item-edit').click(ev => editItemOnActor(datasetOf(ev).itemId, this.actor));
    html.find('.editable').mousedown(ev => ev.which === 2 ? editItemOnActor(datasetOf(ev).itemId, this.actor) : ()=>{});
    html.find(".level").click(ev => changeLevel(datasetOf(ev).up, datasetOf(ev).itemId, this.actor));

    // Change item charges
    html.find('.update-charges').change(ev => changeCurrentCharges(valueOf(ev), getItemFromActor(datasetOf(ev).itemId, this.actor)));

    // Update numeric values on items
    html.find('.change-item-numeric-value').change(ev => changeNumericValue(valueOf(ev), datasetOf(ev).path, getItemFromActor(datasetOf(ev).itemId, this.actor)));
    // Update numeric values on actors
    html.find('.change-actor-numeric-value').change(ev => changeNumericValue(valueOf(ev), datasetOf(ev).path, this.actor));

    // Add custom resource
    html.find('.add-resource').change(ev => createNewCustomResource(valueOf(ev), this.actor));
    html.find('.edit-resource').click(ev => configureCustomResource(this.actor, datasetOf(ev).key));
    html.find('.resource-icon').on('imageSrcChange', ev => changeResourceIcon(ev, this.actor));

    // Manage knowledge and languages
    html.find('.add-knowledge').click(() => addCustomSkill(this.actor));
    html.find('.remove-knowledge').click(ev => removeCustomSkill(datasetOf(ev).key, this.actor));
    html.find('.add-language').click(() => addCustomLanguage(this.actor));
    html.find('.remove-language').click(ev => removeCustomLanguage(datasetOf(ev).key, this.actor));

    // Item details on hover
    html.find('.item-row').hover(ev => this._showItemTooltip(datasetOf(ev).itemId, html), () => this._hideItemTooltip(html));

    // Active Effect Managment
    html.find(".effect-create").click(ev => createEffectOn(datasetOf(ev).type, this.actor));
    html.find(".effect-toggle").click(ev => toggleEffectOn(datasetOf(ev).effectId, this.actor));
    html.find(".effect-edit").click(ev => editEffectOn(datasetOf(ev).effectId, this.actor));
    html.find('.editable-effect').mousedown(ev => ev.which === 2 ? editEffectOn(datasetOf(ev).effectId, this.actor) : ()=>{});
    html.find(".effect-delete").click(ev => deleteEffectOn(datasetOf(ev).effectId, this.actor));
  }

  _editActiveListeners(html) {
    if (!this.isEditable) return;

    // Item manipulation
    html.find('.item-create').click(ev => createItemDialog(datasetOf(ev).tab, this.actor));
    html.find('.item-delete').click(ev => deleteItemFromActor(datasetOf(ev).itemId, this.actor));

    // Table headers names ordering
    html.find(".reorder").click(ev => reorderTableHeader(ev, this.actor));
  }

  _showItemTooltip(itemId, html) {
    const tooltip = html.find(".item-tooltip");
    const itemName = tooltip.find(".item-name");
    const itemDescription = tooltip.find(".item-description");
    const itemDetails = tooltip.find(".item-details");
    const item = this.actor.items.get(itemId);

    const name = generateItemName(item);
    const description = generateDescriptionForItem(item);
    const details = generateDetailsForItem(item);

    itemName.html(name);
    itemDescription.html(description);
    itemDetails.html(details);
    tooltip.removeAttr("hidden");
  }

  _hideItemTooltip(html) {
    const tooltip = html.find(".item-tooltip");
    tooltip.attr("hidden", "true");
  }
}

/**
 * Configuration of advancements on item
 */
class AdvancementConfiguration extends Dialog {

  constructor(item, key, newAdv, dialogData = {}, options = {}) {
    super(dialogData, options);
    this.item = item;
    this.key = key;

    if(newAdv) this.advancement = this._createNewAdvancement();
    else this.advancement = foundry.utils.deepClone(item.system.advancements[this.key]);
  }

  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      template: "systems/dc20rpg/templates/dialogs/configure-advancement.hbs",
      classes: ["dc20rpg", "dialog"],
      width: 650,
      height: 550
    });
  }

  async getData() {
    const advancement = this.advancement;

    // Collect items that are part of advancement
    Object.values(advancement.items).forEach(async record => {
      const item = await fromUuid(record.uuid);
      record.img = item.img;
      record.name = item.name;

      if (record.mandatory) record.selected = true;
    });

    return advancement;
  }

  _createNewAdvancement() {
    return { 
      name: "Advancement",
      mustChoose: false,
      pointAmount: 1,
      level: 1,
      applied: false,
      talent: false,
      items: {
      }
    };
  }

   /** @override */
  activateListeners(html) {
    super.activateListeners(html);
    html.find(".save").click((ev) => this._onSave(ev));
    html.find('.activable').click(ev => this._onActivable(datasetOf(ev).path));
    html.find(".selectable").change(ev => this._onValueChange(datasetOf(ev).path, valueOf(ev)));
    html.find(".input").change(ev => this._onValueChange(datasetOf(ev).path, valueOf(ev)));
    html.find(".numeric-input").change(ev => this._onNumericValueChange(datasetOf(ev).path, valueOf(ev)));

    // Item manipulation
    html.find('.item-delete').click(ev => this._onItemDelete(datasetOf(ev).key)); 

    // Drag and drop events
    html[0].addEventListener('dragover', ev => ev.preventDefault());
    html[0].addEventListener('drop', async ev => await this._onDrop(ev));
  }

  _onSave(event) {
    event.preventDefault();
    this.item.update({[`system.advancements.${this.key}`] : this.advancement});
    this.close();
  }
  _onActivable(pathToValue) {
    let value = getValueFromPath(this.advancement, pathToValue);
    setValueForPath(this.advancement, pathToValue, !value);
    this.render(true);
  }
  _onValueChange(path, value) {
    setValueForPath(this.advancement, path, value);
    this.render(true);
  }
  _onNumericValueChange(path, value) {
    const numericValue = parseInt(value);
    setValueForPath(this.advancement, path, numericValue);
    this.render(true);
  }

  async _onDrop(event) {
    event.preventDefault();
    const droppedData  = event.dataTransfer.getData('text/plain');
    if (!droppedData) return;
    
    const droppedObject = JSON.parse(droppedData);
    if (droppedObject.type !== "Item") return;

    const item = await Item.fromDropData(droppedObject);
    if (!["feature", "technique", "spell"].includes(item.type)) return;

    // Get item
    this.advancement.items[item.id] = {
      uuid: droppedObject.uuid,
      createdItemId: "",
      selected: false,
      pointValue: 1,
      mandatory: false,
    };
    this.render(true);
  }

  _onItemDelete(itemKey) {
    delete this.advancement.items[itemKey];
    this.item.update({[`system.advancements.${this.key}.items.-=${itemKey}`] : null});
    this.render(true);
  }
}

/**
 * Creates AdvancementConfiguration dialog for given item. 
 */
function configureAdvancementDialog(item, advancementKey) {
  let newAdv = false;
  if (!advancementKey) {
    newAdv = true;
    const advancements = item.system.advancements;
    do {
      advancementKey = generateKey();
    } while (advancements[advancementKey]);
  }
  const dialog = new AdvancementConfiguration(item, advancementKey, newAdv, {title: `Configure Advancement`});
  dialog.render(true);
}

function addEnhancement(item, $nameInput) {
  const enhancementName = $nameInput.val();
  if (!enhancementName) {
    let errorMessage = `Enhancement name must be provided.`;
    ui.notifications.error(errorMessage);
    return;
  }
  const enhancements = item.system.enhancements;
  const resources = {
    actionPoint: null,
    health: null,
    mana: null,
    stamina: null
  };
  const modifications = {
    hasAdditionalFormula: false,
    additionalFormula: "",
    overrideSave: false,
    save : {
      type: "",
      dc: null,
      calculationKey: "martial",
      addMastery: false
    }
  };

  let key = "";
  do {
    key = generateKey();
  } while (enhancements[key]);

  const enhancement = {
    name: enhancementName,
    number: 0,
    resources: resources,
    modifications: modifications
  };

  item.update({[`system.enhancements.${key}`]: enhancement});
}

function removeEnhancement(item, key) {
  item.update({[`system.enhancements.-=${key}`]: null });
}

function addMartialManeuvers(item) {
  const enhancements = item.system.enhancements;
  enhancements["powerAttack"] = _maneuver("Power Attack", true, false);
  enhancements["extendAttack"] = _maneuver("Extend Attack", false, false);
  enhancements["sweepAttack"] = _maneuver("Sweep Attack", false, false);
  enhancements["saveManeuver"] = _maneuver("Save Maneuver", false, true);
  const weaponManeuver = _weaponManeuver(item.system.weaponCategory);
  if (weaponManeuver) enhancements["weaponManeuver"] = weaponManeuver;
  enhancements["spendStamina"] = _spendStamina();
  item.update({[`system.enhancements`]: enhancements});
}

function _weaponManeuver(weaponCategory) {
  switch (weaponCategory) {
    case "axe": 
    case "chained": 
    case "fist": 
    case "hammer": 
    case "pick": 
    case "staff": 
    case "whip":
      return _maneuver("Weapon Maneuver", true, true);

    case "spear":
    case "crossbow":
      return _maneuver("Weapon Maneuver", true, false);

    case "bow": 
    case "sword":
      return _maneuver("Weapon Maneuver", false, false);
  }
}

function _maneuver(name, hasExtraDamage, hasSave) {
  return {
    name: name,
    number: 0,
    resources: {
      actionPoint: 1,
      health: null,
      mana: null,
      stamina: null
    },
    modifications: {
      hasAdditionalFormula: hasExtraDamage,
      additionalFormula: "1",
      overrideSave: hasSave,
      save : {
        type: "",
        dc: null,
        calculationKey: "martial",
        addMastery: false
      }
    }
  };
}

function _spendStamina() {
  return {
    name: "Spend Stamina Instead Of AP",
    number: 0,
    resources: {
      actionPoint: -1,
      health: null,
      mana: null,
      stamina: 1
    },
    modifications: {
      hasAdditionalFormula: false,
      additionalFormula: 0,
      overrideSave: false,
      save : {
        type: "",
        dc: null,
        calculationKey: "martial",
        addMastery: false
      }
    }
  };
}

function addFormula(category, item) {
  const formulas = item.system.formulas;

  let key = "";
  do {
    key = generateKey();
  } while (formulas[key]);

  formulas[key] = {
    formula: "",
    type: "",
    category: category,
    versatile: false,
    versatileFormula: "",
    fail: false,
    failFormula: "",
    each5: false,
    each5Formula: "",
  };

  item.update({ ["system.formulas"]: formulas });
}

function removeFormula(key, item) {
  item.update({ [`system.formulas.-=${key}`]: null });
}

/**
* Returns html used to create fromula shown in item sheet. 
*/
function getFormulaHtmlForCategory(category, item) {
  const types = { ...DC20RPG.damageTypes, ...DC20RPG.healingTypes };
  let formulas = item.system.formulas;
  let formulaString = "";

  let filteredFormulas = Object.values(formulas)
    .filter(formula => formula.category === category);

  for (let i = 0; i < filteredFormulas.length; i++) {
    let formula = filteredFormulas[i];
    if (formula.formula === "") continue;
    formulaString += formula.formula;
    if (formula.versatile) formulaString += "(" + formula.versatileFormula + ")";
    formulaString += " <em>" + getLabelFromKey(formula.type, types) + "</em>";
    formulaString += " + ";
  }

  if (formulaString !== "") formulaString = formulaString.substring(0, formulaString.length - 3);
  return formulaString;
}

function updateScalingValues(item, dataset, value, innerKey) {
  const key = dataset.key;
  const index = parseInt(dataset.index);
  const newValue = parseInt(value);

  let currentArray = item.system[innerKey][key].values;
  let updatedArray = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
  for (let i = 0; i < currentArray.length; i++) {
    if (i < index) updatedArray[i] = currentArray[i];
    if (i === index) updatedArray[i] = newValue;
    if (i > index) updatedArray[i] = currentArray[i] > newValue ? currentArray[i] : newValue;
  }

  item.update({[`system.${innerKey}.${key}.values`]: updatedArray});
}

function addScalingValue(item, $keyInput) {
  const kebab = /^[a-z\-]+$/;
  const key = $keyInput.val();
  if (!key) {
    const errorMessage = `Cannot create resource. Key must be provided.`;
    ui.notifications.error(errorMessage);
    return;
  }
  if (!kebab.test(key)) {
    const errorMessage = `Cannot create resource with key: ${key}. It must be in kebab-case.`;
    ui.notifications.error(errorMessage);
    return;
  }

  const newScaling = {
    label: kebabCaseToStandard(key),
    values: [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    isResource: false,
    reset: ""
  };
  item.update({[`system.scaling.${key}`]: newScaling});
}

function removeScalingValue(item, key) {
  item.update({[`system.scaling.-=${key}`]: null});
}

/**
 * Extend the basic ItemSheet with some very simple modifications
 * @extends {ItemSheet}
 */
class DC20RpgItemSheet extends ItemSheet {

  /** @override */
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      classes: ["dc20rpg", "sheet", "item"],
      width: 520,
      height: 520,
      tabs: [{ navSelector: ".sheet-tabs", contentSelector: ".item-sheet-body", initial: "description" }]
    });
  }

  /** @override */
  get template() {
    return `systems/dc20rpg/templates/item/item-${this.item.type}-sheet.hbs`;
  }

  /* -------------------------------------------- */

  /** @override */
  async getData() {
    // Retrieve base data structure.
    const context = super.getData();

    context.userIsGM = game.user.isGM;

    context.config = DC20RPG;
    context.system = this.item.system;
    context.flags = this.item.flags;

    context.itemsWithChargesIds = {};
    context.consumableItemsIds = {};
    context.weaponsOnActor = {};
    context.hasOwner = false;
    let actor = this.object?.parent ?? null;
    if (actor) {
      context.hasOwner = true;

      const itemIds = actor.getOwnedItemsIds(this.item.id);
      context.itemsWithChargesIds = itemIds.withCharges;
      context.consumableItemsIds = itemIds.consumable;
      context.weaponsOnActor = itemIds.weapons;
      
      this._prepareCustomCosts(context, actor); 
    }
    this._prepareEnhancements(context);
    this._prepareAdvancements(context);
    this._prepareItemUsageCosts(context, actor);

    context.sheetData = {};
    this._prepareDetailsBoxes(context);
    this._prepareTypesAndSubtypes(context);
    if (["weapon", "equipment", "consumable", "feature", "technique", "spell"].includes(this.item.type)) {
      this._prepareActionInfo(context);
    }

    // Prepare active effects
    context.effects = prepareActiveEffectCategories(this.item.effects);

    // Enrich text editors
    context.enriched = {};
    context.enriched.description = await TextEditor.enrichHTML(context.system.description, {async: true});

    return context;
  }

  /** @override */
  activateListeners(html) {
    super.activateListeners(html);

    html.find('.activable').click(ev => changeActivableProperty(datasetOf(ev).path, this.item));

    // Formulas
    html.find('.add-formula').click(ev => addFormula(datasetOf(ev).category, this.item));
    html.find('.remove-formula').click(ev => removeFormula(datasetOf(ev).key, this.item));

    // Class Advancements
    html.find('.create-advancement').click(() => configureAdvancementDialog(this.item));
    html.find('.advancement-edit').click(ev => configureAdvancementDialog(this.item, datasetOf(ev).key));
    html.find('.advancement-delete').click(ev => deleteAdvancement(this.item, datasetOf(ev).key));

    // Resources Managment
    html.find('.update-resources').change(ev => updateScalingValues(this.item, datasetOf(ev) , valueOf(ev), "resources"));
    html.find('.update-scaling').change(ev => updateScalingValues(this.item, datasetOf(ev), valueOf(ev), "scaling"));
    html.find('.add-scaling').click(() => addScalingValue(this.item, html.find('.scaling-resorce-key')));
    html.find('.remove-scaling').click(ev => removeScalingValue(this.item, datasetOf(ev).key));

    html.find('.select-other-item').change(ev => this._onSelection(datasetOf(ev).path, datasetOf(ev).selector, this.item));

    // Enhancement
    html.find('.add-enhancement').click(() => addEnhancement(this.item, html.find('.new-enhancement-name')));
    html.find('.add-martial-maneuvers').click(() => addMartialManeuvers(this.item));
    html.find('.remove-enhancement').click(ev => removeEnhancement(this.item, datasetOf(ev).key));

    // Active Effect Managment
    html.find(".effect-create").click(ev => createEffectOn(datasetOf(ev).type, this.item));
    html.find(".effect-toggle").click(ev => toggleEffectOn(datasetOf(ev).effectId, this.item));
    html.find(".effect-edit").click(ev => editEffectOn(datasetOf(ev).effectId, this.item));
    html.find('.editable-effect').mousedown(ev => ev.which === 2 ? editEffectOn(datasetOf(ev).effectId, this.item) : ()=>{});
    html.find(".effect-delete").click(ev => deleteEffectOn(datasetOf(ev).effectId, this.item));
    if (!this.isEditable) return;
  }

  _onSelection(path, selector, item) {
    const itemId = $(`.${selector} option:selected`).val();
    item.update({[path]: itemId});
  }

  //================================
  //           Get Data            =  
  //================================
  _prepareActionInfo(context) {
    context.sheetData.damageFormula = getFormulaHtmlForCategory("damage", this.item);
    context.sheetData.healingFormula = getFormulaHtmlForCategory("healing", this.item);
    context.sheetData.otherFormula = getFormulaHtmlForCategory("other", this.item);
  }

  _prepareDetailsBoxes(context) {
    const infoBoxes = {};
    infoBoxes.rollDetails = this._prepareRollDetailsBoxes(context);
    infoBoxes.properties = this._preparePropertiesBoxes(context);
    infoBoxes.spellLists = this._prepareSpellLists(context);
    infoBoxes.spellProperties = this._prepareSpellPropertiesBoxes(context);

    context.sheetData.infoBoxes = infoBoxes;
  }

  _prepareTypesAndSubtypes(context) {
    const item = this.item;
    const itemType = item.type;
    context.sheetData.fallbackType = getLabelFromKey(itemType, DC20RPG.allItemTypes);

    switch (itemType) {
      case "weapon": {
        context.sheetData.type = getLabelFromKey(item.system.weaponCategory, DC20RPG.weaponCategories);
        context.sheetData.subtype = getLabelFromKey(item.system.weaponType, DC20RPG.weaponTypes);
        break;
      }
      case "equipment": {
        context.sheetData.type = getLabelFromKey(item.system.equipmentType, DC20RPG.equipmentTypes);
        context.sheetData.subtype = getLabelFromKey(item.type, DC20RPG.inventoryTypes);
        break;
      }
      case "consumable": {
        context.sheetData.type = getLabelFromKey(item.system.consumableType, DC20RPG.consumableTypes);
        context.sheetData.subtype = getLabelFromKey(item.type, DC20RPG.inventoryTypes);
        break;
      }
      case "tool": {
        context.sheetData.type = getLabelFromKey(item.system.tradeSkillKey, DC20RPG.tradeSkills);
        context.sheetData.subtype = getLabelFromKey(item.type, DC20RPG.inventoryTypes);
        break;
      }
      case "feature": {
        context.sheetData.type = getLabelFromKey(item.system.featureType, DC20RPG.featureSourceTypes);
        context.sheetData.subtype = item.system.featureOrigin;
        break;
      }
      case "technique": {
        context.sheetData.type = getLabelFromKey(item.system.techniqueType, DC20RPG.techniqueTypes);
        context.sheetData.subtype = item.system.techniqueOrigin;
        break;
      }
      case "spell": {
        context.sheetData.type = getLabelFromKey(item.system.spellType, DC20RPG.spellTypes);
        context.sheetData.subtype = getLabelFromKey(item.system.magicSchool, DC20RPG.magicSchools);
        break;
      }
      case "class": {
        context.sheetData.type = getLabelFromKey(item.type, DC20RPG.allItemTypes);
        context.sheetData.subtype = "Level " + item.system.level;
        break;
      }
    }
  }

  _prepareRollDetailsBoxes(context) {
    const rollDetails = {};

    // Range
    const range = context.system.range;
    if(range && range.normal) {
      const unit = range.unit ? range.unit : "Spaces";
      const max = range.max ? `/${range.max}` : "";
      rollDetails.range = `${range.normal}${max} ${unit}`;
    }
    
    // Duration
    const duration = context.system.duration;
    if (duration && duration.type) {
      const value = duration.value ? duration.value : "";
      const type = getLabelFromKey(duration.type, DC20RPG.durations);
      const timeUnit = getLabelFromKey(duration.timeUnit, DC20RPG.timeUnits);

      if (duration.timeUnit) rollDetails.duration = `${type}<br> (${value} ${timeUnit})`;
      else rollDetails.duration = type;
    }

    // Target
    const target = context.system.target;
    if (target) {
      if (target.invidual) {
        if (target.type) {
          const targetType = getLabelFromKey(target.type, DC20RPG.invidualTargets);
          rollDetails.target = `${target.count} ${targetType}`;
        }
      } else {
        if (target.area) {
          const distance = target.area === "line" ? `${target.distance}/${target.width}` : target.distance;
          const arenaType = getLabelFromKey(target.area, DC20RPG.areaTypes);
          const unit = range.unit ? range.unit : "Spaces";
          rollDetails.target = `${distance} ${unit} ${arenaType}`;
        }
      }
    }

    // Tool info
    const tradeSkillKey = context.system.tradeSkillKey;
    if (tradeSkillKey) {
      const rollBonus = context.system.rollBonus ? context.system.rollBonus : 0;
      const tradeSkill = getLabelFromKey(tradeSkillKey, DC20RPG.tradeSkills);
      const sign = rollBonus >= 0 ? "+" : "-";
      rollDetails.tradeSkillBonus = `${tradeSkill} ${sign} ${Math.abs(rollBonus)}`;
    }

    return rollDetails;
  }

  _preparePropertiesBoxes(context) {
    const properties = {};
    const systemProperties = context.system.properties;
    
    if (!systemProperties) return properties;

    for (const [key, prop] of Object.entries(systemProperties)) {
      if (prop.active) {
        let label = getLabelFromKey(key, DC20RPG.properties);

        if (prop.value) {
          const value = prop.value !== null ? ` (${prop.value})` : "";
          label += value;
        }

        properties[key] = label;
      }
    }

    return properties;
  }

  _prepareSpellLists(context) {
    const properties = {};
    const spellLists = context.system.spellLists;

    if (!spellLists) return properties;

    for (const [key, prop] of Object.entries(spellLists)) {
      if (prop.active) {
        properties[key] = getLabelFromKey(key, DC20RPG.spellLists);
      }
    }

    return properties;
  }

  _prepareSpellPropertiesBoxes(context) {
    const properties = {};
    const spellComponents = context.system.components;

    if (!spellComponents) return properties;

    for (const [key, prop] of Object.entries(spellComponents)) {
      if (prop.active) {
        let label = getLabelFromKey(key, DC20RPG.components);

        if (key === "material") {
          const description = prop.description ? prop.description : "";
          const cost = prop.cost ? ` ${prop.cost} GP` : "";
          const consumed = prop.consumed ? " [Consumed On Use]" : "";
          label += `: ${description}${cost}${consumed}`;
        }

        properties[key] = label;
      }
    }

    return properties;
  }

  _prepareCustomCosts(context, actor) {
    if (!this.item.system.costs) return;

    const customResources = actor.system.resources.custom;
    const itemCustomCosts = this.item.system.costs.resources.custom;

    let customCosts = {};
    for (const [key, resource] of Object.entries(customResources)) {
      const cost = itemCustomCosts[key] ? itemCustomCosts[key] : null;

      const costWrapper = {
        name: resource.name,
        value: cost
      };
      customCosts[key] = costWrapper;
    }
    context.customCosts = customCosts;
  } 

  _prepareEnhancements(context) { // Custom resources will be added if needed
    const enhancements = this.item.system.enhancements;
    if (!enhancements) return;

    // We want to work on copy of enhancements because we will wrap its 
    // value and we dont want it to break other aspects
    const enhancementsCopy = foundry.utils.deepClone(enhancements); 
    context.enhancements = enhancementsCopy;
  }

  _prepareAdvancements(context) {
    const advancements = this.item.system.advancements;
    if (!advancements) return;
    
    // Split advancements depending on levels
    const advByLevel = {};

    Object.entries(advancements).forEach(([key, adv]) => {
      if (!advByLevel[adv.level]) advByLevel[adv.level] = {};
      advByLevel[adv.level][key] = adv;
    });

    context.advByLevel = advByLevel;
  }

  _prepareItemUsageCosts(context, actor) {
    context.usageCosts = getItemUsageCosts(this.item, actor);
  } 
}

class DC20RpgCombatTracker extends CombatTracker {

  /** @override */
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      id: "combat",
      template: "systems/dc20rpg/templates/sidebar/combat-tracker.hbs",
      title: "COMBAT.SidebarTitle",
      scrollY: [".directory-list"]
    });
  }

  /** @override */
  async getData(options={}) {
    const context = await super.getData(options);
    context.turns = await this._prepareTurnsWithCharacterType();
    return context;
  }

  async _prepareTurnsWithCharacterType() {
    const combat = this.viewed;
    const hasCombat = combat !== null;
    if ( !hasCombat ) return context;

    // Format information about each combatant in the encounter
    let hasDecimals = false;
    const turns = [];
    for ( let [i, combatant] of combat.turns.entries() ) {
      if ( !combatant.visible ) continue;

      // Prepare turn data
      const resource = combatant.permission >= CONST.DOCUMENT_OWNERSHIP_LEVELS.OBSERVER ? combatant.resource : null;
      const turn = {
        id: combatant.id,
        name: combatant.name,
        canRollInitiative: combatant.canRollInitiative,
        img: await this._getCombatantThumbnail(combatant),
        active: i === combat.turn,
        owner: combatant.isOwner,
        defeated: combatant.isDefeated,
        hidden: combatant.hidden,
        initiative: combatant.initiative,
        hasRolled: combatant.initiative !== null,
        hasResource: resource !== null,
        resource: resource,
        canPing: (combatant.sceneId === canvas.scene?.id) && game.user.hasPermission("PING_CANVAS")
      };
      if ( (turn.initiative !== null) && !Number.isInteger(turn.initiative) ) hasDecimals = true;
      turn.css = [
        turn.active ? "active" : "",
        turn.hidden ? "hidden" : "",
        turn.defeated ? "defeated" : ""
      ].join(" ").trim();

      // Actor and Token status effects
      turn.effects = new Set();
      for ( const effect of (combatant.actor?.temporaryEffects || []) ) {
        if ( effect.statuses.has(CONFIG.specialStatusEffects.DEFEATED) ) turn.defeated = true;
        else if ( effect.img ) turn.effects.add(effect.img);
      }
      turns.push(turn);
    }

    // Format initiative numeric precision
    const precision = CONFIG.Combat.initiative.decimals;
    turns.forEach(t => {
      if ( t.initiative !== null ) t.initiative = t.initiative.toFixed(hasDecimals ? precision : 0);
    });

    return turns;
  }

  /** @override */
  activateListeners(html) {
    super.activateListeners(html);

    html.find('.change-dc').change(ev => this._changeEncounterDC(valueOf(ev)));
  }

  _changeEncounterDC(value) {
    const dc = parseInt(value);
    const combat = this.viewed;
    combat.update({['flags.dc20rpg.encounterDC']: dc});
  }
}

/**
 * Define a set of template paths to pre-load
 * Pre-loaded templates are compiled and cached for fast access when rendering
 * @return {Promise}
 */
async function preloadHandlebarsTemplates() {
  return loadTemplates(Object.values(allPartials()));
}
function allPartials() {
  return {
    ...actorPartials(),
    ...itemPartials(),
    ...chatPartials(),
    ...otherPartials()
  };
}

function actorPartials() {
  return {
    "Actor Resources": "systems/dc20rpg/templates/actor/parts/actor-resources.hbs",
    "Actor Header": "systems/dc20rpg/templates/actor/parts/actor-header.hbs",
    "Image": "systems/dc20rpg/templates/actor/parts/header-parts/actor-header-left.hbs",
    "Character Info": "systems/dc20rpg/templates/actor/parts/header-parts/actor-header-character.hbs",
    "Npc Info": "systems/dc20rpg/templates/actor/parts/header-parts/actor-header-npc.hbs",
    "Actor Header Middle": "systems/dc20rpg/templates/actor/parts/header-parts/actor-header-middle-row.hbs",
    "Speed": "systems/dc20rpg/templates/actor/parts/header-parts/actor-header-speed.hbs",
    "Exhaustion": "systems/dc20rpg/templates/actor/parts/header-parts/actor-header-exhaustion.hbs",
    "Defences": "systems/dc20rpg/templates/actor/parts/header-parts/actor-header-defences.hbs",
    "Action Points": "systems/dc20rpg/templates/actor/parts/header-parts/actor-header-action-points.hbs",

    "Core": "systems/dc20rpg/templates/actor/parts/actor-core.hbs",
    "Roll Menu": "systems/dc20rpg/templates/actor/parts/core-parts/actor-core-roll-menu.hbs",
    "Skills": "systems/dc20rpg/templates/actor/parts/core-parts/actor-core-skills.hbs",
    "Masteries": "systems/dc20rpg/templates/actor/parts/core-parts/actor-core-masteries.hbs",
    "Damage Reduction": "systems/dc20rpg/templates/actor/parts/core-parts/actor-core-resistances.hbs",
    "Condition Immunities": "systems/dc20rpg/templates/actor/parts/core-parts/actor-core-conditions.hbs",
    "Vision": "systems/dc20rpg/templates/actor/parts/core-parts/actor-core-vision.hbs",

    "Features": "systems/dc20rpg/templates/actor/parts/actor-features.hbs",
    "Techniques": "systems/dc20rpg/templates/actor/parts/actor-techniques.hbs",
    "Inventory": "systems/dc20rpg/templates/actor/parts/actor-inventory.hbs",
    "Spells": "systems/dc20rpg/templates/actor/parts/actor-spells.hbs",
    "Actor Actions": "systems/dc20rpg/templates/actor/parts/actor-actions.hbs",

    "Actor Item Charges": "systems/dc20rpg/templates/actor/parts/items-parts/actor-items-row-charges.hbs",
    "Actor Item Config": "systems/dc20rpg/templates/actor/parts/items-parts/actor-items-row-config.hbs",
    "Actor Item Details": "systems/dc20rpg/templates/actor/parts/items-parts/actor-items-row-details.hbs",
    "Actor Item Roll": "systems/dc20rpg/templates/actor/parts/items-parts/actor-items-row-roll.hbs",
    "Actor Item Resources": "systems/dc20rpg/templates/actor/parts/items-parts/actor-items-row-usage.hbs",
    "Actor Item Item Usage": "systems/dc20rpg/templates/actor/parts/items-parts/actor-items-row-usage-extra.hbs",
    "Actor Item Tooltip": "systems/dc20rpg/templates/actor/parts/actor-tooltip.hbs"
  }
}

function itemPartials() {
  return {
    "Description": "systems/dc20rpg/templates/item/parts/item-description.hbs",
    "Usage": "systems/dc20rpg/templates/item/parts/item-usage.hbs",
    "Roll": "systems/dc20rpg/templates/item/parts/item-roll.hbs",
    "Enhancements": "systems/dc20rpg/templates/item/parts/item-enhancements.hbs",
    "Properties": "systems/dc20rpg/templates/item/parts/body-parts/item-properties.hbs",

    "Text Area": "systems/dc20rpg/templates/item/parts/body-parts/description/item-text-area.hbs",
    "Details Column": "systems/dc20rpg/templates/item/parts/body-parts/description/item-details-column.hbs",
    
    "Core Roll": "systems/dc20rpg/templates/item/parts/body-parts/roll/item-core-roll.hbs",
    "Target": "systems/dc20rpg/templates/item/parts/body-parts/roll/item-target.hbs",
    "Save":"systems/dc20rpg/templates/item/parts/body-parts/roll/item-save.hbs",
    "Check":"systems/dc20rpg/templates/item/parts/body-parts/roll/item-check.hbs",
    "Formulas": "systems/dc20rpg/templates/item/parts/body-parts/roll/item-formulas.hbs",

    "Charges": "systems/dc20rpg/templates/item/parts/body-parts/usage/item-charges.hbs",
    "Core Resources": "systems/dc20rpg/templates/item/parts/body-parts/usage/item-core-resources.hbs",
    "Other Item Usage": "systems/dc20rpg/templates/item/parts/body-parts/usage/item-other-item-usage.hbs",

    "Advancements": "systems/dc20rpg/templates/item/parts/body-parts/advancements/item-class-advancements.hbs",
    "Scaling": "systems/dc20rpg/templates/item/parts/body-parts/advancements/item-class-scaling-values.hbs",
    
    "Item Name": "systems/dc20rpg/templates/item/parts/header-parts/item-header-name.hbs",
    "Usage Header": "systems/dc20rpg/templates/item/parts/header-parts/item-header-usage.hbs",
    "Roll Header": "systems/dc20rpg/templates/item/parts/header-parts/item-header-roll.hbs",
    "Armor Header": "systems/dc20rpg/templates/item/parts/header-parts/item-header-armor.hbs",
  }
}

function chatPartials() {
  return {
    "Dice Roll": "systems/dc20rpg/templates/chat/parts/dice-roll.hbs",
    "Check Details": "systems/dc20rpg/templates/chat/parts/check-button.hbs",
    "Save Details": "systems/dc20rpg/templates/chat/parts/save-button.hbs",
    "Targets": "systems/dc20rpg/templates/chat/parts/targets.hbs",
  }
}

function otherPartials() {
  return {
    "Effects Tables": "systems/dc20rpg/templates/effects/effects.hbs"
  }
}

/**
 * Registers additional Handlebars Helpers to be used in templates later.
 * @return {void}
 */
function registerHandlebarsHelpers() {

  Handlebars.registerHelper('capitalize', function (str) {
    return capitalize(str);
  });

  Handlebars.registerHelper('add', function (obj1, obj2) {
    return obj1 + obj2;
  });

  Handlebars.registerHelper('ifCond', function (v1, operator, v2, options) {
    switch (operator) {
      case '==':
        return (v1 == v2) ? options.fn(this) : options.inverse(this);
      case '===':
        return (v1 === v2) ? options.fn(this) : options.inverse(this);
      case '!=':
        return (v1 != v2) ? options.fn(this) : options.inverse(this);
      case '!==':
        return (v1 !== v2) ? options.fn(this) : options.inverse(this);
      case '<':
        return (v1 < v2) ? options.fn(this) : options.inverse(this);
      case '<=':
        return (v1 <= v2) ? options.fn(this) : options.inverse(this);
      case '>':
        return (v1 > v2) ? options.fn(this) : options.inverse(this);
      case '>=':
        return (v1 >= v2) ? options.fn(this) : options.inverse(this);
      case '&&':
        return (v1 && v2) ? options.fn(this) : options.inverse(this);
      case '||':
        return (v1 || v2) ? options.fn(this) : options.inverse(this);
      case '%':
        return (v1 % v2 === 0) ? options.fn(this) : options.inverse(this);
      default:
        return options.inverse(this);
    }
  });

  Handlebars.registerHelper('skillMasteryIcon', function (skillMasteryKey) {
    switch (skillMasteryKey) {
      case "":
        return "fa-regular fa-circle";
      case "novice":
        return "fa-regular fa-circle-half-stroke";
      case "trained":
        return "fa-solid fa-circle";
      case "expert":
        return "fa-solid fa-circle-check";
      case "master":
        return "fa-solid fa-circle-up";
      case "grandmaster":
        return "fa-solid fa-certificate";
    }
  });

  Handlebars.registerHelper('languageMasteryIcon', function (languageMasteryIcon) {
    switch (languageMasteryIcon) {
      case 0:
        return "fa-regular fa-circle";
      case 1:
        return "fa-regular fa-circle-half-stroke";
      case 2:
        return "fa-solid fa-circle";
      case 3:
        return "fa-solid fa-certificate";
    }
  });

  Handlebars.registerHelper('costPrinter', function (cost, costIcon, mergeAmount, hasValueForZero, zeroIcon) {
    const costIconHtml = `<i class="${costIcon} cost-icon"></i>`;
    const zeroIconHtml = `<i class="${zeroIcon} cost-icon"></i>`;

    if (cost === undefined) return '';
    if (cost === 0 && hasValueForZero) return zeroIconHtml;
    if (cost === 0) return '';
     
    if (mergeAmount > 6 && cost > 1) return `<b>${cost}x</b>&nbsp${costIconHtml}`;

    let pointsPrinter = "";
    for (let i = 1; i <= cost; i ++) {
      pointsPrinter += costIconHtml;
    }
    return pointsPrinter;
  });

  Handlebars.registerHelper('costPrinterIcons', function (cost, iconPath, mergeAmount, hasValueForZero, zeroIconPath) {
    const costImg = `<img src=${iconPath} class="cost-img">`;
    const zeroImg = `<img src=${zeroIconPath} class="cost-img">`;

    if (cost === undefined) return '';
    if (cost === 0 && hasValueForZero) return zeroImg;
    if (cost === 0) return '';

    if (mergeAmount > 6) return `<b>${cost}x</b>&nbsp${costImg}`;
     
    let pointsPrinter = "";
    for (let i = 1; i <= cost; i ++) {
      pointsPrinter += costImg;
    }
    return pointsPrinter;
  });

  Handlebars.registerHelper('printGrit', function (current, max) {
    let fullPoint = "<a class='gp fa-solid fa-hand-fist fa-lg'></a>";
    let emptyPoint = "<a class='gp fa-light fa-hand-fist fa-lg'></a>";

    let gritPoints = "";
    for(let i = 0; i < max; i++) {
      if (i < current) gritPoints += fullPoint;
      else gritPoints += emptyPoint;
    }
    return gritPoints;
  });

  Handlebars.registerHelper('printActionPoints', function (current, max) {
    let fullPoint = "<i class='fa-solid fa-dice-d6 fa-2x ap'></i>";
    let emptyPoint = "<i class='fa-light fa-dice-d6 fa-2x ap'></i>";

    if (max >= 5) return `<b>${current}/${max}</b> ${fullPoint}`;
    
    let actionPoints = "";
    for(let i = 0; i < max; i++) {
      if (i < current) actionPoints += fullPoint;
      else actionPoints += emptyPoint;
    }
    return actionPoints;
  });

  Handlebars.registerHelper('arrayIncludes', function(object, options) {
    let arrayString = options.hash.arrayString;
    let array = arrayString.split(' ');

    return array.includes(object);
  });

  Handlebars.registerHelper('labelFromKey', function(key, objectWithLabels) {
    return getLabelFromKey(key, objectWithLabels);
  });

  Handlebars.registerHelper('printDices', function(results, faces) {
    if (!results) return;

    let final = "";
    results.forEach(result => {
      let colored = result.result === faces ? "max" 
                    : result.result === 1 ? "min" 
                    : "";
      final += `<li class="roll die d${faces} ${colored}">${result.result}</li>`;
    });
    return final;
  });

  Handlebars.registerHelper('sumDices', function(results) {
    if (!results) return;

    let diceTotal = 0;
    results.forEach(result => {
      diceTotal += result.result;
    });
    return diceTotal;
  });

  Handlebars.registerHelper('PARTIAL', function(partialName) {
    const partialPath = allPartials()[partialName];

    if (!partialPath) {
      return new Handlebars.SafeString(`Partial "${partialName}" not found`);
    }

    const template = Handlebars.partials[partialPath];
    if (template) {
      return new Handlebars.SafeString(template(this));
    }
    return '';
  });
}

/**
 * Create a Macro from an Item drop.
 * Get an existing item macro if one exists, otherwise create a new one.
 * @param {Object} data     The dropped data
 * @param {number} slot     The hotbar slot to use
 * @returns {Promise}
 */
async function createItemMacro(data, slot) {
  // First, determine if this is a valid owned item.
  if (data.type !== "Item") return;
  if (!data.uuid.includes('Actor.') && !data.uuid.includes('Token.')) {
    return ui.notifications.warn("You can only create roll macro for owned Items");
  }
  // If it is, retrieve it based on the uuid.
  const item = await Item.fromDropData(data);

  // Create the macro command using the uuid.
  const command = `game.dc20rpg.rollItemMacro("${item.name}");`;
  let macro = game.macros.find(m => (m.name === item.name) && (m.command === command));
  if (!macro) {
    macro = await Macro.create({
      name: item.name,
      type: "script",
      img: item.img,
      command: command,
      flags: { "dc20rpg.itemMacro": true }
    });
  }
  game.user.assignHotbarMacro(macro, slot);
  return false;
}

async function rollItemWithName(itemName) {
  const seletedTokens = await getSelectedTokens();
  if (!seletedTokens) return ui.notifications.warn(`No selected or assigned actor could be found to target with macro.`);

  
  for (let token of seletedTokens) {
    const actor = await token.actor;
    const item = await actor.items.getName(itemName);
    if (!item) {
      ui.notifications.warn(`Actor '${actor.name}' does not own item named '${itemName}'.`);
      continue;
    }

    return await rollFromItem(item._id, actor, true);
  }
}

function registerDC20Statues() {
  return [
    _invisible(),
    _bleeding(),
    _burning(),
    _poisoned(), 

    _charmed(),
    _grappled(),
    _intimidated(),
    _taunted(),

    _rattled(),
    _frightened(),
    _surprised(), 
    _prone(),

    _deafened(),
    _blinded(),
    _incapacitated(),
    _unconscious(),

    _restrained(),
    _stunned(),
    _paralyzed(),
    _petrified(),

    _exposed(1),
    _exposed(2),
    _exposed(3),
    _exposed(4),

    _hindered(1),
    _hindered(2),
    _hindered(3),
    _hindered(4),

    _dazed(1),
    _dazed(2),
    _dazed(3),
    _dazed(4),

    _heavilyDazed(1),
    _heavilyDazed(2),
    _heavilyDazed(3),
    _heavilyDazed(4),

    _impaired(1),
    _impaired(2),
    _impaired(3),
    _impaired(4),

    _heavilyImpaired(1),
    _heavilyImpaired(2),
    _heavilyImpaired(3),
    _heavilyImpaired(4),

    _slowed(1),
    _slowed(2),
    _slowed(3),
    _slowed(4),

    _concentration(),
    _bloodied1(),
    _bloodied2(),
    _dead(),
  ]
}

//================================
//             EXTRA             =
//================================
function _concentration() {
  return {
    id: "concentration",
    name: "Concentration",
    label: "Concentration",
    icon: "systems/dc20rpg/images/statuses/concentration.svg",
    description: "You are concentrating on a Spell.",
    changes: []
  }
}
function _bloodied1() {
  return {
    id: "bloodied1",
    name: "Bloodied 1",
    label: "Bloodied 1",
    icon: "systems/dc20rpg/images/statuses/bloodied1.svg",
    description: "Has less than 50% HP.",
    changes: []
  }
}
function _bloodied2() {
  return {
    id: "bloodied2",
    name: "Bloodied 2",
    label: "Bloodied 2",
    icon: "systems/dc20rpg/images/statuses/bloodied2.svg",
    description: "Has less than 25% HP.",
    changes: []
  }
}
function _dead() {
  return {
    id: "dead",
    name: "Dead",
    label: "Dead",
    icon: "systems/dc20rpg/images/statuses/dead.svg",
    description: "You are dead.",
    changes: []
  }
}

//================================
//           STACKING            =
//================================
function _exposed(stack) {
  return {
    id: `exposed${stack}`,
    name: `Exposed ${stack}`,
    label: `Exposed ${stack}` ,
    icon: `systems/dc20rpg/images/statuses/exposed${stack}.svg`,
    description: `<b>Attack Checks</b> against you have ADV ${stack}.`,
    changes: []
  }
}
function _hindered(stack) {
  return {
    id: `hindered${stack}`,
    name: `Hindered ${stack}`,
    label: `Hindered ${stack}`,
    icon: `systems/dc20rpg/images/statuses/hindered${stack}.svg`,
    description: `You have DisADV ${stack} on <b>Attack Checks</b>.`,
    changes: []
  }
}
function _dazed(stack) {
  return {
    id: `dazed${stack}`,
    name: `Dazed ${stack}`,
    label: `Dazed ${stack}`,
    icon: `systems/dc20rpg/images/statuses/dazed${stack}.svg`,
    description: `You have DisADV ${stack} on <b>Mental Checks</b>.`,
    changes: []
  }
}
function _heavilyDazed(stack) {
  return {
    id: `heavilyDazed${stack}`,
    name: `Heavily Dazed ${stack}`,
    label: `Heavily Dazed ${stack}`,
    icon: `systems/dc20rpg/images/statuses/heavilyDazed${stack}.svg`,
    description: `You have DisADV ${stack} on <b>Mental Checks</b> and <b>Mental Saves</b>.`,
    changes: []
  }
}
function _impaired(stack) {
  return {
    id: `impaired${stack}`,
    name: `Impaired ${stack}`,
    label: `Impaired ${stack}`,
    icon: `systems/dc20rpg/images/statuses/impaired${stack}.svg`,
    description: `You have DisADV ${stack} on <b>Physical Checks</b>.`,
    changes: []
  }
}
function _heavilyImpaired(stack) {
  return {
    id: `heavilyImpaired${stack}`,
    name: `Heavily Impaired ${stack}`,
    label: `Heavily Impaired ${stack}`,
    icon: `systems/dc20rpg/images/statuses/heavilyImpaired${stack}.svg`,
    description: `You have DisADV ${stack} on <b>Physical Checks</b> and <b>Physical Saves</b>.`,
    changes: []
  }
}
function _slowed(stack) {
  return {
    id: `slowed${stack}`,
    name: `Slowed ${stack}`,
    label: `Slowed ${stack}`,
    icon: `systems/dc20rpg/images/statuses/slowed${stack}.svg`,
    description: `Every 1 Space you move costs an extra ${stack} Space of movement.`,
    changes: []
  }
}

//================================
//          OVERLAPPING          =
//================================
function _charmed() {
  return {
    id: "charmed",
    name: "Charmed",
    label: "Charmed",
    icon: "systems/dc20rpg/images/statuses/charmed.svg",
    description: "Your <b>Charmer</b> has ADV on <b>Charisma Checks</b> made against you. Additionally, you can't target your <b>Charmer</b> with harmful Attacks, abilities, or magic effects.",
    changes: []
  }
}
function _grappled() {
  const description = "Your Speed is reduced to 0 and you have DisADV on <b>Agility Saves</b>." + 
  "<br><br><b><u>Ending a Grapple</u></b> " + 
  "<ul><li><b>Escape Grapple:</b> You can spend <b>1 AP</b> to attempt to free yourself from a <b>Grapple</b>. " + 
  "Make a <b>Martial Check</b> contested by the opposing creatures <b>Athletics Check</b>. " + 
  "<br><b>Success:</b> You end the <b>Grappled</b> Condition on yourself. </li>" +
  "<li><b>Incapacitated Grappler:</b> If the Grappler becomes <b>Incapacitated</b>d, the Grapple immediately ends. </li>" +
  "<li><b>Forced Movement:</b> : If an effect attempts to forcibly move you beyond the Grappler's reach, the Grappler makes " + 
  "the Check or Save instead of you. If the effect targets both you and the Grappler, the Grappler makes 1 Check or Save for both of you." +
  "<br><b>Success:</b> The targets of the effect aren't moved." +
  "<br><b>Fail:</b> The Grapple immediately ends, and the targets of the effect are moved. </li>" +
  "<li><b>Falling:</b> If you begin falling while Grappled, and your Grappler isn't falling with you, your Grappler holds you in the air if " + 
  "they can carry your weight.</li></ul>";

  return {
    id: "grappled",
    name: "Grappled",
    label: "Grappled",
    icon: "systems/dc20rpg/images/statuses/grappled.svg",
    description: description,
    changes: []
  }
}
function _intimidated() {
  return {
    id: "intimidated",
    name: "Intimidated",
    label: "Intimidated",
    icon: "systems/dc20rpg/images/statuses/intimidated.svg",
    description: "You have DisADV on all <b>Checks</b> while your source intimidation is within your line of sight.",
    changes: []
  }
}
function _rattled() {
  return {
    id: "rattled",
    name: "Rattled",
    label: "Rattled",
    icon: "systems/dc20rpg/images/statuses/rattled.svg",
    description: "You can't willingly move closer to your source of fear, and you are <b>Intimidated</b> (DisADV on all <b>Checks</b> while it's within your line of sight).",
    changes: []
  }
}
function _frightened() {
  return {
    id: "frightened",
    name: "Frightened",
    label: "Frightened",
    icon: "systems/dc20rpg/images/statuses/frightened.svg",
    description: "You must spend your turns trying to move as far away as you can from the source of the effect as possible. <br>The only <b>Action</b> you can take is the <b>Move Action</b> to try to run away, or the <b>Dodge Action</b> if you are prevented from moving or there's nowhere farther to move. <br>You are also considered <b>Rattled</b> (you cannot move closer to the source) and <b>Intimidated</b> (DisADV on all <b>Checks</b> while it's within your line of sight).",
    changes: []
  }
}
function _restrained() {
  return {
    id: "restrained",
    name: "Restrained",
    label: "Restrained",
    icon: "systems/dc20rpg/images/statuses/restrained.svg",
    description: "You are <b>Hindered</b> (You have DisADV on <b>Attack Checks</b>), <b>Exposed</b> (<b>Attack Checks</b> against you have ADV), and <b>Grappled</b> (your Speed is reduced to 0 and you have DisADV on <b>Agility Saves</b>).",
    changes: []
  }
}
function _taunted() {
  return {
    id: "taunted",
    name: "Taunted",
    label: "Taunted",
    icon: "systems/dc20rpg/images/statuses/taunted.svg",
    description: "You have DisADV on <b>Attack Checks</b> against creatures other than the one that Taunted you. If a creature is successfully <b>Taunted</b> while already <b>Taunted</b> by another creature, the original Taunt is removed.",
    changes: []
  }
}

//================================
//         NON-STACKING          =
//================================
function _bleeding() {
  return {
    id: "bleeding",
    name: "Bleeding",
    label: "Bleeding",
    icon: "systems/dc20rpg/images/statuses/bleeding.svg",
    description: "You take <b>1 True damage</b> at the start of each of your turns. <br><br><b><u>Ending Bleeding</u></b>" + 
                  "<ul><li><b>Healed</b>: You're subjected to an effect that restores your HP.</li> " + 
                  "<li><b>Medicine Action</b>: A creature can spend <b>1 AP</b> to make a <b>DC 10 Medicine Check</b> on itself or another creature within 1 Space." + 
                  "<br><b>Success:</b> Remove the <b>Bleeding</b> Condition. <br><b>Success(each 5):</b> The creature gains +1 Temp HP.",
    changes: []
  }
}
function _burning() {
  return {
    id: "burning",
    name: "Burning",
    label: "Burning",
    icon: "systems/dc20rpg/images/statuses/burning.svg",
    description: "You take <b>1 Fire damage</b> at the start of each of your turns. You or another creature within 1 Space can spend <b>1 AP</b> to put it out.",
    changes: []
  }
}
function _poisoned() {
  return {
    id: "poisoned",
    name: "Poisoned",
    label: "Poisoned",
    icon: "systems/dc20rpg/images/statuses/poisoned.svg",
    description: "You are <b>Impaired</b> (DisADV on <b>Physical Checks</b>) and take <b>1 Poison damage</b> at the start of each of your turns. <br>A creature can spend <b>1 AP</b> to make a <b>Medicine Check</b> (against the DC of the Poison) on itself or another creature within 1 Space. <br><b>Success:</b> Remove the <b>Poisoned</b> Condition.",
    changes: []
  }
}
function _deafened() {
  return {
    id: "deafened",
    name: "Deafened",
    label: "Deafened",
    icon: "systems/dc20rpg/images/statuses/deafened.svg",
    description: "You automatically fail <b>Checks</b> that require Hearing, and all creatures are considered <b>Unheard</b> by you. Additionally, you have <b>Resistance to Thunder damage</b>.",
    changes: [{
      key: "system.damageReduction.damageTypes.sonic.resistance",
      mode: 5,
      priority: undefined,
      value: "true"
    }]
  }
}
function _blinded() {
  return {
    id: "blinded",
    name: "Blinded",
    label: "Blinded",
    icon: "systems/dc20rpg/images/statuses/blinded.svg",
    description: "You automatically fail Checks that require <b>Sight</b> and all other creatures are considered <b>Unseen</b>. <br>You are <b>Exposed</b> (<b>Attack Checks</b> against you have ADV) and <b>Hindered</b> (You have DisADV on <b>Attack Checks</b>). <br>Additionally, while you are not guided by another creature, all terrain is Difficult Terrain to you (moving 1 Space costs 2 Spaces).",
    changes: []
  }
}
function _invisible() {
  return {
    id: "invisible",
    name: "Invisible",
    label: "Invisible",
    icon: "systems/dc20rpg/images/statuses/invisible.svg",
    description: "You are <b>Unseen</b>, making creatures that can't see you <b>Exposed</b> (your <b>Attack Checks</b> against them have ADV) and <b>Hindered</b> against you (they have DisADV on <b>Attack Checks</b> against you).",
    changes: []
  }
}
function _prone() {
  return {
    id: "prone",
    name: "Prone",
    label: "Prone",
    icon: "systems/dc20rpg/images/statuses/prone.svg",
    description: "You are <b>Hindered</b> (You have DisADV on <b>Attack Checks</b>), Ranged Attacks are <b>Hindered</b> against you, and you are <b>Exposed</b> against Melee Attacks (<b>Melee Attack Checks</b> against you have ADV). <br><br><b>Crawling:</b> Your only movement option is to Crawl, which counts as <b>Slowed 1</b> (Every 1 Space you move costs an extra 1 Space of movement). <br><br><b>Standing Up:</b> You can spend 2 Spaces of movement to stand up, ending the <b>Prone</b> Condition on yourself. Standing up from Prone does possibly trigger <b>Opportunity Attacks</b>.",
    changes: []
  }
}
function _incapacitated() {
  return {
    id: "incapacitated",
    name: "Incapacitated",
    label: "Incapacitated",
    icon: "systems/dc20rpg/images/statuses/incapacitated.svg",
    description: "You can not Speak, Concentrate, or spend Action Points.",
    changes: []
  }
}
function _stunned() {
  return {
    id: "stunned",
    name: "Stunned",
    label: "Stunned",
    icon: "systems/dc20rpg/images/statuses/stunned.svg",
    description: "You automatically fail <b>Agility</b>, <b>Might</b> and <b>Physical Saves</b>. You are also <b>Exposed</b> (<b>Attack Checks</b> against you have ADV), and <b>Incapacitated</b> (You can not Speak, Concentrate, or spend Action Points).",
    changes: []
  }
}
function _paralyzed() {
  return {
    id: "paralyzed",
    name: "Paralyzed",
    label: "Paralyzed",
    icon: "systems/dc20rpg/images/statuses/paralyzed.svg",
    description: "<b>Attacks</b> made from within 1 Space that Hit you are considered <b>Critical Hits</b>. You are also <b>Stunned</b (automatically fail <b>Agility</b>, <b>Might</b> and <b>Physical Saves</b>), <b>Exposed</b> (<b>Attack Checks</b> against you have ADV), and <b>Incapacitated</b> (You can not Speak, Concentrate, or spend Action Points).",
    changes: []
  }
}
function _unconscious() {
  return {
    id: "unconscious",
    name: "Unconscious",
    label: "Unconscious",
    icon: "systems/dc20rpg/images/statuses/unconscious.svg",
    description: "You are no longer aware of your surroundings, you drop whatever you are holding and fall <b>Prone</b>. <br>You are also <b>Paralyzed</b> (<b>Attack Checks</b> made from within 1 Space that Hit you are considered <b>Critical Hits</b>), <b>Stunned</b> (automatically fail <b>Agility</b>, <b>Might</b> and <b>Physical Saves</b>), <b>Exposed</b> (<b>Attack Checks</b> against you have ADV), and <b>Incapacitated</b>(You can not Speak, Concentrate, or spend Action Points).",
    changes: []
  }
}
function _petrified() {
  return {
    id: "petrified",
    name: "Petrified",
    label: "Petrified",
    icon: "systems/dc20rpg/images/statuses/petrified.svg",
    description: "You and your mundane belongings are turned into stone and you are no longer aware of your surroundings. You become 10 times heavier and have <b>Resistance (Half)</b> to all damage. <br><br>Any <b>Poisons</b> or <b>Diseases</b> already affecting you are suspended and you are immune to any additional <b>Poison</b> and <b>Disease</b> while <b>Petrified</b>. <br><br>You are also <b>Paralyzed</b> (<b>Attack Checks</b> made from within 1 Space that Hit you are considered <b>Critical Hits</b>), <b>Stunned</b> (automatically fail <b>Agility</b>, <b>Might</b> and <b>Physical Saves</b>), <b>Exposed</b>(<b>Attack Checks</b> against you have ADV), and <b>Incapacitated</b> (You can not Speak, Concentrate, or spend Action Points).",
    changes: [
      {
        key: "system.damageReduction.damageTypes.acid.resistance",
        mode: 5,
        priority: undefined,
        value: "true"
      },
      {
        key: "system.damageReduction.damageTypes.cold.resistance",
        mode: 5,
        priority: undefined,
        value: "true"
      },
      {
        key: "system.damageReduction.damageTypes.fire.resistance",
        mode: 5,
        priority: undefined,
        value: "true"
      },
      {
        key: "system.damageReduction.damageTypes.force.resistance",
        mode: 5,
        priority: undefined,
        value: "true"
      },
      {
        key: "system.damageReduction.damageTypes.holy.resistance",
        mode: 5,
        priority: undefined,
        value: "true"
      },
      {
        key: "system.damageReduction.damageTypes.lightning.resistance",
        mode: 5,
        priority: undefined,
        value: "true"
      },
      {
        key: "system.damageReduction.damageTypes.poison.resistance",
        mode: 5,
        priority: undefined,
        value: "true"
      },
      {
        key: "system.damageReduction.damageTypes.psychic.resistance",
        mode: 5,
        priority: undefined,
        value: "true"
      },
      {
        key: "system.damageReduction.damageTypes.sonic.resistance",
        mode: 5,
        priority: undefined,
        value: "true"
      },
      {
        key: "system.damageReduction.damageTypes.sonic.resistance",
        mode: 5,
        priority: undefined,
        value: "true"
      },
      {
        key: "system.damageReduction.damageTypes.unholy.resistance",
        mode: 5,
        priority: undefined,
        value: "true"
      },
      {
        key: "system.damageReduction.damageTypes.piercing.resistance",
        mode: 5,
        priority: undefined,
        value: "true"
      },
      {
        key: "system.damageReduction.damageTypes.slashing.resistance",
        mode: 5,
        priority: undefined,
        value: "true"
      },
      {
        key: "system.damageReduction.damageTypes.bludgeoning.resistance",
        mode: 5,
        priority: undefined,
        value: "true"
      }
    ]
  }
}
function _surprised() {
  return {
    id: "surprised",
    name: "Surprised",
    label: "Surprised",
    icon: "systems/dc20rpg/images/statuses/surprised.svg",
    description: "You can't spend <b>Action Points</b> and are <b>Exposed</b> (<b>Attack Checks</b> against you have ADV).",
    changes: []
  }
}

//=============================================================================
//																	SCOPES																		=
// types: Supported types: "string", "number", "boolean", "object"						=
// scopes: 																																		=
//		- "world" - system-specific settings																		=
//		- "client" - client-side settings - not synchronized between users. 		=
//								 They are only stored locally and are not saved to the 			=
//								 server. These settings are typically used for interface 		=
//								 customization or client-specific behavior.									=
//		- "user" - individual-user settings	- synchronized between devices for 	=
//							 that user.	They are stored on the server and can be accessed =
//							 from any device where the user is logged in. These settings 	=						
// 							 are often used for personal preferences or configurations.		=
//=============================================================================
// For more custom settings (with popups for example) see DND5e system
function registerGameSettings(settings) {
  settings.register("dc20rpg", "showDamageChatMessage", {
    name: "Show Damage/Healing Chat Messages to Players",
    hint: "If selected damage/healing taken messages will be send to public chat instead of being GM only.",
    scope: "world",
    config: true,
    default: false,
    type: Boolean
	});

  settings.register("dc20rpg", "showSourceOfDamageOnChatMessage", {
    name: "Show Source of Damage/Healing on Chat Messages",
    hint: "If selected damage/healing taken messages will be enhanced with sources of that calculation (enhancements, heavy/brutal, over 5, crit, etc).",
    scope: "world",
    config: true,
    default: true,
    type: Boolean
	});

  settings.register("dc20rpg", "showTargetsOnChatMessage", {
    name: "Show Targets on Chat Message",
    hint: "If selected user targets will be shown on chat message created by rolling an item.",
    scope: "world",
    config: true,
    default: true,
    type: Boolean
	});
}

// Import document classes.

/* -------------------------------------------- */
/*  Init Hook                                   */
/* -------------------------------------------- */
Hooks.once('init', async function() {
  
  // Add utility classes to the global game object so that they're more easily
  // accessible in global contexts.
  game.dc20rpg = {
    DC20RpgActor,
    DC20RpgItem,
    DC20RpgCombatant,
    rollItemMacro,
    getSelectedTokens,
    effectMacroHelper
  };
  
  CONFIG.statusEffects = registerDC20Statues();
  // Add custom constants for configuration.
  CONFIG.DC20RPG = DC20RPG;

  // Define custom Document classes
  CONFIG.Actor.documentClass = DC20RpgActor;
  CONFIG.Item.documentClass = DC20RpgItem;
  CONFIG.Combatant.documentClass  = DC20RpgCombatant;
  CONFIG.Combat.documentClass = DC20RpgCombat;
  CONFIG.Dice.rolls = [DC20RpgRoll];
  CONFIG.ui.combat = DC20RpgCombatTracker;

  // Register sheet application classes
  Actors.unregisterSheet("core", ActorSheet);
  Actors.registerSheet("dc20rpg", DC20RpgActorSheet, { makeDefault: true });
  Items.unregisterSheet("core", ItemSheet);
  Items.registerSheet("dc20rpg", DC20RpgItemSheet, { makeDefault: true });

  // Register Handlebars helpers
  registerHandlebarsHelpers();

  // Preload Handlebars templates
  return preloadHandlebarsTemplates();
});

/* -------------------------------------------- */
/*  Ready Hook                                  */
/* -------------------------------------------- */
Hooks.once("ready", async function() {
  // Register game settings
  registerGameSettings(game.settings);

  /* -------------------------------------------- */
  /*  Hotbar Macros                               */
  /* -------------------------------------------- */
  // Wait to register hotbar drop hook on ready so that modules could register earlier if they want to
  Hooks.on("hotbarDrop", (bar, data, slot) => {
    if(data.type === "Item") createItemMacro(data, slot);
    if(data.type === "Macro") {
      let macro = game.macros.find(macro => (macro.uuid === data.uuid));
      if(macro) game.user.assignHotbarMacro(macro, slot);
    }
    return false; 
  });
});

/* -------------------------------------------- */
/*  Render Chat Message Hook                    */
/* -------------------------------------------- */
Hooks.on("renderChatMessage", (message, html, data) => initChatMessage(message, html));
Hooks.on('renderActorSheet', (app, html, data) => addObserverToCustomResources(html));

Hooks.on("createActor", (actor, options, userID) => {
  if (userID != game.user.id) return; // Check current user is the one that triggered the hook
  preConfigurePrototype(actor);
});
Hooks.on("createItem", (item, options, userID) => {
  if (userID != game.user.id) return; // Check current user is the one that triggered the hook
  addUniqueItemToActor(item);
  checkProficiencies(item);
});
Hooks.on("updateItem", (item, updateData, options, userID) => {
  if (userID != game.user.id) return; // Check current user is the one that triggered the hook
  checkProficiencies(item);
});
Hooks.on("preDeleteItem", (item, options, userID) => {
  if (userID != game.user.id) return; // Check current user is the one that triggered the hook
  removeUniqueItemFromActor(item);
});
Hooks.on("preUpdateActor", (actor, updateData) => updateActorHp(actor, updateData));

/**
 * Create a Macro from an Item drop.
 * Get an existing item macro if one exists, otherwise create a new one.
 * @param {string} itemUuid
 */
function rollItemMacro(itemName) {
  rollItemWithName(itemName);
}
